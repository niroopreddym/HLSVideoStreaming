CREATE VIEW
    bb_vw_ops_incident AS
select
    task_ci.ci_item AS ci_name,
    task_ci.ci_item_sys_id AS ci_sys_id,
    task_ci.sys_id AS task_ci_sys_id,
    task_ci.task_sys_id AS task_ci_task_sys_id,
    incident.sys_id_incident AS sys_id_incident,
    incident.sys_id_task AS sys_id_task,
    incident.number AS incident_number,
    incident.category AS incident_category,
    incident.close_code AS incident_close_code,
    incident.state AS state,
    incident.incident_state AS incident_state,
    incident.made_sla AS incident_made_sla,
    incident.major_incident_state AS major_incident_state,
    incident.priority AS incident_priority,
    incident.caused_by AS incident_caused_by,
    incident.caused_by_sys_id AS caused_by_sys_id,
    incident.u_triggered_by_alert AS u_triggered_by_alert,
    date_format (incident.sys_created_on, '%Y-%m-%d') AS incident_created_on
from
    (
        (
            bb_prefact_snow_incident incident
            join bb_prefact_snow_task_ci task_ci on (incident.sys_id_incident = task_ci.task_sys_id)
        )
        join bb_mst_ci bmc on (bmc.sys_id = task_ci.ci_item_sys_id)
    )
where
    date_format (incident.sys_created_on, '%Y-%m-%d') between concat (
        year (curdate () - interval 2 year) + case
            when month (curdate ()) >= 4 then 0
            else -1
        end,
        '-04-01'
    ) and date_format  (sysdate (), '%Y-%m-%d')
order by
    incident.sys_created_on,
    incident.sys_id_incident,
    task_ci.ci_item;