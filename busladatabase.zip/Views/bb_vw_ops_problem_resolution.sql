CREATE VIEW
    bb_vw_ops_problem_resolution AS
select
    bmc.id AS ci_id,
    bmc.sys_id AS ci_sys_id,
    bmc.ci_name AS ci_name,
    date_format (task.sys_created_on, '%Y-%m-%d') AS txn_date,
    task.number AS number,
    task.sys_id AS task_sys_id,
    problem.sys_id_problem AS sys_id_problem,
    problem.sys_id_task AS sys_id_task,
    problem.category AS problem_category,
    problem.state AS problem_state,
    problem.made_sla AS problem_made_sla,
    problem.priority AS problem_priority,
    task.state AS task_state,
    task.priority AS task_priority,
    task.made_sla AS task_made_sla,
    task_sla.duration AS duration,
    task_sla.business_duration AS business_duration,
    sla_def.duration AS sla_def_duration,
    task_sla.has_breached AS has_breached,
    task_sla.stage AS stage,
    sla_def.type AS sla_type,
    sla_def.target AS target,
    problem.related_incidents AS related_incidents_count,
    problem.u_close_code AS close_code,
    problem.major_problem AS major_problem,
    date_format (task.closed_at, '%Y-%m-%d') AS closed_at
from
    (
        (
            (
                (
                    (
                        bb_prefact_snow_task task
                        join bb_prefact_snow_problem problem on (problem.sys_id_problem = task.sys_id)
                    )
                    join bb_prefact_snow_task_ci task_ci on (task_ci.task_sys_id = task.sys_id)
                )
                join bb_prefact_snow_task_sla task_sla on (task_sla.task_sys_id = task.sys_id)
            )
            join bb_prefact_snow_contract_sla sla_def on (sla_def.sys_id = task_sla.sla_sys_id)
        )
        join bb_mst_ci bmc on (bmc.sys_id = task_ci.ci_item_sys_id)
    )
where
    task.sys_class_name = 'Problem'
    and task_sla.stage <> 'Cancelled'
    and sla_def.type = 'SLA'
    and sla_def.target = 'Resolution'
    and date_format (task.sys_created_on, '%Y-%m-%d') between concat (
        year (curdate () - interval 2 year) + case
            when month (curdate ()) >= 4 then 0
            else -1
        end,
        '-04-01'
    ) and date_format  (sysdate (), '%Y-%m-%d')
order by
    task.sys_created_on,
    task.number,
    task.cmdb_ci;