CREATE VIEW
    bb_vw_ops_fact_observability AS
select
    ac.id AS id,
    ac.u_business_application AS ci_sys_id,
    ci.id AS ci_id,
    ci.ci_name AS ci_name,
    ti.id AS time_id,
    ti.date AS txn_date,
    ci.tier_id AS tier_id,
    case
        when tier.tier_name = 'Tier 1'
        and ci.is_platinum_ci = 'Y' then 'Tier 1 - Platinum'
        when tier.tier_name = 'Tier 1'
        and ci.is_platinum_ci = 'N' then 'Tier 1'
        when tier.tier_name = 'Tier 2' then 'Tier 2'
        when tier.tier_name = 'Tier 3' then 'Tier 3'
    end AS tier_name,
    ci.is_platinum_ci AS is_platinum_ci,
    ci.is_ci_vendor_product AS is_ci_vendor_product,
    ci.vendor AS vendor,
    ac.u_overall_adoption_level AS overall_adoption_level,
    ac.u_adoption_category AS adoption_category,
    ac.u_category AS category,
    ac.u_class_type AS class_type,
    ac.u_configuration_item AS configuration_item,
    ac.u_entity AS entity,
    ac.u_name AS name,
    ac.u_stage AS stage,
    ac.u_parent AS parent,
    ac.sys_created_on AS sys_created_on,
    ac.sys_updated_on AS sys_updated_on
from
    (
        (
            (
                bb_prefact_snow_u_adoption_check ac
                join bb_mst_ci ci on (ci.sys_id = ac.u_business_application)
            )
            join bb_dim_time ti on (
                ti.date = date_format (ac.sys_created_on, '%Y-%m-%d')
            )
        )
        left join bb_mst_tier tier on (ci.tier_id = tier.id)
    )
where
    ac.u_class_type = 'Business Application'
order by
    ci.ci_name;