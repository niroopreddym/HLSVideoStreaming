CREATE VIEW
    bb_vw_dashboard_product_ci_hry_unmapped AS
select
    t1.ci_id AS ci_id,
    t1.ci_name AS ci_name,
    t1.parent_ci_id AS parent_ci_id,
    t1.parent_ci_name AS parent_ci_name,
    t1.subcategory AS subcategory,
    t1.business_unit_id AS business_unit_id,
    t1.business_unit AS business_unit,
    t1.subproduct_capability_id AS subproduct_capability_id,
    t1.subproduct_code AS subproduct_code,
    t1.subproduct_name AS subproduct_name,
    t1.ci_subproduct_id AS ci_subproduct_id,
    t1.subproduct_id AS subproduct_id,
    t1.product_id AS product_id,
    t1.product_capability_id AS product_capability_id,
    t1.product_business_capability_name AS product_business_capability_name,
    t1.product_code AS product_code,
    t1.product_name AS product_name,
    t1.product_ownr AS product_ownr,
    t1.product_desc AS product_desc,
    t1.TYPE AS TYPE,
    t1.aat_id AS aat_id,
    t1.aat_name AS aat_name,
    t1.funding_portfolio_id AS funding_portfolio_id,
    t1.funding_portfolio_name AS funding_portfolio_name,
    t1.delivery_portfolio_id AS delivery_portfolio_id,
    t1.delivery_portfolio_name AS delivery_portfolio_name,
    t1.team_id AS team_id,
    t1.Tier AS Tier,
    ifnull (t1.actual_tier_name, 'Tier not defined') AS actual_tier_name,
    t1.is_platinum_ci AS is_platinum_ci,
    ifnull (t1.ci_tier, 'Tier not defined') AS ci_tier,
    (
        select
            bmt.tier_weightage
        from
            bb_mst_tier bmt
        where
            bmt.tier_name = t1.ci_tier
    ) AS tier_weightage,
    t1.is_ci_vendor_product AS is_ci_vendor_product,
    t1.vendor_name AS vendor_name,
    t1.tpo AS tpo,
    t1.tpm AS tpm,
    t1.install_status AS install_status,
    t1.ci_created_on AS ci_created_on
from
    (
        select
            ci.id AS ci_id,
            ci.ci_name AS ci_name,
            ci.parent_ci_id AS parent_ci_id,
            (
                select
                    bmc.ci_name AS parent_ci_name
                from
                    bb_mst_ci bmc
                where
                    bmc.id = ci.parent_ci_id
            ) AS parent_ci_name,
            ci.subcategory AS subcategory,
            0 AS business_unit_id,
            'Business Unit not defined' AS business_unit,
            0 AS subproduct_capability_id,
            'Sub Product not defined' AS subproduct_code,
            'Sub Product not defined' AS subproduct_name,
            ci.subproduct_id AS ci_subproduct_id,
            0 AS subproduct_id,
            0 AS product_id,
            0 AS product_capability_id,
            'Capability not defined' AS product_business_capability_name,
            'Product not defined' AS product_code,
            'Product not defined' AS product_name,
            '' AS product_ownr,
            '' AS product_desc,
            '' AS TYPE,
            ci.aat_id AS aat_id,
            ifnull (aat.aat_name, 'AAT not defined') AS aat_name,
            ci.funding_portfolio_id AS funding_portfolio_id,
            ifnull (
                ifnull (pf.portfolio_desc, dpf.portfolio_desc),
                'Funding portfolio not defined'
            ) AS funding_portfolio_name,
            aat.delivery_portfolio_id AS delivery_portfolio_id,
            ifnull (
                dpf.portfolio_desc,
                'Delivery portfolio not defined'
            ) AS delivery_portfolio_name,
            ci.team_id AS team_id,
            ci.tier_id AS Tier,
            tier.tier_name AS actual_tier_name,
            ci.is_ci_vendor_product AS is_ci_vendor_product,
            ci.vendor AS vendor_name,
            ci.technical_product_owner AS tpo,
            ci.technical_product_manager AS tpm,
            ci.is_platinum_ci AS is_platinum_ci,
            case
                when tier.tier_name = 'Tier 1'
                and ci.is_platinum_ci = 'Y' then 'Tier 1 - Platinum'
                when tier.tier_name = 'Tier 1'
                and ci.is_platinum_ci = 'N' then 'Tier 1'
                when tier.tier_name = 'Tier 2' then 'Tier 2'
                when tier.tier_name = 'Tier 3' then 'Tier 3'
            end AS ci_tier,
            ci.install_status AS install_status,
            ci.ci_created_on AS ci_created_on
        from
            (
                (
                    (
                        (
                            bb_mst_ci ci
                            left join bb_mst_portfolio pf on (ci.funding_portfolio_id = pf.id)
                        )
                        left join bb_mst_aat aat on (ci.aat_id = aat.id)
                    )
                    left join bb_mst_tier tier on (ci.tier_id = tier.id)
                )
                left join bb_mst_portfolio dpf on (aat.delivery_portfolio_id = dpf.id)
            )
        where
            ci.status = 'Y'
            and ci.subproduct_id is null
            and ci.ci_name like 'S.A%'
    ) t1
where
    t1.ci_id is not null
order by
    ifnull (t1.parent_ci_name, t1.ci_name);