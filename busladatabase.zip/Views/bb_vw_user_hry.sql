CREATE VIEW
    bb_vw_user_hry AS
select
    bmu.id AS user_id,
    bmu.staff_id AS staff_id,
    bmu.first_name AS first_name,
    bmu.last_name AS last_name,
    concat (trim(bmu.first_name), ' ', trim(bmu.last_name)) AS staff_name,
    bmu.job_title AS job_title,
    bmu.email AS email,
    bmu.grade AS grade,
    bmu.date_of_joining AS date_of_joining,
    bmu.date_of_leaving AS date_of_leaving,
    case
        when bmu.date_of_leaving is null
        or ifnull (bmu.date_of_leaving, current_timestamp()) >= sysdate () then 'Active'
        else 'Inactive'
    end AS staff_status,
    bmu.team_id AS team_id,
    bmt.team_code AS team_code,
    bmt.team_name AS team_name,
    decode_oracle (bmt.status, 'Y', 'Active', 'Inactive') AS team_status,
    bmu.chapter_id AS chapter_id,
    bmc.chapter_name AS chapter_name,
    bmc.chapter_desc AS chapter_desc,
    bmt.aat_id AS aat_id,
    bma.aat_name AS aat_code,
    bma.aat_desc AS aat_desc,
    decode_oracle (bma.status, 'Y', 'Active', 'Inactive') AS aat_status,
    pillar.id AS pillar_id,
    pillar.pillar_short_name AS pillar_shortname,
    pillar.pillar_name AS pillar_name,
    decode_oracle (pillar.status, 'Y', 'Active', 'Inactive') AS pillar_status,
    bmp.id AS delivery_portfolio_id,
    bmp.portfolio_desc AS portfolio_desc
from
    (
        (
            (
                (
                    (
                        bb_mst_users bmu
                        left join bb_mst_team bmt on (bmt.id = bmu.team_id)
                    )
                    left join bb_mst_aat bma on (bma.id = bmt.aat_id)
                )
                left join bb_mst_chapter bmc on (bmc.id = bmu.chapter_id)
            )
            left join bb_mst_pillar pillar on (pillar.id = bma.pillar_id)
        )
        left join bb_mst_portfolio bmp on (bmp.id = pillar.portfolio_id)
    );