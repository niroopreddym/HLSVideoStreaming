CREATE VIEW
    bb_vw_new_ci_notification AS
select
    t2.AppCIId AS AppCIId,
    t2.AppCIName AS AppCIName,
    t2.Description AS Description,
    t2.FundingPortfolio AS FundingPortfolio,
    t2.DeliveryPortfolio AS DeliveryPortfolio,
    t2.ART AS ART,
    t2.tpm AS tpm,
    t2.tpo AS tpo,
    t2.CIVendorInhouse AS CIVendorInhouse,
    t2.VendorName AS VendorName,
    t2.CIStatus AS CIStatus,
    t2.CITier AS CITier,
    t2.CICreatedOn AS CICreatedOn,
    t2.recepient_email_to AS recepient_email_to,
    case
        when t2.recepient_email_cc = t2.recepient_email_to then ''
        else t2.recepient_email_cc
    end AS recepient_email_cc,
    t2.CINotificationId AS CINotificationId,
    t2.CILastNotifiedOn AS CILastNotifiedOn,
    t2.CINotificationReminderRequired AS CINotificationReminderRequired
from
    (
        select
            t1.ci_id AS AppCIId,
            t1.ci_name AS AppCIName,
            t1.ci_short_description AS Description,
            t1.funding_portfolio AS FundingPortfolio,
            t1.delivery_portfolio AS DeliveryPortfolio,
            t1.aat_name AS ART,
            t1.tpm AS tpm,
            t1.tpo AS tpo,
            t1.ci_venor_inhouse AS CIVendorInhouse,
            t1.vendor_name AS VendorName,
            t1.install_status AS CIStatus,
            t1.ci_tier AS CITier,
            t1.ci_created_on AS CICreatedOn,
            substr (
                group_concat (t1.recepient_email_to separator ','),
                1,
                octet_length(
                    group_concat (t1.recepient_email_to separator ',')
                ) - 1
            ) AS recepient_email_to,
            substr (
                group_concat (t1.recepient_email_cc separator ','),
                locate (
                    ',',
                    group_concat (t1.recepient_email_cc separator ',')
                ) + 1
            ) AS recepient_email_cc,
            t1.ci_notfn_id AS CINotificationId,
            t1.ci_last_notified_on AS CILastNotifiedOn,
            t1.ci_notification_reminder_required AS CINotificationReminderRequired
        from
            (
                select
                    ci_hry.ci_id AS ci_id,
                    ci_hry.ci_name AS ci_name,
                    ci_hry.alias_name AS alias_name,
                    ci_hry.ci_short_description AS ci_short_description,
                    ci_hry.subcategory AS subcategory,
                    ci_hry.install_status AS install_status,
                    ci_hry.tpo AS tpo,
                    ci_hry.tpm AS tpm,
                    ci_hry.aat_name AS aat_name,
                    ci_hry.funding_portfolio_id AS funding_portfolio_id,
                    case
                        when ci_hry.funding_portfolio_id is null then 'Funding portfolio not defined'
                        else ci_hry.funding_portfolio_name
                    end AS funding_portfolio,
                    ci_hry.delivery_portfolio_id AS delivery_portfolio_id,
                    ci_hry.delivery_portfolio_name AS delivery_portfolio,
                    case
                        when ci_hry.is_ci_vendor_product = 'Y' then 'Vendor'
                        else 'InHouse'
                    end AS ci_venor_inhouse,
                    ci_hry.vendor_name AS vendor_name,
                    ci_hry.ci_created_on AS ci_created_on,
                    ci_hry.ci_tier AS ci_tier,
                    group_concat (distinct dlv_hry.email separator ',') AS recepient_email_to,
                    '' AS recepient_email_cc,
                    (
                        select
                            ci_notfn.id
                        from
                            bb_mst_ci_notfn_history ci_notfn
                        where
                            ci_notfn.ci_id = ci_hry.ci_id
                        order by
                            ci_notfn.created_on desc
                        limit
                            1
                    ) AS ci_notfn_id,
                    (
                        select
                            ci_notfn.notified_on
                        from
                            bb_mst_ci_notfn_history ci_notfn
                        where
                            ci_notfn.ci_id = ci_hry.ci_id
                        order by
                            ci_notfn.created_on desc
                        limit
                            1
                    ) AS ci_last_notified_on,
                    (
                        select
                            ci_notfn.reminder_required
                        from
                            bb_mst_ci_notfn_history ci_notfn
                        where
                            ci_notfn.ci_id = ci_hry.ci_id
                        order by
                            ci_notfn.created_on desc
                        limit
                            1
                    ) AS ci_notification_reminder_required
                from
                    (
                        bb_vw_dashboard_product_ci_hry ci_hry
                        left join bb_vw_user_team_aat_portfolio_hry dlv_hry on (
                            dlv_hry.delivery_portfolio_id = ci_hry.delivery_portfolio_id
                            and dlv_hry.job_title in (
                                'TECHNICAL PRODUCT OWNER',
                                'TECHNICAL PRODUCT MANAGER',
                                'SENIOR TECHNICAL PRODUCT OWNER',
                                'ASSOCIATE TECHNICAL PRODUCT OWNER',
                                'MANAGER TECHNICAL PRODUCT PORTFOLIO'
                            )
                            and dlv_hry.date_of_leaving is null
                        )
                    )
                where
                    ci_hry.ci_created_on > date_format (sysdate () - interval 10 day, '%Y-%m-%d')
                    and ci_hry.install_status <> 'Decommissioned'
                    and ci_hry.delivery_portfolio_name not in (
                        'Data Programme',
                        'Enterprise Technology',
                        'Delivery portfolio not defined'
                    )
                group by
                    ci_hry.ci_name,
                    ci_hry.alias_name,
                    ci_hry.ci_short_description,
                    ci_hry.subcategory,
                    ci_hry.install_status,
                    ci_hry.tpo,
                    ci_hry.tpm,
                    ci_hry.aat_name,
                    ci_hry.funding_portfolio_id,
                    ci_hry.funding_portfolio_name,
                    ci_hry.delivery_portfolio_id,
                    ci_hry.delivery_portfolio_name,
                    ci_hry.is_ci_vendor_product,
                    ci_hry.vendor_name,
                    ci_hry.ci_created_on,
                    ci_hry.ci_tier,
                    (
                        select
                            ci_notfn.id
                        from
                            bb_mst_ci_notfn_history ci_notfn
                        where
                            ci_notfn.ci_id = ci_hry.ci_id
                        order by
                            ci_notfn.created_on desc
                        limit
                            1
                    ),
                    (
                        select
                            ci_notfn.notified_on
                        from
                            bb_mst_ci_notfn_history ci_notfn
                        where
                            ci_notfn.ci_id = ci_hry.ci_id
                        order by
                            ci_notfn.created_on desc
                        limit
                            1
                    ),
                    (
                        select
                            ci_notfn.reminder_required
                        from
                            bb_mst_ci_notfn_history ci_notfn
                        where
                            ci_notfn.ci_id = ci_hry.ci_id
                        order by
                            ci_notfn.created_on desc
                        limit
                            1
                    )
                union
                select
                    ci_hry.ci_id AS ci_id,
                    ci_hry.ci_name AS ci_name,
                    ci_hry.alias_name AS alias_name,
                    ci_hry.ci_short_description AS ci_short_description,
                    ci_hry.subcategory AS subcategory,
                    ci_hry.install_status AS install_status,
                    ci_hry.tpo AS tpo,
                    ci_hry.tpm AS tpm,
                    ci_hry.aat_name AS aat_name,
                    ci_hry.funding_portfolio_id AS funding_portfolio_id,
                    case
                        when ci_hry.funding_portfolio_id is null then 'Funding portfolio not defined'
                        else ci_hry.funding_portfolio_name
                    end AS funding_portfolio,
                    ci_hry.delivery_portfolio_id AS delivery_portfolio_id,
                    ci_hry.delivery_portfolio_name AS delivery_portfolio,
                    case
                        when ci_hry.is_ci_vendor_product = 'Y' then 'Vendor'
                        else 'InHouse'
                    end AS ci_venor_inhouse,
                    ci_hry.vendor_name AS vendor_name,
                    ci_hry.ci_created_on AS ci_created_on,
                    ci_hry.ci_tier AS ci_tier,
                    '' AS recepient_email_to,
                    group_concat (distinct fd_hry.email separator ',') AS recepient_email_cc,
                    (
                        select
                            ci_notfn.id
                        from
                            bb_mst_ci_notfn_history ci_notfn
                        where
                            ci_notfn.ci_id = ci_hry.ci_id
                        order by
                            ci_notfn.created_on desc
                        limit
                            1
                    ) AS ci_notfn_id,
                    (
                        select
                            ci_notfn.notified_on
                        from
                            bb_mst_ci_notfn_history ci_notfn
                        where
                            ci_notfn.ci_id = ci_hry.ci_id
                        order by
                            ci_notfn.created_on desc
                        limit
                            1
                    ) AS ci_last_notified_on,
                    (
                        select
                            ci_notfn.reminder_required
                        from
                            bb_mst_ci_notfn_history ci_notfn
                        where
                            ci_notfn.ci_id = ci_hry.ci_id
                        order by
                            ci_notfn.created_on desc
                        limit
                            1
                    ) AS ci_notification_reminder_required
                from
                    (
                        bb_vw_dashboard_product_ci_hry ci_hry
                        left join bb_vw_user_team_aat_portfolio_hry fd_hry on (
                            fd_hry.delivery_portfolio_id = ci_hry.funding_portfolio_id
                            and fd_hry.job_title in (
                                'TECHNICAL PRODUCT OWNER',
                                'TECHNICAL PRODUCT MANAGER',
                                'SENIOR TECHNICAL PRODUCT OWNER',
                                'ASSOCIATE TECHNICAL PRODUCT OWNER',
                                'MANAGER TECHNICAL PRODUCT PORTFOLIO'
                            )
                            and fd_hry.date_of_leaving is null
                        )
                    )
                where
                    ci_hry.ci_created_on > date_format (sysdate () - interval 10 day, '%Y-%m-%d')
                    and ci_hry.install_status <> 'Decommissioned'
                    and ci_hry.delivery_portfolio_name not in (
                        'Data Programme',
                        'Enterprise Technology',
                        'Delivery portfolio not defined'
                    )
                group by
                    ci_hry.ci_name,
                    ci_hry.alias_name,
                    ci_hry.ci_short_description,
                    ci_hry.subcategory,
                    ci_hry.install_status,
                    ci_hry.tpo,
                    ci_hry.tpm,
                    ci_hry.aat_name,
                    ci_hry.funding_portfolio_id,
                    ci_hry.funding_portfolio_name,
                    ci_hry.delivery_portfolio_id,
                    ci_hry.delivery_portfolio_name,
                    ci_hry.is_ci_vendor_product,
                    ci_hry.vendor_name,
                    ci_hry.ci_created_on,
                    ci_hry.ci_tier,
                    (
                        select
                            ci_notfn.id
                        from
                            bb_mst_ci_notfn_history ci_notfn
                        where
                            ci_notfn.ci_id = ci_hry.ci_id
                        order by
                            ci_notfn.created_on desc
                        limit
                            1
                    ),
                    (
                        select
                            ci_notfn.notified_on
                        from
                            bb_mst_ci_notfn_history ci_notfn
                        where
                            ci_notfn.ci_id = ci_hry.ci_id
                        order by
                            ci_notfn.created_on desc
                        limit
                            1
                    ),
                    (
                        select
                            ci_notfn.reminder_required
                        from
                            bb_mst_ci_notfn_history ci_notfn
                        where
                            ci_notfn.ci_id = ci_hry.ci_id
                        order by
                            ci_notfn.created_on desc
                        limit
                            1
                    )
            ) t1
        group by
            t1.ci_name,
            t1.ci_short_description,
            t1.funding_portfolio,
            t1.delivery_portfolio,
            t1.aat_name,
            t1.tpm,
            t1.tpo,
            t1.ci_venor_inhouse,
            t1.vendor_name,
            t1.install_status,
            t1.ci_tier,
            t1.ci_created_on,
            t1.ci_notfn_id,
            t1.ci_last_notified_on,
            t1.ci_notification_reminder_required
    ) t2
order by
    t2.FundingPortfolio,
    t2.DeliveryPortfolio,
    t2.AppCIName;