CREATE VIEW
    bb_vw_product_tier AS
select
    t1.product_id AS product_id,
    t1.product_name AS product_name,
    t1.product_l1_capability_id AS product_l1_capability_id,
    t1.product_l1_capability AS product_l1_capability,
    t1.product_tier AS product_tier,
    t1.product_status AS product_status,
    (
        select
            bmt.tier_weightage
        from
            bb_mst_tier bmt
        where
            bmt.tier_name = t1.product_tier
    ) AS tier_weightage,
    t1.product_vendor_indicator AS product_vendor_indicator
from
    (
        select
            mp.id AS product_id,
            mp.product_name AS product_name,
            mp.capability_id AS product_l1_capability_id,
            l1.capability_name AS product_l1_capability,
            case
                when (
                    select
                        count(1)
                    from
                        (
                            bb_mst_ci mci
                            join bb_mst_tier tier on (mci.tier_id = tier.id)
                        )
                    where
                        mci.subproduct_id in (
                            select
                                bms.id
                            from
                                bb_mst_subproduct bms
                            where
                                bms.product_id = mp.id
                        )
                        and tier.tier_name = 'Tier 1'
                        and mci.is_platinum_ci = 'Y'
                ) > 0 then 'Tier 1 - Platinum'
                when (
                    select
                        count(1)
                    from
                        (
                            bb_mst_ci mci
                            join bb_mst_tier tier on (mci.tier_id = tier.id)
                        )
                    where
                        mci.subproduct_id in (
                            select
                                bms.id
                            from
                                bb_mst_subproduct bms
                            where
                                bms.product_id = mp.id
                        )
                        and tier.tier_name = 'Tier 1'
                        and mci.is_platinum_ci = 'N'
                ) > 0 then 'Tier 1'
                when (
                    select
                        count(1)
                    from
                        (
                            bb_mst_ci mci
                            join bb_mst_tier tier on (mci.tier_id = tier.id)
                        )
                    where
                        mci.subproduct_id in (
                            select
                                bms.id
                            from
                                bb_mst_subproduct bms
                            where
                                bms.product_id = mp.id
                        )
                        and tier.tier_name = 'Tier 2'
                ) > 0 then 'Tier 2'
                when (
                    select
                        count(1)
                    from
                        (
                            bb_mst_ci mci
                            join bb_mst_tier tier on (mci.tier_id = tier.id)
                        )
                    where
                        mci.subproduct_id in (
                            select
                                bms.id
                            from
                                bb_mst_subproduct bms
                            where
                                bms.product_id = mp.id
                        )
                        and tier.tier_name = 'Tier 3'
                ) > 0 then 'Tier 3'
            end AS product_tier,
            mp.status AS product_status,
            (
                select
                    case
                        when group_concat (distinct mci.is_ci_vendor_product separator ',') = 'N,Y'
                        or group_concat (distinct mci.is_ci_vendor_product separator ',') = 'Y,N' then 'Mix'
                        when group_concat (distinct mci.is_ci_vendor_product separator ',') = 'N' then 'Inhouse'
                        when group_concat (distinct mci.is_ci_vendor_product separator ',') = 'Y' then 'Vendor'
                    end AS vendor_indicator
                from
                    bb_mst_ci mci
                where
                    mci.subproduct_id in (
                        select
                            bms.id
                        from
                            bb_mst_subproduct bms
                        where
                            bms.product_id = mp.id
                    )
            ) AS product_vendor_indicator
        from
            (
                bb_mst_product mp
                left join bb_mst_capability l1 on (l1.id = mp.capability_id)
            )
        order by
            mp.id,
            case
                when (
                    select
                        count(1)
                    from
                        (
                            bb_mst_ci mci
                            join bb_mst_tier tier on (mci.tier_id = tier.id)
                        )
                    where
                        mci.subproduct_id in (
                            select
                                bms.id
                            from
                                bb_mst_subproduct bms
                            where
                                bms.product_id = mp.id
                        )
                        and tier.tier_name = 'Tier 1'
                        and mci.is_platinum_ci = 'Y'
                ) > 0 then 'Tier 1 - Platinum'
                when (
                    select
                        count(1)
                    from
                        (
                            bb_mst_ci mci
                            join bb_mst_tier tier on (mci.tier_id = tier.id)
                        )
                    where
                        mci.subproduct_id in (
                            select
                                bms.id
                            from
                                bb_mst_subproduct bms
                            where
                                bms.product_id = mp.id
                        )
                        and tier.tier_name = 'Tier 1'
                        and mci.is_platinum_ci = 'N'
                ) > 0 then 'Tier 1'
                when (
                    select
                        count(1)
                    from
                        (
                            bb_mst_ci mci
                            join bb_mst_tier tier on (mci.tier_id = tier.id)
                        )
                    where
                        mci.subproduct_id in (
                            select
                                bms.id
                            from
                                bb_mst_subproduct bms
                            where
                                bms.product_id = mp.id
                        )
                        and tier.tier_name = 'Tier 2'
                ) > 0 then 'Tier 2'
                when (
                    select
                        count(1)
                    from
                        (
                            bb_mst_ci mci
                            join bb_mst_tier tier on (mci.tier_id = tier.id)
                        )
                    where
                        mci.subproduct_id in (
                            select
                                bms.id
                            from
                                bb_mst_subproduct bms
                            where
                                bms.product_id = mp.id
                        )
                        and tier.tier_name = 'Tier 3'
                ) > 0 then 'Tier 3'
            end
    ) t1;