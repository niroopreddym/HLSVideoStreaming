CREATE VIEW
    bb_vw_product_hry AS
select
    ci.id AS ci_id,
    ci.alias_name AS ci_alias_name,
    ci.ci_name AS ci_name,
    group_concat (distinct ci.ci_name separator ',') AS ci_name_CommaSeparated,
    ci.parent_ci_id AS parent_ci_id,
    ci.subproduct_id AS ci_subproduct_id,
    spr.subproduct_desc AS subproduct_desc,
    group_concat (distinct spr.subproduct_desc separator ',') AS suproduct_name_CommaSeparated,
    ci.subcategory AS subcategory,
    bu.id AS business_unit_id,
    bu.business_unit_name AS business_unit,
    group_concat (distinct bu.business_unit_name separator ',') AS business_unit_name_CommaSeparated,
    group_concat (distinct bu.id separator ',') AS business_unit_id_CommaSeparated,
    octet_length(
        group_concat (distinct bu.business_unit_name separator ',')
    ) - octet_length(
        replace (
            group_concat (distinct bu.business_unit_name separator ','),
            ',',
            ''
        )
    ) AS business_unit_name_CommaSeparated_exist,
    spr.capability_id AS subproduct_capability_id,
    spr.subproduct_code AS subproduct_code,
    spr.subproduct_name AS subproduct_name,
    spr.id AS subproduct_id,
    pr.id AS product_id,
    pr.capability_id AS product_capability_id,
    capilty.capability_name AS product_business_capability_name,
    pr.product_code AS product_code,
    pr.product_name AS product_name,
    pr.product_ownr AS product_ownr,
    pr.product_desc AS product_desc,
    pr.type AS TYPE,
    ci.aat_id AS aat_id,
    aat.aat_name AS aat_name,
    ifnull (
        ci.funding_portfolio_id,
        aat.delivery_portfolio_id
    ) AS funding_portfolio_id,
    ifnull (pf.portfolio_desc, dpf.portfolio_desc) AS funding_portfolio_name,
    group_concat (
        distinct ifnull (pf.portfolio_desc, dpf.portfolio_desc) separator ','
    ) AS funding_portfolio_name_CommaSeparated,
    group_concat (
        distinct ifnull (
            ci.funding_portfolio_id,
            aat.delivery_portfolio_id
        ) separator ','
    ) AS funding_portfolio_id_CommaSeparated,
    octet_length(
        group_concat (
            distinct ifnull (pf.portfolio_desc, dpf.portfolio_desc) separator ','
        )
    ) - octet_length(
        replace (
            group_concat (
                distinct ifnull (pf.portfolio_desc, dpf.portfolio_desc) separator ','
            ),
            ',',
            ''
        )
    ) AS funding_portfolio_name_CommaSeparated_exist,
    ci.team_id AS team_id,
    ci.tier_id AS Tier,
    tier.tier_name AS tier_name,
    ci.is_ci_vendor_product AS is_ci_vendor_product,
    ci.vendor AS vendor_name,
    group_concat (distinct ci.vendor separator ',') AS vendor_name_CommaSeparated,
    aat.delivery_portfolio_id AS delivery_portfolio_id,
    dpf.portfolio_desc AS delivery_portfolio_name,
    group_concat (distinct dpf.portfolio_desc separator ',') AS delivery_portfolio_name_CommaSeparated,
    group_concat (distinct dpf.id separator ',') AS delivery_portfolio_id_CommaSeparated,
    octet_length(
        group_concat (distinct dpf.portfolio_desc separator ',')
    ) - octet_length(
        replace (
            group_concat (distinct dpf.portfolio_desc separator ','),
            ',',
            ''
        )
    ) AS delivery_portfolio_name_CommaSeparated_exist,
    ci.technical_product_owner AS tpo,
    ci.technical_product_manager AS tpm,
    group_concat (
        distinct ci.technical_product_manager separator ','
    ) AS tpm_name_CommaSeparated,
    group_concat (distinct ci.technical_product_owner separator ',') AS tpo_name_CommaSeparated,
    count(distinct ci.ci_name) AS NoOfAppCIs,
    count(distinct spr.id) AS NoOfSubproducts,
    (
        select
            bb_vw_dashboard_product_ci_hry.product_id
        from
            bb_vw_dashboard_product_ci_hry
        where
            bb_vw_dashboard_product_ci_hry.ci_id = ci.parent_ci_id
    ) AS parent_ci_product_id
from
    (
        (
            (
                (
                    (
                        (
                            (
                                (
                                    bb_mst_product pr
                                    left join bb_mst_subproduct spr on (spr.product_id = pr.id)
                                )
                                left join bb_mst_ci ci on (ci.subproduct_id = spr.id)
                            )
                            left join bb_mst_portfolio pf on (ci.funding_portfolio_id = pf.id)
                        )
                        left join bb_mst_aat aat on (ci.aat_id = aat.id)
                    )
                    left join bb_mst_business_unit bu on (spr.business_unit_id = bu.id)
                )
                left join bb_mst_tier tier on (ci.tier_id = tier.id)
            )
            left join bb_mst_capability capilty on (pr.capability_id = capilty.id)
        )
        left join bb_mst_portfolio dpf on (aat.delivery_portfolio_id = dpf.id)
    )
group by
    pr.id;