CREATE VIEW
    bb_vw_api_product_catalogue AS
select
    t1.product_id AS product_id,
    t1.product_code AS product_code,
    t1.product_name AS product_name,
    t1.product_desc AS product_desc,
    t1.product_business_capability AS product_business_capability,
    t1.product_tpm AS product_tpm,
    t1.product_tpo AS product_tpo,
    t1.product_type AS product_type,
    t1.product_status AS product_status,
    t1.product_created_on AS product_created_on,
    t1.product_modified_on AS product_modified_on,
    t1.subproduct_id AS subproduct_id,
    t1.subproduct_code AS subproduct_code,
    t1.subproduct_name AS subproduct_name,
    t1.subproduct_desc AS subproduct_desc,
    t1.subproduct_business_capability AS subproduct_business_capability,
    t1.subproduct_business_unit AS subproduct_business_unit,
    t1.subproduct_tpm AS subproduct_tpm,
    t1.subproduct_tpo AS subproduct_tpo,
    t1.subproduct_status AS subproduct_status,
    t1.subproduct_created_on AS subproduct_created_on,
    t1.subproduct_modified_on AS subproduct_modified_on,
    t1.ci_name AS ci_name,
    t1.cmdb_ci_sys_id AS cmdb_ci_sys_id,
    t1.ci_subproduct_id AS ci_subproduct_id,
    t1.ci_install_status AS ci_install_status,
    t1.ci_created_on AS ci_created_on,
    t1.ci_modified_on AS ci_modified_on,
    t1.ci_mapping_modified_on AS ci_mapping_modified_on
from
    (
        select
            bmp.id AS product_id,
            bmp.product_code AS product_code,
            bmp.product_name AS product_name,
            bmp.product_desc AS product_desc,
            l1_bmcp.capability_name AS product_business_capability,
            bmp.technical_product_manager AS product_tpm,
            bmp.technical_product_owner AS product_tpo,
            bmp.type AS product_type,
            bmp.status AS product_status,
            bmp.created_on AS product_created_on,
            bmp.modified_on AS product_modified_on,
            bmsp.id AS subproduct_id,
            bmsp.subproduct_code AS subproduct_code,
            bmsp.subproduct_name AS subproduct_name,
            bmsp.subproduct_desc AS subproduct_desc,
            l2_bmcp.capability_name AS subproduct_business_capability,
            bmbu.business_unit_name AS subproduct_business_unit,
            bmsp.technical_product_manager AS subproduct_tpm,
            bmsp.technical_product_owner AS subproduct_tpo,
            bmsp.status AS subproduct_status,
            bmsp.created_on AS subproduct_created_on,
            bmsp.modified_on AS subproduct_modified_on,
            ci.ci_name AS ci_name,
            ci.sys_id AS cmdb_ci_sys_id,
            ci.subproduct_id AS ci_subproduct_id,
            ci.install_status AS ci_install_status,
            ci.created_on AS ci_created_on,
            ci.modified_on AS ci_modified_on,
            ci.ci_mapping_modified_on AS ci_mapping_modified_on
        from
            (
                (
                    (
                        (
                            (
                                bb_mst_product bmp
                                left join bb_mst_capability l1_bmcp on (l1_bmcp.id = bmp.capability_id)
                            )
                            left join bb_mst_subproduct bmsp on (bmsp.product_id = bmp.id)
                        )
                        left join bb_mst_capability l2_bmcp on (l2_bmcp.id = bmsp.capability_id)
                    )
                    left join bb_mst_business_unit bmbu on (bmbu.id = bmsp.business_unit_id)
                )
                left join bb_mst_ci ci on (ci.subproduct_id = bmsp.id)
            )
        union
        select
            bmp.id AS product_id,
            ifnull (bmp.product_code, 'PRDCTNTDFND0001') AS product_code,
            ifnull (bmp.product_name, 'Product not defined') AS product_name,
            bmp.product_desc AS product_desc,
            l1_bmcp.capability_name AS product_business_capability,
            bmp.technical_product_manager AS product_tpm,
            bmp.technical_product_owner AS product_tpo,
            bmp.type AS product_type,
            bmp.status AS product_status,
            bmp.created_on AS product_created_on,
            bmp.modified_on AS product_modified_on,
            bmsp.id AS subproduct_id,
            ifnull (bmsp.subproduct_code, 'SUBPRDCTNTDFND0002') AS subproduct_code,
            ifnull (bmsp.subproduct_name, 'Subproduct not defined') AS subproduct_name,
            bmsp.subproduct_desc AS subproduct_desc,
            l2_bmcp.capability_name AS subproduct_business_capability,
            bmbu.business_unit_name AS subproduct_business_unit,
            bmsp.technical_product_manager AS subproduct_tpm,
            bmsp.technical_product_owner AS subproduct_tpo,
            bmsp.status AS subproduct_status,
            bmsp.created_on AS subproduct_created_on,
            bmsp.modified_on AS subproduct_modified_on,
            ci.ci_name AS ci_name,
            ci.sys_id AS cmdb_ci_sys_id,
            ci.subproduct_id AS ci_subproduct_id,
            ci.install_status AS ci_install_status,
            ci.created_on AS ci_created_on,
            ci.modified_on AS ci_modified_on,
            ci.ci_mapping_modified_on AS ci_mapping_modified_on
        from
            (
                bb_mst_ci ci
                left join (
                    (
                        (
                            (
                                bb_mst_product bmp
                                left join bb_mst_capability l1_bmcp on (l1_bmcp.id = bmp.capability_id)
                            )
                            left join bb_mst_subproduct bmsp on (bmsp.product_id = bmp.id)
                        )
                        left join bb_mst_capability l2_bmcp on (l2_bmcp.id = bmsp.capability_id)
                    )
                    left join bb_mst_business_unit bmbu on (bmbu.id = bmsp.business_unit_id)
                ) on (ci.subproduct_id = bmsp.id)
            )
    ) t1
group by
    t1.product_id,
    t1.product_code,
    t1.product_name,
    t1.subproduct_id,
    t1.subproduct_code,
    t1.subproduct_name,
    t1.ci_name,
    t1.cmdb_ci_sys_id;