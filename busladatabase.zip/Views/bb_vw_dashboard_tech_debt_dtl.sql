CREATE VIEW
    bb_vw_dashboard_tech_debt_dtl AS
select
    tech_debt.app_ci_id AS app_ci_id,
    tech_debt.application AS application,
    tech_debt.app_tier AS app_tier,
    tech_debt.sub_category AS sub_category,
    tech_debt.technical_ci_name AS technical_ci_name,
    tech_debt.secondary_ci_sys_id AS secondary_ci_sys_id,
    tech_debt.secondary_ci_name AS secondary_ci_name,
    tech_debt.created_on AS created_on,
    tech_debt.state AS state,
    tech_debt.state_changed_on AS state_changed_on,
    tech_debt.Tech_Severity AS Tech_Severity,
    tech_debt.Tech_Score AS Tech_Score,
    tech_debt.EOL_Severity AS EOL_Severity,
    tech_debt.EOL_Score AS EOL_Score,
    tech_debt.install_status AS install_status,
    tech_debt.Install_Score AS Install_Score
from
    (
        select
            tech_debt.u_sub_category AS sub_category,
            tech_debt.u_application AS app_sys_id,
            app.id AS app_ci_id,
            app.ci_name AS application,
            (
                select
                    bmt.tier_name
                from
                    bb_mst_tier bmt
                where
                    bmt.id = app.tier_id
            ) AS app_tier,
            tech_debt.u_technical_ci AS technical_ci_sys_id,
            tech_app.name AS technical_ci_name,
            date_format (tech_debt.sys_created_on, '%Y-%m-%d') AS created_on,
            tech_debt.state AS state,
            date_format (tech_debt.sys_updated_on, '%Y-%m-%d') AS state_changed_on,
            case
                when tech_app.name in (
                    select
                        bmcm.entity_val
                    from
                        bb_mst_common_master bmcm
                    where
                        bmcm.entity = 'TECH_DEBT'
                        and bmcm.entity_code = 'CRITICAL_TECH_COMPONENT'
                ) then 'Critical'
                else 'Not Critical'
            end AS Tech_Severity,
            (
                select
                    bmcm.entity_val
                from
                    bb_mst_common_master bmcm
                where
                    bmcm.entity = 'TECH_DEBT_TECH_SCORE'
                    and bmcm.entity_code = case
                        when tech_app.name in (
                            select
                                bmcm.entity_val
                            from
                                bb_mst_common_master bmcm
                            where
                                bmcm.entity = 'TECH_DEBT'
                                and bmcm.entity_code = 'CRITICAL_TECH_COMPONENT'
                        ) then 'Critical'
                        else 'Not Critical'
                    end
            ) AS Tech_Score,
            ifnull (tech_debt.u_severity, 'Low') AS EOL_Severity,
            (
                select
                    bmcm.entity_val
                from
                    bb_mst_common_master bmcm
                where
                    bmcm.entity = 'TECH_DEBT_EOL_SCORE'
                    and bmcm.entity_code = ifnull (tech_debt.u_severity, 'Low')
            ) AS EOL_Score,
            secondary_ci.install_status AS install_status,
            (
                select
                    bmcm.entity_val
                from
                    bb_mst_common_master bmcm
                where
                    bmcm.entity = 'TECH_DEBT_INSTALL_SCORE'
                    and bmcm.entity_code = secondary_ci.install_status
            ) AS Install_Score,
            tech_debt.u_secondary_ci AS secondary_ci_sys_id,
            secondary_ci.name AS secondary_ci_name
        from
            (
                (
                    (
                        bb_prefact_snow_u_technical_debt tech_debt
                        left join bb_mst_ci app on (tech_debt.u_application = app.sys_id)
                    )
                    left join bb_prefact_snow_cmdb_ci tech_app on (tech_app.sys_id = tech_debt.u_technical_ci)
                )
                left join bb_prefact_snow_cmdb_ci secondary_ci on (secondary_ci.sys_id = tech_debt.u_secondary_ci)
            )
        where
            tech_debt.u_category = 'End of Life'
            and secondary_ci.install_status is not null
        order by
            app.ci_name,
            date_format (tech_debt.sys_created_on, '%Y-%m-%d'),
            tech_app.name
    ) tech_debt;