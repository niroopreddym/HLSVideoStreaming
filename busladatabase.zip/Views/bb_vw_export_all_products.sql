CREATE VIEW
    bb_vw_export_all_products AS
select
    pr.product_name AS Product Name,
    pr.product_desc AS Product Description,
    spr.subproduct_name AS Sub Product Name,
    spr.subproduct_desc AS Sub Product Description,
    ci.ci_name AS App CI Name,
    ci.short_description AS App CI Name Description,
    capilty.capability_name AS Business Capability,
    bu.business_unit_name AS Business Unit,
    pf.portfolio_desc AS Funding Portfolio,
    dpf.portfolio_desc AS Delivery Portfolio,
    aat.aat_desc AS AAT,
    ci.technical_product_manager AS Technical Product Manager,
    ci.technical_product_owner AS Technical Product Owner,
    ci.is_ci_vendor_product AS CI Vendor / InHouse,
    ci.vendor AS Vendor Name,
    ci.install_status AS CI Status,
    tier.tier_name AS CI Tier
from
    (
        (
            (
                (
                    (
                        (
                            (
                                (
                                    bb_mst_product pr
                                    left join bb_mst_subproduct spr on (spr.product_id = pr.id)
                                )
                                left join bb_mst_ci ci on (ci.subproduct_id = spr.id)
                            )
                            left join bb_mst_portfolio pf on (ci.funding_portfolio_id = pf.id)
                        )
                        left join bb_mst_aat aat on (ci.aat_id = aat.id)
                    )
                    left join bb_mst_business_unit bu on (spr.business_unit_id = bu.id)
                )
                left join bb_mst_tier tier on (ci.tier_id = tier.id)
            )
            left join bb_mst_capability capilty on (pr.capability_id = capilty.id)
        )
        left join bb_mst_portfolio dpf on (aat.delivery_portfolio_id = dpf.id)
    );