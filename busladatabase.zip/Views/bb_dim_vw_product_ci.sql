CREATE VIEW
    bb_dim_vw_product_ci AS
select
    ci.id AS ci_id,
    ci.ci_name AS ci_name,
    ci.parent_ci_id AS parent_ci_id,
    ci.subproduct_id AS subproduct_id,
    spr.capability_id AS subproduct_capability_id,
    spr.subproduct_code AS subproduct_code,
    spr.subproduct_name AS subproduct_name,
    pr.id AS product_id,
    pr.capability_id AS product_capability_id,
    pr.product_code AS product_code,
    pr.product_name AS product_name,
    pr.product_ownr AS product_ownr,
    pr.type AS type,
    ci.aat_id AS aat_id,
    ci.team_id AS team_id,
    ci.tier_id AS Tier
from
    (
        (
            bb_mst_ci ci
            join bb_mst_subproduct spr
        )
        join bb_mst_product pr
    )
where
    ci.subproduct_id = spr.id
    and spr.product_id = pr.id;