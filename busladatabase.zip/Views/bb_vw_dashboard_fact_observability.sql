CREATE VIEW
    bb_vw_swe_fact AS
select
    mci.id AS ci_id,
    mci.ci_name AS ci_name,
    bsf.time_id AS time_id,
    bdt.date AS txn_date,
    bds.id AS subcategory_id,
    bds.subcategory_code AS subcategory_code,
    bsf.metrics_id AS metrics_id,
    bdm.metrics_desc AS metrics_name,
    round(bsf.measure, 2) AS val_measure,
    (
        select
            scr.scale_rating
        from
            bb_map_metrics_scale_rating scr
        where
            scr.metrics_id = bsf.metrics_id
            and round(bsf.measure, 2) >= scr.scale_value_min
            and round(bsf.measure, 2) <= scr.scale_value_max
    ) AS scale_rating,
    (
        select
            scr.scale_indicator
        from
            bb_map_metrics_scale_rating scr
        where
            scr.metrics_id = bsf.metrics_id
            and round(bsf.measure, 2) >= scr.scale_value_min
            and round(bsf.measure, 2) <= scr.scale_value_max
    ) AS scale_indicator,
    brm.weightage AS metrics_weightage
from
    (
        (
            (
                (
                    (
                        bb_swe_fact bsf
                        join bb_mst_ci mci on (mci.id = bsf.ci_id)
                    )
                    join bb_dim_time bdt on (bdt.id = bsf.time_id)
                )
                join bb_dim_metrics bdm on (bdm.id = bsf.metrics_id)
            )
            join bb_dim_subcategory bds on (bds.id = bdm.subcategory_id)
        )
        join bb_rollup_metrics brm on (brm.metrics_id = bsf.metrics_id)
    )
order by
    bdt.date,
    mci.ci_name,
    bdm.metrics_desc;