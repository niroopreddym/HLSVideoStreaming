CREATE VIEW
    bb_vw_product_subproduct_ci_hry AS
select
    ci.id AS ci_id,
    ci.ci_name AS ci_name,
    ci.alias_name AS ci_alias_name,
    ci.parent_ci_id AS parent_ci_id,
    spr.id AS subproduct_id,
    bu.business_unit_name AS business_unit,
    spr.capability_id AS subproduct_capability_id,
    spr.subproduct_code AS subproduct_code,
    spr.subproduct_name AS subproduct_name,
    pr.id AS product_id,
    pr.capability_id AS product_capability_id,
    capilty.capability_name AS product_business_capability_name,
    pr.product_code AS product_code,
    pr.product_name AS product_name,
    pr.product_ownr AS product_ownr,
    pr.product_desc AS product_desc,
    pr.type AS TYPE,
    ci.aat_id AS aat_id,
    aat.aat_name AS aat_name,
    aat.aat_desc AS aat_desc,
    ci.funding_portfolio_id AS funding_portfolio_id,
    pf.portfolio_desc AS funding_portfolio_name,
    ci.team_id AS team_id,
    ci.tier_id AS Tier,
    tier.tier_name AS tier_name,
    ci.is_ci_vendor_product AS is_ci_vendor_product,
    ci.vendor AS vendor_name,
    aat.delivery_portfolio_id AS delivery_portfolio_id,
    dpf.portfolio_desc AS delivery_portfolio_name,
    ci.technical_product_owner AS tpo,
    ci.technical_product_manager AS tpm,
    case
        when group_concat (distinct ci.is_ci_vendor_product separator ',') = 'N' then 'Inhouse'
        when group_concat (distinct ci.is_ci_vendor_product separator ',') = 'Y' then group_concat (distinct ci.vendor separator ',')
        else 'Mix'
    end AS InhouseOrVendor,
    group_concat (distinct tier.tier_name separator ',') AS TierNameCommaSeparated,
    group_concat (distinct aat.aat_name separator ',') AS AATNameCommaSeparated,
    count(0) AS NoOfAppCIs
from
    (
        (
            (
                (
                    (
                        (
                            (
                                (
                                    bb_mst_product pr
                                    left join bb_mst_subproduct spr on (spr.product_id = pr.id)
                                )
                                left join bb_mst_ci ci on (ci.subproduct_id = spr.id)
                            )
                            left join bb_mst_portfolio pf on (ci.funding_portfolio_id = pf.id)
                        )
                        left join bb_mst_aat aat on (ci.aat_id = aat.id)
                    )
                    left join bb_mst_business_unit bu on (spr.business_unit_id = bu.id)
                )
                left join bb_mst_tier tier on (ci.tier_id = tier.id)
            )
            left join bb_mst_capability capilty on (pr.capability_id = capilty.id)
        )
        left join bb_mst_portfolio dpf on (aat.delivery_portfolio_id = dpf.id)
    )
group by
    ci.subproduct_id,
    pr.id,
    spr.product_id,
    spr.id;