CREATE DEFINER VIEW bb_vw_pc_product_list AS
select
    t1.product_id AS product_id,
    t1.product_code AS product_code,
    t1.product_name AS product_name,
    t1.product_desc AS product_desc,
    t1.product_capability_id AS product_capability_id,
    t1.product_business_capability_name AS product_business_capability_name,
    t1.business_unit_name_CommaSeperated AS business_unit_name_CommaSeperated,
    t1.business_unit_name_CommaSeperated_exist AS business_unit_name_CommaSeperated_exist,
    t1.funding_portfolio_name_CommaSeperated AS funding_portfolio_name_CommaSeperated,
    t1.funding_portfolio_name_CommaSeperated_exist AS funding_portfolio_name_CommaSeperated_exist,
    t1.delivery_portfolio_name_CommaSeperated AS delivery_portfolio_name_CommaSeperated,
    t1.delivery_portfolio_name_CommaSeperated_exist AS delivery_portfolio_name_CommaSeperated_exist,
    t1.tier_name AS tier_name,
    t1.product_status AS product_status,
    t1.product_vendor_indicator AS product_vendor_indicator,
    t1.aat_names AS aat_names,
    t1.subproduct_name_CommaSeperated AS subproduct_name_CommaSeperated,
    t1.ci_name_CommaSeperated AS ci_name_CommaSeperated,
    t1.tpo_name_CommaSeperated AS tpo_name_CommaSeperated,
    t1.tpm_name_CommaSeperated AS tpm_name_CommaSeperated,
    t1.vendor_name_CommaSeperated AS vendor_name_CommaSeperated,
    t1.NoOfSubproducts AS NoOfSubproducts,
    t1.NoOfAppCIs AS NoOfAppCIs
from
    (
        select
            mp.id AS product_id,
            mp.product_code AS product_code,
            mp.product_name AS product_name,
            mp.product_desc AS product_desc,
            mp.capability_id AS product_capability_id,
            l1.capability_name AS product_business_capability_name,
            (
                select
                    group_concat (distinct bmu.business_unit_name separator ', ')
                from
                    bb_mst_business_unit bmu
                where
                    bmu.id in (
                        select
                            bmsp.business_unit_id
                        from
                            bb_mst_subproduct bmsp
                        where
                            bmsp.product_id = mp.id
                    )
            ) AS business_unit_name_CommaSeperated,
            (
                select
                    octet_length(
                        group_concat (distinct bmu.business_unit_name separator ', ')
                    ) - octet_length(
                        replace (
                            group_concat (distinct bmu.business_unit_name separator ', '),
                            ',',
                            ''
                        )
                    )
                from
                    bb_mst_business_unit bmu
                where
                    bmu.id in (
                        select
                            bmsp.business_unit_id
                        from
                            bb_mst_subproduct bmsp
                        where
                            bmsp.product_id = mp.id
                    )
            ) AS business_unit_name_CommaSeperated_exist,
            (
                select
                    group_concat (distinct bmpf.portfolio_desc separator ', ')
                from
                    bb_mst_portfolio bmpf
                where
                    bmpf.id in (
                        select
                            mci.funding_portfolio_id
                        from
                            bb_mst_ci mci
                        where
                            mci.subproduct_id in (
                                select
                                    bms.id
                                from
                                    bb_mst_subproduct bms
                                where
                                    bms.product_id = mp.id
                            )
                    )
            ) AS funding_portfolio_name_CommaSeperated,
            (
                select
                    octet_length(
                        group_concat (distinct bmpf.portfolio_desc separator ', ')
                    ) - octet_length(
                        replace (
                            group_concat (distinct bmpf.portfolio_desc separator ', '),
                            ',',
                            ''
                        )
                    )
                from
                    bb_mst_portfolio bmpf
                where
                    bmpf.id in (
                        select
                            mci.funding_portfolio_id
                        from
                            bb_mst_ci mci
                        where
                            mci.subproduct_id in (
                                select
                                    bms.id
                                from
                                    bb_mst_subproduct bms
                                where
                                    bms.product_id = mp.id
                            )
                    )
            ) AS funding_portfolio_name_CommaSeperated_exist,
            (
                select
                    group_concat (distinct bmpf.portfolio_desc separator ', ')
                from
                    bb_mst_portfolio bmpf
                where
                    bmpf.id in (
                        select
                            bma.delivery_portfolio_id
                        from
                            bb_mst_aat bma
                        where
                            bma.id in (
                                select
                                    mci.aat_id
                                from
                                    bb_mst_ci mci
                                where
                                    mci.subproduct_id in (
                                        select
                                            bms.id
                                        from
                                            bb_mst_subproduct bms
                                        where
                                            bms.product_id = mp.id
                                    )
                            )
                    )
            ) AS delivery_portfolio_name_CommaSeperated,
            (
                select
                    octet_length(
                        group_concat (distinct bmpf.portfolio_desc separator ', ')
                    ) - octet_length(
                        replace (
                            group_concat (distinct bmpf.portfolio_desc separator ', '),
                            ',',
                            ''
                        )
                    )
                from
                    bb_mst_portfolio bmpf
                where
                    bmpf.id in (
                        select
                            bma.delivery_portfolio_id
                        from
                            bb_mst_aat bma
                        where
                            bma.id in (
                                select
                                    mci.aat_id
                                from
                                    bb_mst_ci mci
                                where
                                    mci.subproduct_id in (
                                        select
                                            bms.id
                                        from
                                            bb_mst_subproduct bms
                                        where
                                            bms.product_id = mp.id
                                    )
                            )
                    )
            ) AS delivery_portfolio_name_CommaSeperated_exist,
            (
                select
                    case
                        when locate (
                            ',',
                            group_concat (distinct tier.tier_name separator ',')
                        ) > 0 then 'Mix'
                        else group_concat (distinct tier.tier_name separator ',')
                    end AS tier_indicator
                from
                    bb_mst_tier tier
                where
                    tier.id in (
                        select
                            mci.tier_id
                        from
                            bb_mst_ci mci
                        where
                            mci.subproduct_id in (
                                select
                                    bms.id
                                from
                                    bb_mst_subproduct bms
                                where
                                    bms.product_id = mp.id
                            )
                    )
            ) AS tier_name,
            mp.status AS product_status,
            (
                select
                    case
                        when locate (
                            ',',
                            group_concat (distinct mci.is_ci_vendor_product separator ',')
                        ) > 0 then 'Mix'
                        when group_concat (distinct mci.is_ci_vendor_product separator ',') = 'N' then 'Inhouse'
                        when group_concat (distinct mci.is_ci_vendor_product separator ',') = 'Y' then 'Vendor'
                    end AS vendor_indicator
                from
                    bb_mst_ci mci
                where
                    mci.subproduct_id in (
                        select
                            bms.id
                        from
                            bb_mst_subproduct bms
                        where
                            bms.product_id = mp.id
                    )
            ) AS product_vendor_indicator,
            (
                select
                    group_concat (distinct bma.aat_name separator ', ') AS aat_names
                from
                    (
                        bb_mst_ci bmc
                        left join bb_mst_aat bma on (bma.id = bmc.aat_id)
                    )
                where
                    bmc.subproduct_id in (
                        select
                            bmsp.id
                        from
                            bb_mst_subproduct bmsp
                        where
                            bmsp.product_id = mp.id
                    )
            ) AS aat_names,
            (
                select
                    group_concat (distinct bmsp.subproduct_name separator ', ')
                from
                    bb_mst_subproduct bmsp
                where
                    bmsp.product_id = mp.id
            ) AS subproduct_name_CommaSeperated,
            (
                select
                    group_concat (distinct mci.ci_name separator ', ')
                from
                    bb_mst_ci mci
                where
                    mci.subproduct_id in (
                        select
                            bmsp.id
                        from
                            bb_mst_subproduct bmsp
                        where
                            bmsp.product_id = mp.id
                    )
            ) AS ci_name_CommaSeperated,
            (
                select
                    group_concat (
                        distinct mci.technical_product_owner separator ', '
                    )
                from
                    bb_mst_ci mci
                where
                    mci.subproduct_id in (
                        select
                            bmsp.id
                        from
                            bb_mst_subproduct bmsp
                        where
                            bmsp.product_id = mp.id
                    )
            ) AS tpo_name_CommaSeperated,
            (
                select
                    group_concat (
                        distinct mci.technical_product_manager separator ', '
                    )
                from
                    bb_mst_ci mci
                where
                    mci.subproduct_id in (
                        select
                            bmsp.id
                        from
                            bb_mst_subproduct bmsp
                        where
                            bmsp.product_id = mp.id
                    )
            ) AS tpm_name_CommaSeperated,
            (
                select
                    group_concat (distinct mci.vendor separator ', ')
                from
                    bb_mst_ci mci
                where
                    mci.subproduct_id in (
                        select
                            bmsp.id
                        from
                            bb_mst_subproduct bmsp
                        where
                            bmsp.product_id = mp.id
                    )
            ) AS vendor_name_CommaSeperated,
            (
                select
                    count(1)
                from
                    bb_mst_subproduct bms
                where
                    bms.product_id = mp.id
            ) AS NoOfSubproducts,
            (
                select
                    count(1)
                from
                    bb_mst_ci mci
                where
                    mci.subproduct_id in (
                        select
                            bms.id
                        from
                            bb_mst_subproduct bms
                        where
                            bms.product_id = mp.id
                    )
            ) AS NoOfAppCIs
        from
            (
                bb_mst_product mp
                left join bb_mst_capability l1 on (l1.id = mp.capability_id)
            )
        order by
            mp.id,
            (
                select
                    case
                        when locate (
                            ',',
                            group_concat (distinct tier.tier_name separator ',')
                        ) > 0 then 'Mix'
                        else group_concat (distinct tier.tier_name separator ',')
                    end AS tier_indicator
                from
                    bb_mst_tier tier
                where
                    tier.id in (
                        select
                            mci.tier_id
                        from
                            bb_mst_ci mci
                        where
                            mci.subproduct_id in (
                                select
                                    bms.id
                                from
                                    bb_mst_subproduct bms
                                where
                                    bms.product_id = mp.id
                            )
                    )
            )
    ) t1;