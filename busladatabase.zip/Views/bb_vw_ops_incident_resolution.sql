CREATE VIEW 
    bb_vw_ops_incident_resolution AS 
select 
    bmc.id AS ci_id, 
    bmc.sys_id AS ci_sys_id, 
    bmc.ci_name AS ci_name, 
    bmc.subproduct_id AS subproduct_id, 
    bmc.aat_id AS aat_id, 
    bmc.funding_portfolio_id AS funding_portfolio_id, 
    bmc.is_ci_vendor_product AS is_ci_vendor_product, 
    bmc.vendor AS vendor, 
    bmc.is_platinum_ci AS is_platinum_ci, 
    bmc.decommission_date AS decommission_date, 
    date_format(task.sys_created_on, '%Y-%m-%d') AS txn_date, 
    task.number AS number, 
    task.sys_id AS task_sys_id, 
    incident.sys_id_incident AS sys_id_incident, 
    incident.sys_id_task AS sys_id_task, 
    incident.category AS incident_category, 
    incident.close_code AS incident_close_code, 
    incident.incident_state AS incident_state, 
    incident.made_sla AS incident_made_sla, 
    incident.major_incident_state AS major_incident_state, 
    incident.priority AS incident_priority, 
    incident.u_triggered_by_alert AS u_triggered_by_alert, 
    task.state AS task_state, 
    task.priority AS task_priority, 
    task.made_sla AS task_made_sla, 
    task_sla.duration AS duration, 
    task_sla.business_duration AS business_duration, 
    sla_def.duration AS sla_def_duration, 
    task_sla.has_breached AS has_breached, 
    task_sla.stage AS stage, 
    sla_def.type AS sla_type, 
    sla_def.target AS target, 
    incident.caller_id AS caller_id, 
    task_sla.start_time AS start_time, 
    task_sla.end_time AS end_time from 
(((((bb_prefact_snow_task task join bb_prefact_snow_incident incident on(incident.sys_id_incident = task.sys_id)) 
join bb_prefact_snow_task_ci task_ci on(task_ci.task_sys_id = task.sys_id)) 
join bb_prefact_snow_task_sla task_sla on(task_sla.task_sys_id = task.sys_id and task_sla.stage <> 'Cancelled')) 
join bb_prefact_snow_contract_sla sla_def on(sla_def.sys_id = task_sla.sla_sys_id and sla_def.type = 'SLA' and sla_def.target = 'Resolution')) 
join bb_mst_ci bmc on(bmc.sys_id = task_ci.ci_item_sys_id and bmc.ci_name like 'S.A%')) 
where task.sys_class_name = 'Incident' and 
date_format(task.sys_created_on,'%Y-%m-%d') between concat(year(curdate() - interval 2 year) + case when month(curdate()) >= 4 then 0 else -1 end, '-04-01') and 
date_format(sysdate(), '%Y-%m-%d') and task.state = 'Closed' order by task.sys_created_on, 
task.number, 
task.cmdb_ci;