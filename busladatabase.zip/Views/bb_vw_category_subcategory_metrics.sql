CREATE VIEW
    bb_vw_category_subcategory_metrics AS
select
    c.id AS category_id,
    c.category_code AS category_code,
    sc.id AS subcategory_id,
    sc.subcategory_code AS subcategory_code,
    dm.id AS metrics_id,
    dm.metrics_code AS metrics_code
from
    (
        (
            bb_dim_metrics dm
            join bb_dim_category c
        )
        join bb_dim_subcategory sc
    )
where
    dm.subcategory_id = sc.id
    and sc.category_id = c.id;