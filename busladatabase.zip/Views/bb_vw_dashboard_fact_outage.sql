CREATE VIEW
    bb_vw_dashboard_fact_outage AS
select
    bdt.date AS txn_date,
    bmc.id AS ci_id,
    bmc.ci_name AS ci_name,
    bmc.tier_id AS tier_id,
    tier.tier_name AS actual_tier_name,
    case
        when tier.tier_name = 'Tier 1'
        and bmc.is_platinum_ci = 'Y' then 'Tier 1 - Platinum'
        when tier.tier_name = 'Tier 1'
        and bmc.is_platinum_ci = 'N' then 'Tier 1'
        when tier.tier_name = 'Tier 2' then 'Tier 2'
        when tier.tier_name = 'Tier 3' then 'Tier 3'
    end AS updated_tier_name,
    tier.min_availability_target AS min_availability_target,
    co.id AS outage_id,
    co.cmdb_ci_sys_id AS cmdb_ci_sys_id,
    co.type AS outage_type,
    co.sys_id AS outage_sys_id,
    co.number AS outage_number,
    co.begin AS outage_begin,
    co.end AS outage_end,
    co.duration AS outage_duration,
    ifnull (co.duration_in_sec, 0) AS outage_duration_in_sec
from
    (
        (
            (
                bb_dim_time bdt
                join bb_mst_ci bmc on (
                    bdt.date between concat (
                        year (curdate () - interval 2 year) + case
                            when month (curdate ()) >= 4 then 0
                            else -1
                        end,
                        '-04-01'
                    ) and date_format  (sysdate (), '%Y-%m-%d')
                )
            )
            left join bb_mst_tier tier on (bmc.tier_id = tier.id)
        )
        left join bb_prefact_snow_cmdb_ci_outage co on (
            co.cmdb_ci_sys_id = bmc.sys_id
            and bdt.date = date_format (co.begin, '%Y-%m-%d')
            and co.type = 'Outage'
        )
    )
where
    bmc.ci_name like 'S.A.%'
order by
    bdt.date,
    bmc.ci_name;