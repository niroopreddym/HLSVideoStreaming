CREATE VIEW
    bb_vw_dim_ci_time AS
select
    bdt.date AS date,
    bmc.id AS ci_id,
    bmc.sys_id AS ci_sys_id,
    bmc.ci_name AS ci_name,
    bmc.alias_name AS alias_name,
    bmc.parent_ci_id AS parent_ci_id,
    bmc.subproduct_id AS subproduct_id,
    bmc.funding_portfolio_id AS funding_portfolio_id,
    bmc.subcategory AS subcategory,
    bmc.aat_id AS aat_id,
    bmc.tier_id AS tier_id,
    bmc.install_status AS install_status,
    bmc.technical_product_owner AS technical_product_owner,
    bmc.technical_product_manager AS technical_product_manager,
    bmc.is_ci_vendor_product AS is_ci_vendor_product,
    bmc.vendor AS vendor,
    bmc.is_platinum_ci AS is_platinum_ci,
    bmc.ci_created_on AS ci_created_on,
    bmc.decommission_date AS decommission_date
from
    (
        bb_mst_ci bmc
        join bb_dim_time bdt on (
            bdt.date between date_format (
                sysdate () - interval 1 month - interval dayofmonth (sysdate () - interval 1 month) - 1 day - interval 2 year,
                '%Y-%m-%d'
            ) and date_format  (sysdate (), '%Y-%m-%d')
        )
    );