CREATE VIEW
    bb_vw_ops_fact_availability_mttr AS
select
    x.ci_name AS ci_name,
    x.tier_name AS tier_name,
    x.outage_period AS outage_period,
    x.lastday AS last_day_of_month,
    x.day_of_month AS no_of_days_month,
    x.total_sec_month AS total_sec_month,
    sum(x.duration_in_sec) AS duration_in_sec,
    x.min_availability_target AS min_availability_target,
    truncate (
        (x.total_sec_month - sum(x.duration_in_sec)) / x.total_sec_month * 100,
        2
    ) AS availability,
    round(avg(x.duration_in_sec), 0) AS MTTR_in_seconds,
    count(x.outage_number) AS unplanned_outage_count
from
    (
        select
            co.ci_name AS ci_name,
            date_format (co.BEGIN, '%Y-%m') AS outage_period,
            last_day (date_format (co.BEGIN, '%Y-%m-%d')) AS lastday,
            dayofmonth (last_day (date_format (co.BEGIN, '%Y-%m-%d'))) AS day_of_month,
            co.duration_in_sec AS duration_in_sec,
            dayofmonth (last_day (date_format (co.BEGIN, '%Y-%m-%d'))) * 24 * 60 * 60 AS total_sec_month,
            co.tier_name AS tier_name,
            tier.min_availability_target AS min_availability_target,
            co.outage_number AS outage_number
        from
            (
                bb_vw_ops_fact_outage co
                left join bb_mst_tier tier on (tier.id = co.tier_id)
            )
        where
            co.TYPE = 'Outage'
            and co.ci_name like 'S.A.%'
    ) x
group by
    x.ci_name,
    x.outage_period,
    x.tier_name,
    x.lastday,
    x.day_of_month,
    x.total_sec_month,
    x.min_availability_target
order by
    x.ci_name,
    x.outage_period;