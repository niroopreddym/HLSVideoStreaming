CREATE VIEW
    bb_vw_dashboard_swe_fact AS
select
    t1.ci_id AS ci_id,
    t1.ci_name AS ci_name,
    t1.txn_date AS txn_date,
    t1.subcategory_code AS subcategory_code,
    sum(t1.PR_Size_val) AS PR_Size,
    ifnull (sum(t1.PR_Size_rating), 1) AS PR_Size_rating,
    ifnull (
        group_concat (t1.PR_Size_indicator separator ','),
        'E'
    ) AS PR_Size_indicator,
    ifnull (
        sum(t1.PR_Size_weightage),
        (
            select distinct
                bdm.metrics_weightage
            from
                bb_vw_dim_metrics_layer bdm
            where
                bdm.metrics_code = 'PR_SIZE'
                and bdm.subcategory_code = 'Code Health'
        )
    ) AS PR_Size_weightage,
    sum(t1.UTC_val) AS UTC,
    ifnull (sum(t1.UTC_rating), 1) AS UTC_rating,
    ifnull (
        group_concat (t1.UTC_indicator separator ','),
        'E'
    ) AS UTC_indicator,
    ifnull (
        sum(t1.UTC_weightage),
        (
            select distinct
                bdm.metrics_weightage
            from
                bb_vw_dim_metrics_layer bdm
            where
                bdm.metrics_code = 'UNIT_TEST'
                and bdm.subcategory_code = 'Code Health'
        )
    ) AS UTC_weightage,
    sum(t1.Vulnerability_val) AS vulnerability,
    ifnull (sum(t1.Vulnerability_rating), 1) AS Vulnerability_rating,
    ifnull (
        group_concat (t1.Vulnerability_indicator separator ','),
        'E'
    ) AS Vulnerability_indicator,
    ifnull (
        sum(t1.Vulnerability_weightage),
        (
            select distinct
                bdm.metrics_weightage
            from
                bb_vw_dim_metrics_layer bdm
            where
                bdm.metrics_code = 'VULNERABILITY'
                and bdm.subcategory_code = 'Code Health'
        )
    ) AS Vulnerability_weightage,
    sum(t1.Maintainability_val) AS Maintainability,
    ifnull (sum(t1.Maintainability_rating), 1) AS Maintainability_rating,
    ifnull (
        group_concat (t1.Maintainability_indicator separator ','),
        'E'
    ) AS Maintainability_indicator,
    ifnull (
        sum(t1.Maintainability_weightage),
        (
            select distinct
                bdm.metrics_weightage
            from
                bb_vw_dim_metrics_layer bdm
            where
                bdm.metrics_code = 'MAINTAINABILITY'
                and bdm.subcategory_code = 'Code Health'
        )
    ) AS Maintainability_weightage,
    sum(t1.Reliability_val) AS Reliability,
    ifnull (sum(t1.Reliability_rating), 1) AS Reliability_rating,
    ifnull (
        group_concat (t1.Reliability_indicator separator ','),
        'E'
    ) AS Reliability_indicator,
    ifnull (
        sum(t1.Reliability_weightage),
        (
            select distinct
                bdm.metrics_weightage
            from
                bb_vw_dim_metrics_layer bdm
            where
                bdm.metrics_code = 'RELIABILITY'
                and bdm.subcategory_code = 'Code Health'
        )
    ) AS Reliability_weightage
from
    (
        select
            bb_vw_swe_fact_new.ci_id AS ci_id,
            bb_vw_swe_fact_new.ci_name AS ci_name,
            bb_vw_swe_fact_new.txn_date AS txn_date,
            bb_vw_swe_fact_new.subcategory_code AS subcategory_code,
            case
                when bb_vw_swe_fact_new.metrics_id = (
                    select distinct
                        bdm.metrics_id
                    from
                        bb_vw_dim_metrics_layer bdm
                    where
                        bdm.metrics_code = 'PR_SIZE'
                        and bdm.subcategory_code = 'Code Health'
                ) then bb_vw_swe_fact_new.val_measure
            end AS PR_Size_val,
            case
                when bb_vw_swe_fact_new.metrics_id = (
                    select distinct
                        bdm.metrics_id
                    from
                        bb_vw_dim_metrics_layer bdm
                    where
                        bdm.metrics_code = 'PR_SIZE'
                        and bdm.subcategory_code = 'Code Health'
                ) then bb_vw_swe_fact_new.scale_rating
            end AS PR_Size_rating,
            case
                when bb_vw_swe_fact_new.metrics_id = (
                    select distinct
                        bdm.metrics_id
                    from
                        bb_vw_dim_metrics_layer bdm
                    where
                        bdm.metrics_code = 'PR_SIZE'
                        and bdm.subcategory_code = 'Code Health'
                ) then bb_vw_swe_fact_new.scale_indicator
            end AS PR_Size_indicator,
            case
                when bb_vw_swe_fact_new.metrics_id = (
                    select distinct
                        bdm.metrics_id
                    from
                        bb_vw_dim_metrics_layer bdm
                    where
                        bdm.metrics_code = 'PR_SIZE'
                        and bdm.subcategory_code = 'Code Health'
                ) then bb_vw_swe_fact_new.metrics_weightage
            end AS PR_Size_weightage,
            case
                when bb_vw_swe_fact_new.metrics_id = (
                    select distinct
                        bdm.metrics_id
                    from
                        bb_vw_dim_metrics_layer bdm
                    where
                        bdm.metrics_code = 'UNIT_TEST'
                        and bdm.subcategory_code = 'Code Health'
                ) then bb_vw_swe_fact_new.val_measure
            end AS UTC_val,
            case
                when bb_vw_swe_fact_new.metrics_id = (
                    select distinct
                        bdm.metrics_id
                    from
                        bb_vw_dim_metrics_layer bdm
                    where
                        bdm.metrics_code = 'UNIT_TEST'
                        and bdm.subcategory_code = 'Code Health'
                ) then bb_vw_swe_fact_new.scale_rating
            end AS UTC_rating,
            case
                when bb_vw_swe_fact_new.metrics_id = (
                    select distinct
                        bdm.metrics_id
                    from
                        bb_vw_dim_metrics_layer bdm
                    where
                        bdm.metrics_code = 'UNIT_TEST'
                        and bdm.subcategory_code = 'Code Health'
                ) then bb_vw_swe_fact_new.scale_indicator
            end AS UTC_indicator,
            case
                when bb_vw_swe_fact_new.metrics_id = (
                    select distinct
                        bdm.metrics_id
                    from
                        bb_vw_dim_metrics_layer bdm
                    where
                        bdm.metrics_code = 'UNIT_TEST'
                        and bdm.subcategory_code = 'Code Health'
                ) then bb_vw_swe_fact_new.metrics_weightage
            end AS UTC_weightage,
            case
                when bb_vw_swe_fact_new.metrics_id = (
                    select distinct
                        bdm.metrics_id
                    from
                        bb_vw_dim_metrics_layer bdm
                    where
                        bdm.metrics_code = 'VULNERABILITY'
                        and bdm.subcategory_code = 'Code Health'
                ) then bb_vw_swe_fact_new.val_measure
            end AS Vulnerability_val,
            case
                when bb_vw_swe_fact_new.metrics_id = (
                    select distinct
                        bdm.metrics_id
                    from
                        bb_vw_dim_metrics_layer bdm
                    where
                        bdm.metrics_code = 'VULNERABILITY'
                        and bdm.subcategory_code = 'Code Health'
                ) then bb_vw_swe_fact_new.scale_rating
            end AS Vulnerability_rating,
            case
                when bb_vw_swe_fact_new.metrics_id = (
                    select distinct
                        bdm.metrics_id
                    from
                        bb_vw_dim_metrics_layer bdm
                    where
                        bdm.metrics_code = 'VULNERABILITY'
                        and bdm.subcategory_code = 'Code Health'
                ) then bb_vw_swe_fact_new.scale_indicator
            end AS Vulnerability_indicator,
            case
                when bb_vw_swe_fact_new.metrics_id = (
                    select distinct
                        bdm.metrics_id
                    from
                        bb_vw_dim_metrics_layer bdm
                    where
                        bdm.metrics_code = 'VULNERABILITY'
                        and bdm.subcategory_code = 'Code Health'
                ) then bb_vw_swe_fact_new.metrics_weightage
            end AS Vulnerability_weightage,
            case
                when bb_vw_swe_fact_new.metrics_id = (
                    select distinct
                        bdm.metrics_id
                    from
                        bb_vw_dim_metrics_layer bdm
                    where
                        bdm.metrics_code = 'MAINTAINABILITY'
                        and bdm.subcategory_code = 'Code Health'
                ) then bb_vw_swe_fact_new.val_measure
            end AS Maintainability_val,
            case
                when bb_vw_swe_fact_new.metrics_id = (
                    select distinct
                        bdm.metrics_id
                    from
                        bb_vw_dim_metrics_layer bdm
                    where
                        bdm.metrics_code = 'MAINTAINABILITY'
                        and bdm.subcategory_code = 'Code Health'
                ) then bb_vw_swe_fact_new.scale_rating
            end AS Maintainability_rating,
            case
                when bb_vw_swe_fact_new.metrics_id = (
                    select distinct
                        bdm.metrics_id
                    from
                        bb_vw_dim_metrics_layer bdm
                    where
                        bdm.metrics_code = 'MAINTAINABILITY'
                        and bdm.subcategory_code = 'Code Health'
                ) then bb_vw_swe_fact_new.scale_indicator
            end AS Maintainability_indicator,
            case
                when bb_vw_swe_fact_new.metrics_id = (
                    select distinct
                        bdm.metrics_id
                    from
                        bb_vw_dim_metrics_layer bdm
                    where
                        bdm.metrics_code = 'MAINTAINABILITY'
                        and bdm.subcategory_code = 'Code Health'
                ) then bb_vw_swe_fact_new.metrics_weightage
            end AS Maintainability_weightage,
            case
                when bb_vw_swe_fact_new.metrics_id = (
                    select distinct
                        bdm.metrics_id
                    from
                        bb_vw_dim_metrics_layer bdm
                    where
                        bdm.metrics_code = 'RELIABILITY'
                        and bdm.subcategory_code = 'Code Health'
                ) then bb_vw_swe_fact_new.val_measure
            end AS Reliability_val,
            case
                when bb_vw_swe_fact_new.metrics_id = (
                    select distinct
                        bdm.metrics_id
                    from
                        bb_vw_dim_metrics_layer bdm
                    where
                        bdm.metrics_code = 'RELIABILITY'
                        and bdm.subcategory_code = 'Code Health'
                ) then bb_vw_swe_fact_new.scale_rating
            end AS Reliability_rating,
            case
                when bb_vw_swe_fact_new.metrics_id = (
                    select distinct
                        bdm.metrics_id
                    from
                        bb_vw_dim_metrics_layer bdm
                    where
                        bdm.metrics_code = 'RELIABILITY'
                        and bdm.subcategory_code = 'Code Health'
                ) then bb_vw_swe_fact_new.scale_indicator
            end AS Reliability_indicator,
            case
                when bb_vw_swe_fact_new.metrics_id = (
                    select distinct
                        bdm.metrics_id
                    from
                        bb_vw_dim_metrics_layer bdm
                    where
                        bdm.metrics_code = 'RELIABILITY'
                        and bdm.subcategory_code = 'Code Health'
                ) then bb_vw_swe_fact_new.metrics_weightage
            end AS Reliability_weightage
        from
            bb_vw_swe_fact_new
    ) t1
group by
    t1.ci_id,
    t1.ci_name,
    t1.txn_date,
    t1.subcategory_code
order by
    t1.txn_date,
    t1.ci_name,
    t1.subcategory_code;