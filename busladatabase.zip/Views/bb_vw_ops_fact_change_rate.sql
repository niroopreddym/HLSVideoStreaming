CREATE VIEW
    bb_vw_ops_fact_change_rate AS
select
    x.ci_name AS ci_name,
    x.period AS period,
    x.total_closed_cr AS total_closed_cr,
    x.total_successful_cr AS total_successful_cr,
    x.total_un_successful_cr AS total_un_successful_cr,
    x.total_successful_cr / x.total_closed_cr * 100 AS change_success_rate,
    x.total_un_successful_cr / x.total_closed_cr * 100 AS change_failure_rate
from
    (
        select
            bb_vw_ops_fact_change.ci_name AS ci_name,
            date_format (bb_vw_ops_fact_change.txn_date, '%Y-%m') AS period,
            sum(
                case
                    when bb_vw_ops_fact_change.state = 'closed'
                    and bb_vw_ops_fact_change.close_code <> 'Canceled' then 1
                    else 0
                end
            ) AS total_closed_cr,
            sum(
                case
                    when bb_vw_ops_fact_change.state = 'closed'
                    and bb_vw_ops_fact_change.close_code in ('Successful', 'Successful with issues') then 1
                    else 0
                end
            ) AS total_successful_cr,
            sum(
                case
                    when bb_vw_ops_fact_change.state = 'closed'
                    and bb_vw_ops_fact_change.close_code = 'Unsuccessful' then 1
                    else 0
                end
            ) AS total_un_successful_cr
        from
            bb_vw_ops_fact_change
        where
            bb_vw_ops_fact_change.state = 'closed'
            and bb_vw_ops_fact_change.close_code is not null
            and bb_vw_ops_fact_change.close_code <> 'Canceled'
        group by
            bb_vw_ops_fact_change.ci_name,
            date_format (bb_vw_ops_fact_change.txn_date, '%Y-%m')
    ) x
order by
    x.period,
    x.ci_name;