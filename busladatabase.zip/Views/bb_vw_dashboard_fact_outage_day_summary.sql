CREATE VIEW
    bb_vw_dashboard_fact_outage_day_summary AS
select
    t1.txn_date AS txn_date,
    t1.ci_id AS ci_id,
    t1.ci_name AS ci_name,
    t1.tier_id AS tier_id,
    t1.updated_tier_name AS updated_tier_name,
    t1.min_availability_target AS min_availability_target,
    sum(t1.total_outage_duration) AS total_outage_duration,
    count(t1.outage_id) AS unplanned_outage_count,
    truncate (
        (t1.total_sec_day - sum(t1.total_outage_duration)) / t1.total_sec_day * 100,
        2
    ) AS availability,
    ifnull (
        round(
            sum(t1.total_outage_duration) / count(t1.outage_number),
            0
        ),
        0
    ) AS MTTR_in_seconds
from
    (
        select
            bdt.date AS txn_date,
            bmc.id AS ci_id,
            bmc.ci_name AS ci_name,
            bmc.tier_id AS tier_id,
            case
                when tier.tier_name = 'Tier 1'
                and bmc.is_platinum_ci = 'Y' then 'Tier 1 - Platinum'
                when tier.tier_name = 'Tier 1'
                and bmc.is_platinum_ci = 'N' then 'Tier 1'
                when tier.tier_name = 'Tier 2' then 'Tier 2'
                when tier.tier_name = 'Tier 3' then 'Tier 3'
            end AS updated_tier_name,
            tier.min_availability_target AS min_availability_target,
            co.id AS outage_id,
            co.cmdb_ci_sys_id AS cmdb_ci_sys_id,
            co.type AS outage_type,
            co.sys_id AS outage_sys_id,
            co.number AS outage_number,
            co.begin AS outage_begin,
            co.end AS outage_end,
            co.duration AS outage_duration,
            ifnull (co.duration_in_sec, 0) AS total_outage_duration,
            24 * 60 * 60 AS total_sec_day
        from
            (
                (
                    (
                        bb_dim_time bdt
                        join bb_mst_ci bmc
                    )
                    left join bb_mst_tier tier on (bmc.tier_id = tier.id)
                )
                left join bb_prefact_snow_cmdb_ci_outage co on (
                    co.cmdb_ci_sys_id = bmc.sys_id
                    and bdt.date = date_format (co.begin, '%Y-%m-%d')
                    and co.type = 'Outage'
                )
            )
        where
            bmc.ci_name like 'S.A.%'
    ) t1
where
    date_format (t1.txn_date, '%Y-%m-%d') between concat (
        year (curdate () - interval 2 year) + case
            when month (curdate ()) >= 4 then 0
            else -1
        end,
        '-04-01'
    ) and date_format  (sysdate (), '%Y-%m-%d')
group by
    t1.txn_date,
    t1.ci_name
order by
    t1.txn_date,
    t1.ci_name;