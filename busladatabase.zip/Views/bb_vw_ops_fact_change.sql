CREATE VIEW
    bb_vw_ops_fact_change AS
select
    cr.id AS id,
    cr.number AS change_number,
    cr.sys_id_change_request AS cr_sys_id,
    cr.cmdb_ci_sys_id AS ci_sys_id,
    ci.id AS ci_id,
    ci.ci_name AS ci_name,
    ti.id AS time_id,
    ti.date AS txn_date,
    ci.tier_id AS tier_id,
    cr.category AS category,
    cr.u_subcategory AS subcategory,
    cr.close_code AS close_code,
    cr.state AS state,
    cr.made_sla AS made_sla,
    cr.type AS change_type,
    cr.priority AS cr_priority,
    cr.start_date AS start_date,
    cr.end_date AS end_date,
    cr.opened_at AS opened_at,
    cr.sys_created_on AS sys_created_on,
    cr.sys_updated_on AS sys_updated_on
from
    (
        (
            (
                bb_prefact_snow_change_request cr
                join bb_mst_ci ci on (cr.cmdb_ci_sys_id = ci.sys_id)
            )
            join bb_dim_time ti on (
                ti.date = date_format (cr.sys_created_on, '%Y-%m-%d')
                and ti.date between concat (
                    year (curdate () - interval 2 year) + case
                        when month (curdate ()) >= 4 then 0
                        else -1
                    end,
                    '-04-01'
                ) and date_format  (sysdate (), '%Y-%m-%d')
            )
        )
        left join bb_mst_tier tier on (ci.tier_id = tier.id)
    )
order by
    ti.date;