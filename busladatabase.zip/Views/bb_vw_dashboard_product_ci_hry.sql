CREATE VIEW
    bb_vw_dashboard_product_ci_hry AS
select
    t1.ci_id AS ci_id,
    t1.ci_name AS ci_name,
    t1.parent_ci_id AS parent_ci_id,
    t1.parent_ci_name AS parent_ci_name,
    t1.ci_sys_id AS ci_sys_id,
    t1.alias_name AS alias_name,
    t1.ci_short_description AS ci_short_description,
    t1.install_status AS install_status,
    t1.subcategory AS subcategory,
    t1.business_unit_id AS business_unit_id,
    t1.business_unit AS business_unit,
    t1.subproduct_capability_id AS subproduct_capability_id,
    t1.subproduct_code AS subproduct_code,
    t1.subproduct_name AS subproduct_name,
    t1.ci_subproduct_id AS ci_subproduct_id,
    t1.subproduct_id AS subproduct_id,
    t1.product_id AS product_id,
    t1.product_capability_id AS product_capability_id,
    t1.product_business_capability_name AS product_business_capability_name,
    t1.product_code AS product_code,
    t1.product_name AS product_name,
    t1.product_ownr AS product_ownr,
    t1.product_desc AS product_desc,
    t1.TYPE AS TYPE,
    t1.aat_id AS aat_id,
    t1.aat_name AS aat_name,
    t1.funding_portfolio_id AS funding_portfolio_id,
    t1.funding_portfolio_name AS funding_portfolio_name,
    t1.delivery_portfolio_id AS delivery_portfolio_id,
    t1.delivery_portfolio_name AS delivery_portfolio_name,
    t1.team_id AS team_id,
    t1.Tier AS Tier,
    ifnull (t1.actual_tier_name, 'Tier not defined') AS actual_tier_name,
    t1.is_platinum_ci AS is_platinum_ci,
    ifnull (t1.ci_tier, 'Tier not defined') AS ci_tier,
    (
        select
            bmt.id
        from
            bb_mst_tier bmt
        where
            bmt.tier_name = t1.ci_tier
    ) AS ci_tier_id,
    (
        select
            bmt.tier_weightage
        from
            bb_mst_tier bmt
        where
            bmt.tier_name = t1.ci_tier
    ) AS tier_weightage,
    t1.is_ci_vendor_product AS is_ci_vendor_product,
    t1.vendor_name AS vendor_name,
    t1.tpo AS tpo,
    t1.tpm AS tpm,
    t1.ci_created_on AS ci_created_on,
    t1.ci_mapping_modified_on AS ci_mapping_modified_on,
    t1.ci_decommission_date AS ci_decommission_date
from
    (
        select
            ci.id AS ci_id,
            ci.ci_name AS ci_name,
            ci.parent_ci_id AS parent_ci_id,
            ci.sys_id AS ci_sys_id,
            ci.install_status AS install_status,
            ifnull (ci.alias_name, 'Alias name not defined') AS alias_name,
            (
                select
                    bmc.ci_name AS parent_ci_name
                from
                    bb_mst_ci bmc
                where
                    bmc.id = ci.parent_ci_id
            ) AS parent_ci_name,
            ci.subcategory AS subcategory,
            bu.id AS business_unit_id,
            ifnull (
                bu.business_unit_name,
                'Business Unit not defined'
            ) AS business_unit,
            spr.capability_id AS subproduct_capability_id,
            ifnull (spr.subproduct_code, 'SUBPRDCTNTDFND0002') AS subproduct_code,
            ifnull (spr.subproduct_name, 'Sub Product not defined') AS subproduct_name,
            ci.subproduct_id AS ci_subproduct_id,
            spr.id AS subproduct_id,
            pr.id AS product_id,
            pr.capability_id AS product_capability_id,
            ifnull (capilty.capability_name, 'Capability not defined') AS product_business_capability_name,
            ifnull (pr.product_code, 'PRDCTNTDFND0001') AS product_code,
            ifnull (pr.product_name, 'Product not defined') AS product_name,
            pr.product_ownr AS product_ownr,
            pr.product_desc AS product_desc,
            pr.type AS TYPE,
            ci.aat_id AS aat_id,
            ifnull (aat.aat_name, 'AAT not defined') AS aat_name,
            ci.funding_portfolio_id AS funding_portfolio_id,
            ifnull (
                ifnull (pf.portfolio_desc, dpf.portfolio_desc),
                'Funding portfolio not defined'
            ) AS funding_portfolio_name,
            aat.delivery_portfolio_id AS delivery_portfolio_id,
            ifnull (
                dpf.portfolio_desc,
                'Delivery portfolio not defined'
            ) AS delivery_portfolio_name,
            ci.team_id AS team_id,
            ci.tier_id AS Tier,
            tier.tier_name AS actual_tier_name,
            ci.is_ci_vendor_product AS is_ci_vendor_product,
            ci.vendor AS vendor_name,
            ci.technical_product_owner AS tpo,
            ci.technical_product_manager AS tpm,
            ci.is_platinum_ci AS is_platinum_ci,
            case
                when tier.tier_name = 'Tier 1'
                and ci.is_platinum_ci = 'Y' then 'Tier 1 - Platinum'
                when tier.tier_name = 'Tier 1'
                and ci.is_platinum_ci = 'N' then 'Tier 1'
                when tier.tier_name = 'Tier 2' then 'Tier 2'
                when tier.tier_name = 'Tier 3' then 'Tier 3'
            end AS ci_tier,
            ci.ci_created_on AS ci_created_on,
            ci.ci_mapping_modified_on AS ci_mapping_modified_on,
            ci.decommission_date AS ci_decommission_date,
            ci.short_description AS ci_short_description
        from
            (
                (
                    (
                        (
                            (
                                (
                                    (
                                        (
                                            bb_mst_ci ci
                                            left join bb_mst_subproduct spr on (ci.subproduct_id = spr.id)
                                        )
                                        left join bb_mst_product pr on (spr.product_id = pr.id)
                                    )
                                    left join bb_mst_portfolio pf on (ci.funding_portfolio_id = pf.id)
                                )
                                left join bb_mst_aat aat on (ci.aat_id = aat.id)
                            )
                            left join bb_mst_business_unit bu on (spr.business_unit_id = bu.id)
                        )
                        left join bb_mst_tier tier on (ci.tier_id = tier.id)
                    )
                    left join bb_mst_capability capilty on (pr.capability_id = capilty.id)
                )
                left join bb_mst_portfolio dpf on (aat.delivery_portfolio_id = dpf.id)
            )
        where
            ci.ci_name like 'S.A.%'
    ) t1
order by
    ifnull (t1.parent_ci_name, t1.ci_name);