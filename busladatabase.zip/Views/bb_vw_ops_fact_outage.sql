CREATE VIEW
    bb_vw_ops_fact_outage AS
select
    co.id AS id,
    co.number AS outage_number,
    co.sys_id AS outage_sys_id,
    co.cmdb_ci_sys_id AS ci_sys_id,
    ci.id AS ci_id,
    ci.ci_name AS ci_name,
    ti.id AS time_id,
    ti.date AS txn_date,
    co.begin AS BEGIN,
    co.end AS END,
    co.duration_in_sec AS duration_in_sec,
    co.type AS TYPE,
    ci.tier_id AS tier_id,
    case
        when tier.tier_name = 'Tier 1'
        and ci.is_platinum_ci = 'Y' then 'Tier 1 - Platinum'
        when tier.tier_name = 'Tier 1'
        and ci.is_platinum_ci = 'N' then 'Tier 1'
        when tier.tier_name = 'Tier 2' then 'Tier 2'
        when tier.tier_name = 'Tier 3' then 'Tier 3'
    end AS tier_name,
    ci.is_platinum_ci AS is_platinum_ci,
    ci.is_ci_vendor_product AS is_ci_vendor_product,
    ci.vendor AS vendor,
    ci.install_status AS install_status
from
    (
        (
            (
                bb_prefact_snow_cmdb_ci_outage co
                join bb_mst_ci ci on (co.cmdb_ci_sys_id = ci.sys_id)
            )
            join bb_dim_time ti on (ti.date = date_format (co.begin, '%Y-%m-%d'))
        )
        left join bb_mst_tier tier on (ci.tier_id = tier.id)
    );