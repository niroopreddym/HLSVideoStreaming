CREATE VIEW
    bb_vw_user_team_hry AS
select distinct
    usr.staff_id AS staff_id,
    team.team_name AS team_name,
    aat.aat_desc AS aat_name,
    aat.aat_name AS aat_code,
    portfolio.portfolio_desc AS portfolio_desc,
    team.id AS team_id,
    aat.id AS aat_id,
    usr.job_title AS job_title
from
    (
        (
            (
                bb_mst_users usr
                join bb_mst_team team
            )
            join bb_mst_aat aat
        )
        join bb_mst_portfolio portfolio
    )
where
    usr.team_id = team.id
    and team.aat_id = aat.id
    and ifnull (
        usr.extended_portfolio_id,
        aat.delivery_portfolio_id
    ) = portfolio.id;