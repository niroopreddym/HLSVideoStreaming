CREATE VIEW
    bb_vw_dashboard_fact_observability_history AS
select
    bmc.id AS ci_id,
    bmc.sys_id AS ci_sys_id,
    bmc.ci_name AS ci_name,
    case
        when ac.u_overall_adoption_level in (
            'GOLD',
            'BRONZE',
            'SILVER',
            'Minimum Requirement Not Met',
            'Not Applicable'
        ) then ac.u_overall_adoption_level
        else 'Minimum Requirement Not Met'
    end AS overall_adoption_level,
    date_format (ac.sys_created_on, '%y-%m-%d') AS created_on,
    date_format (ac.sys_updated_on, '%y-%m-%d') AS last_updated_on
from
    (
        (
            bb_mst_ci bmc
            left join bb_ib_staging_snow_u_adoption_check ac on (
                ac.u_business_application = bmc.sys_id
                and ac.u_class_type = 'Business Application'
            )
        )
        left join bb_dim_time bdt on (
            bdt.date = date_format (ac.sys_created_on, '%y-%m-%d')
        )
    )
where
    bmc.ci_name like 'S.A.%'
group by
    bmc.id,
    bmc.sys_id,
    bmc.ci_name,
    date_format (ac.sys_created_on, '%y-%m-%d'),
    date_format (ac.sys_updated_on, '%y-%m-%d'),
    case
        when ac.u_overall_adoption_level in (
            'GOLD',
            'BRONZE',
            'SILVER',
            'Minimum Requirement Not Met',
            'Not Applicable'
        ) then ac.u_overall_adoption_level
        else 'Minimum Requirement Not Met'
    end
order by
    bmc.ci_name,
    date_format (ac.sys_created_on, '%y-%m-%d'),
    date_format (ac.sys_updated_on, '%y-%m-%d');