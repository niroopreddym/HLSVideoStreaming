CREATE VIEW
    bb_vw_ops_fact_change_detail AS
select
    bdt.date AS txn_date,
    bmc.id AS ci_id,
    bmc.sys_id AS ci_sys_id,
    bmc.ci_name AS ci_name,
    cr.number AS change_number,
    cr.sys_id_change_request AS cr_sys_id,
    cr.u_subcategory AS change_subcategory,
    cr.state AS change_state,
    cr.close_code AS change_close_code,
    cr.made_sla AS made_sla,
    cr.start_date AS start_date,
    cr.end_date AS end_date,
    cr.priority AS cr_priority
from
    (
        (
            bb_mst_ci bmc
            left join bb_dim_time bdt on (
                bdt.date between concat (
                    year (curdate () - interval 2 year) + case
                        when month (curdate ()) >= 4 then 0
                        else -1
                    end,
                    '-04-01'
                ) and date_format  (sysdate (), '%Y-%m-%d')
            )
        )
        left join bb_prefact_snow_change_request cr on (
            cr.cmdb_ci_sys_id = bmc.sys_id
            and date_format (cr.start_date, '%y-%m-%d') = bdt.date
            and cr.state = 'closed'
            and cr.close_code is not null
            and cr.close_code <> 'Canceled'
        )
    )
order by
    bdt.date,
    bmc.ci_name;