CREATE VIEW
    bb_vw_subproduct_tier AS
select
    t1.subproduct_id AS subproduct_id,
    t1.subproduct_name AS subproduct_name,
    t1.subproduct_desc AS subproduct_desc,
    t1.subproduct_business_unit_id AS subproduct_business_unit_id,
    t1.subproduct_business_unit AS subproduct_business_unit,
    t1.subproduct_l2_capability_id AS subproduct_l2_capability_id,
    t1.subproduct_l2_capability AS subproduct_l2_capability,
    t1.subproduct_tier AS subproduct_tier,
    (
        select
            bmt.tier_weightage
        from
            bb_mst_tier bmt
        where
            bmt.tier_name = t1.subproduct_tier
    ) AS tier_weightage,
    t1.subproduct_status AS subproduct_status,
    t1.product_id AS product_id,
    t1.product_name AS product_name,
    t1.product_l1_capability_id AS product_l1_capability_id,
    t1.product_l1_capability AS product_l1_capability,
    t1.subproduct_vendor_indicator AS subproduct_vendor_indicator
from
    (
        select
            msp.id AS subproduct_id,
            msp.subproduct_name AS subproduct_name,
            msp.subproduct_desc AS subproduct_desc,
            msp.business_unit_id AS subproduct_business_unit_id,
            bu.business_unit_name AS subproduct_business_unit,
            msp.capability_id AS subproduct_l2_capability_id,
            l2.capability_name AS subproduct_l2_capability,
            case
                when (
                    select
                        count(1)
                    from
                        (
                            bb_mst_ci mci
                            join bb_mst_tier tier on (mci.tier_id = tier.id)
                        )
                    where
                        mci.subproduct_id = msp.id
                        and tier.tier_name = 'Tier 1'
                        and mci.is_platinum_ci = 'Y'
                ) > 0 then 'Tier 1 - Platinum'
                when (
                    select
                        count(1)
                    from
                        (
                            bb_mst_ci mci
                            join bb_mst_tier tier on (mci.tier_id = tier.id)
                        )
                    where
                        mci.subproduct_id = msp.id
                        and tier.tier_name = 'Tier 1'
                        and mci.is_platinum_ci = 'N'
                ) > 0 then 'Tier 1'
                when (
                    select
                        count(1)
                    from
                        (
                            bb_mst_ci mci
                            join bb_mst_tier tier on (mci.tier_id = tier.id)
                        )
                    where
                        mci.subproduct_id = msp.id
                        and tier.tier_name = 'Tier 2'
                ) > 0 then 'Tier 2'
                when (
                    select
                        count(1)
                    from
                        (
                            bb_mst_ci mci
                            join bb_mst_tier tier on (mci.tier_id = tier.id)
                        )
                    where
                        mci.subproduct_id = msp.id
                        and tier.tier_name = 'Tier 3'
                ) > 0 then 'Tier 3'
            end AS subproduct_tier,
            msp.status AS subproduct_status,
            msp.product_id AS product_id,
            mp.product_name AS product_name,
            mp.capability_id AS product_l1_capability_id,
            l1.capability_name AS product_l1_capability,
            (
                select
                    case
                        when group_concat (distinct mci.is_ci_vendor_product separator ',') = 'N,Y'
                        or group_concat (distinct mci.is_ci_vendor_product separator ',') = 'Y,N' then 'Mix'
                        when group_concat (distinct mci.is_ci_vendor_product separator ',') = 'N' then 'Inhouse'
                        when group_concat (distinct mci.is_ci_vendor_product separator ',') = 'Y' then 'Vendor'
                    end
                from
                    bb_mst_ci mci
                where
                    mci.subproduct_id = msp.id
            ) AS subproduct_vendor_indicator
        from
            (
                (
                    (
                        (
                            bb_mst_subproduct msp
                            left join bb_mst_product mp on (msp.product_id = mp.id)
                        )
                        left join bb_mst_capability l2 on (l2.id = msp.capability_id)
                    )
                    left join bb_mst_capability l1 on (l1.id = mp.capability_id)
                )
                left join bb_mst_business_unit bu on (bu.id = msp.business_unit_id)
            )
        order by
            msp.id,
            case
                when (
                    select
                        count(1)
                    from
                        (
                            bb_mst_ci mci
                            join bb_mst_tier tier on (mci.tier_id = tier.id)
                        )
                    where
                        mci.subproduct_id = msp.id
                        and tier.tier_name = 'Tier 1'
                        and mci.is_platinum_ci = 'Y'
                ) > 0 then 'Tier 1 - Platinum'
                when (
                    select
                        count(1)
                    from
                        (
                            bb_mst_ci mci
                            join bb_mst_tier tier on (mci.tier_id = tier.id)
                        )
                    where
                        mci.subproduct_id = msp.id
                        and tier.tier_name = 'Tier 1'
                        and mci.is_platinum_ci = 'N'
                ) > 0 then 'Tier 1'
                when (
                    select
                        count(1)
                    from
                        (
                            bb_mst_ci mci
                            join bb_mst_tier tier on (mci.tier_id = tier.id)
                        )
                    where
                        mci.subproduct_id = msp.id
                        and tier.tier_name = 'Tier 2'
                ) > 0 then 'Tier 2'
                when (
                    select
                        count(1)
                    from
                        (
                            bb_mst_ci mci
                            join bb_mst_tier tier on (mci.tier_id = tier.id)
                        )
                    where
                        mci.subproduct_id = msp.id
                        and tier.tier_name = 'Tier 3'
                ) > 0 then 'Tier 3'
            end
    ) t1;