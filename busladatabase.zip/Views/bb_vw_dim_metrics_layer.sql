CREATE VIEW
    bb_vw_dim_metrics_layer AS
select
    t1.category_id AS category_id,
    t1.category_code AS category_code,
    t1.category_desc AS category_desc,
    t1.subcategory_id AS subcategory_id,
    t1.subcategory_code AS subcategory_code,
    t1.subcategory_desc AS subcategory_desc,
    t1.subcategory_weightage AS subcategory_weightage,
    t1.metrics_id AS metrics_id,
    t1.metrics_code AS metrics_code,
    t1.metrics_desc AS metrics_desc,
    t1.metrics_weightage AS metrics_weightage,
    t1.scale_value_min AS scale_value_min,
    t1.scale_value_max AS scale_value_max,
    t1.scale_indicator AS scale_indicator,
    t1.scale_rating AS scale_rating,
    t1.tier AS tier
from
    (
        select
            bdc.id AS category_id,
            bdc.category_code AS category_code,
            bdc.category_desc AS category_desc,
            bdsc.id AS subcategory_id,
            bdsc.subcategory_code AS subcategory_code,
            bdsc.subcategory_desc AS subcategory_desc,
            brsc.weightage AS subcategory_weightage,
            bdm.id AS metrics_id,
            bdm.metrics_code AS metrics_code,
            bdm.metrics_desc AS metrics_desc,
            brm.weightage AS metrics_weightage,
            bmsr.scale_value_min AS scale_value_min,
            bmsr.scale_value_max AS scale_value_max,
            bmsr.scale_indicator AS scale_indicator,
            bmsr.scale_rating AS scale_rating,
            bmsr.tier AS tier
        from
            (
                (
                    (
                        (
                            (
                                bb_dim_category bdc
                                join bb_dim_subcategory bdsc on (bdsc.category_id = bdc.id)
                            )
                            left join bb_rollup_sub_category brsc on (brsc.sub_category_id = bdsc.id)
                        )
                        join bb_dim_metrics bdm on (bdm.subcategory_id = bdsc.id)
                    )
                    left join bb_rollup_metrics brm on (brm.metrics_id = bdm.id)
                )
                left join bb_map_metrics_scale_rating bmsr on (bmsr.metrics_id = bdm.id)
            )
    ) t1
order by
    t1.category_id,
    t1.subcategory_id,
    t1.metrics_id,
    t1.scale_indicator;