CREATE VIEW
    bb_vw_ci_teams_tpo AS
select
    bmc.id AS ci_id,
    bmc.ci_name AS ci_name,
    bms.product_id AS product_id,
    bmc.subproduct_id AS subproduct_id,
    bms.subproduct_name AS subproduct_name,
    group_concat (bmt.team_name separator ', ') AS team_name_CommaSeparated,
    group_concat (bmt.id separator ', ') AS team_id_CommaSeparated,
    group_concat (bmct.id separator ', ') AS bmct_id_CommaSeparated,
    bmct.primary_team_ind AS primary_team_ind,
    bmc.tpo_staff_id AS tpo_staff_id,
    concat (bmu.first_name, '', bmu.last_name) AS tpo_staff_name
from
    (
        (
            (
                (
                    (
                        bb_mst_ci bmc
                        left join bb_mst_ci_teams_mapping bmct on (bmc.id = bmct.ci_id)
                    )
                    left join bb_mst_team bmt on (bmct.team_id = bmt.id)
                )
                left join bb_mst_subproduct bms on (bmc.subproduct_id = bms.id)
            )
            left join bb_mst_product bmp on (bms.product_id = bmp.id)
        )
        left join bb_mst_users bmu on (bmu.staff_id = bmc.tpo_staff_id)
    )
where
    bms.product_id is not null
group by
    bmc.id,
    bmc.ci_name
order by
    bmc.ci_name;