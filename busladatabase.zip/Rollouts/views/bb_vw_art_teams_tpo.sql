CREATE VIEW
    bb_vw_art_teams_tpo AS
select distinct
    hry.aat_id AS aat_id,
    hry.aat_code AS aat_code,
    hry.team_id AS team_id,
    hry.team_name AS team_name,
    hry.staff_id AS staff_id,
    hry.staff_name AS staff_name,
    hry.job_title AS job_title,
    hry.alternate_role AS alternate_role
from
    bb_vw_user_hry hry
where
    hry.job_title like 'TECHNICAL PRODUCT OWNER'
    or hry.alternate_role like '%TECHNICAL PRODUCT OWNER%';