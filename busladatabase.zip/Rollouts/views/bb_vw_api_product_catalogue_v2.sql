-- bb_vw_api_product_catalogue_v2
CREATE VIEW
    bb_vw_api_product_catalogue_v2 AS
select
    t.product_id AS product_id,
    t.product_code AS product_code,
    t.product_name AS product_name,
    t.product_desc AS product_desc,
    t.product_business_capability AS product_business_capability,
    cast(
        t.product_business_dept as char(1000) charset utf8mb4
    ) AS product_business_dept,
    t.product_portfolio AS product_portfolio,
    t.product_pillar AS product_pillar,
    cast(t.product_art as char(1000) charset utf8mb4) AS product_art,
    t.product_type AS product_type,
    t.product_status AS product_status,
    t.product_created_on AS product_created_on,
    t.product_modified_on AS product_modified_on,
    t.subproduct_id AS subproduct_id,
    t.subproduct_code AS subproduct_code,
    t.subproduct_name AS subproduct_name,
    t.subproduct_desc AS subproduct_desc,
    t.subproduct_business_capability AS subproduct_business_capability,
    t.subproduct_business_dept AS subproduct_business_dept,
    t.subproduct_art AS subproduct_art,
    t.subproduct_tpm AS subproduct_tpm,
    t.subproduct_status AS subproduct_status,
    t.subproduct_created_on AS subproduct_created_on,
    t.subproduct_modified_on AS subproduct_modified_on,
    t.ci_name AS ci_name,
    cast(t.cmdb_ci_sys_id as char(255) charset utf8mb4) AS cmdb_ci_sys_id,
    t.ci_install_status AS ci_install_status,
    t.ci_id AS ci_id,
    t.ci_tpo AS ci_tpo,
    cast(t.ci_teams as char(1000) charset utf8mb4) AS ci_teams,
    t.ci_created_on AS ci_created_on,
    t.ci_modified_on AS ci_modified_on,
    t.ci_mapping_modified_on AS ci_mapping_modified_on
from
    (
        select
            bmp.id AS product_id,
            bmp.product_code AS product_code,
            bmp.product_name AS product_name,
            bmp.product_desc AS product_desc,
            l1_bmcp.capability_name AS product_business_capability,
            (
                select
                    ifnull (
                        group_concat (
                            concat (t.business_unit_code, '|', t.business_unit_name) separator '*'
                        ),
                        'BUCNTDFND0001|Business Unit Name defined'
                    )
                from
                    (
                        select distinct
                            spr.product_id AS product_id,
                            ifnull (bmbu.business_unit_code, 'BUCNTDFND0001') AS business_unit_code,
                            ifnull (
                                bmbu.business_unit_name,
                                'Business Unit Name defined'
                            ) AS business_unit_name
                        from
                            (
                                bb_mst_subproduct spr
                                join bb_mst_business_unit bmbu on (spr.business_unit_id = bmbu.id)
                            )
                    ) t
                where
                    t.product_id = bmp.id
            ) AS product_business_dept,
            ifnull (bmpf.portfolio_desc, 'Portfolio not defined') AS product_portfolio,
            ifnull (bmpl.pillar_name, 'Pillar not defined') AS product_pillar,
            (
                select
                    ifnull (
                        group_concat (
                            concat (t.aat_desc, '|', t.tpm_staff_id) separator '*'
                        ),
                        'ART not defined|TPM not defined'
                    )
                from
                    (
                        select distinct
                            spr.product_id AS product_id,
                            ifnull (bma.aat_desc, 'ART not defined') AS aat_desc,
                            ifnull (spr.tpm_staff_id, 'TPM not defined') AS tpm_staff_id
                        from
                            (
                                bb_mst_subproduct spr
                                join bb_mst_aat bma on (spr.art_id = bma.id)
                            )
                    ) t
                where
                    t.product_id = bmp.id
            ) AS product_art,
            bmp.type AS product_type,
            bmp.status AS product_status,
            bmp.created_on AS product_created_on,
            bmp.modified_on AS product_modified_on,
            bmsp.id AS subproduct_id,
            bmsp.subproduct_code AS subproduct_code,
            bmsp.subproduct_name AS subproduct_name,
            bmsp.subproduct_desc AS subproduct_desc,
            l2_bmcp.capability_name AS subproduct_business_capability,
            concat (
                ifnull (sprbu.business_unit_code, 'BUCNTDFND0001'),
                '|',
                ifnull (
                    sprbu.business_unit_name,
                    'Business Department not defined'
                )
            ) AS subproduct_business_dept,
            sp_aat.aat_desc AS subproduct_art,
            bmsp.tpm_staff_id AS subproduct_tpm,
            bmsp.status AS subproduct_status,
            bmsp.created_on AS subproduct_created_on,
            bmsp.modified_on AS subproduct_modified_on,
            ci.ci_name AS ci_name,
            ci.sys_id AS cmdb_ci_sys_id,
            ci.install_status AS ci_install_status,
            ci.id AS ci_id,
            ci.tpo_staff_id AS ci_tpo,
            (
                select
                    group_concat (t.team separator '*')
                from
                    (
                        select
                            bmct.ci_id AS bmctm_ci_id,
                            bmc.ci_name AS bmctm_ci_name,
                            concat (bmt.team_name, '|', bmct.primary_team_ind) AS team
                        from
                            (
                                (
                                    bb_mst_team bmt
                                    join bb_mst_ci_teams_mapping bmct on (bmct.team_id = bmt.id)
                                )
                                join bb_mst_ci bmc on (bmct.ci_id = bmc.id)
                            )
                        order by
                            bmc.ci_name
                    ) t
                where
                    t.bmctm_ci_id = ci_id
                group by
                    t.bmctm_ci_name
            ) AS ci_teams,
            ci.created_on AS ci_created_on,
            ci.modified_on AS ci_modified_on,
            ci.ci_mapping_modified_on AS ci_mapping_modified_on
        from
            (
                (
                    (
                        (
                            (
                                (
                                    (
                                        (
                                            bb_mst_product bmp
                                            left join bb_mst_capability l1_bmcp on (bmp.capability_id = l1_bmcp.id)
                                        )
                                        left join bb_mst_subproduct bmsp on (bmp.id = bmsp.product_id)
                                    )
                                    left join bb_mst_portfolio bmpf on (bmp.portfolio_id = bmpf.id)
                                )
                                left join bb_mst_pillar bmpl on (bmp.pillar_id = bmpl.id)
                            )
                            left join bb_mst_aat sp_aat on (bmsp.art_id = sp_aat.id)
                        )
                        left join bb_mst_business_unit sprbu on (bmsp.business_unit_id = sprbu.id)
                    )
                    left join bb_mst_capability l2_bmcp on (bmsp.capability_id = l2_bmcp.id)
                )
                left join bb_mst_ci ci on (bmsp.id = ci.subproduct_id)
            )
        where
            bmp.portfolio_id not in (8, 9)
    ) t;