CREATE VIEW
    bb_vw_dashboard_tech_debt_history AS
select
    tech_debt.app_ci_id AS app_ci_id,
    tech_debt.application AS application,
    tech_debt.sub_category AS sub_category,
    tech_debt.technical_ci_name AS technical_ci_name,
    tech_debt.count_secondary_ci AS count_secondary_ci,
    tech_debt.state AS state,
    tech_debt.created_on AS created_on,
    tech_debt.state_changed_on AS state_changed_on,
    tech_debt.Tech_Severity AS Tech_Severity,
    tech_debt.Tech_Score AS Tech_Score,
    tech_debt.EOL_Severity AS EOL_Severity,
    tech_debt.EOL_Score AS EOL_Score,
    tech_debt.install_status AS install_status,
    tech_debt.Install_Score AS Install_Score,
    tech_debt.count_secondary_ci * tech_debt.Tech_Score * tech_debt.EOL_Score * tech_debt.Install_Score AS Tech_Debt_index,
    tech_debt.count_secondary_ci * tech_debt.Tech_Score * tech_debt.critical_EOL_Score * tech_debt.Install_Score AS Critical_EOL_Tech_Index
from
    (
        select
            tech_debt.u_sub_category AS sub_category,
            tech_debt.u_application AS app_sys_id,
            app.id AS app_ci_id,
            app.ci_name AS application,
            tech_debt.u_technical_ci AS technical_ci_sys_id,
            tech_app.name AS technical_ci_name,
            date_format (tech_debt.sys_created_on, '%Y-%m-%d') AS created_on,
            tech_debt.state AS state,
            date_format (tech_debt.sys_updated_on, '%Y-%m-%d') AS state_changed_on,
            case
                when tech_app.name in (
                    select
                        bmcm.entity_val
                    from
                        bb_mst_common_master bmcm
                    where
                        bmcm.entity = 'TECH_DEBT'
                        and bmcm.entity_code = 'CRITICAL_TECH_COMPONENT'
                ) then 'Critical'
                else 'Not Critical'
            end AS Tech_Severity,
            (
                select
                    bmcm.entity_val
                from
                    bb_mst_common_master bmcm
                where
                    bmcm.entity = 'TECH_DEBT_TECH_SCORE'
                    and bmcm.entity_code = case
                        when tech_app.name in (
                            select
                                bmcm.entity_val
                            from
                                bb_mst_common_master bmcm
                            where
                                bmcm.entity = 'TECH_DEBT'
                                and bmcm.entity_code = 'CRITICAL_TECH_COMPONENT'
                        ) then 'Critical'
                        else 'Not Critical'
                    end
            ) AS Tech_Score,
            ifnull (tech_debt.u_severity, 'Low') AS EOL_Severity,
            (
                select
                    bmcm.entity_val
                from
                    bb_mst_common_master bmcm
                where
                    bmcm.entity = 'TECH_DEBT_EOL_SCORE'
                    and bmcm.entity_code = ifnull (tech_debt.u_severity, 'Low')
            ) AS EOL_Score,
            (
                select
                    bmcm.entity_val
                from
                    bb_mst_common_master bmcm
                where
                    bmcm.entity = 'TECH_DEBT_EOL_SCORE'
                    and bmcm.entity_code = 'Critical'
            ) AS critical_EOL_Score,
            case
                when secondary_ci.install_status = 'Production' then 'Production'
                else 'Non-Production'
            end AS install_status,
            (
                select
                    bmcm.entity_val
                from
                    bb_mst_common_master bmcm
                where
                    bmcm.entity = 'TECH_DEBT_INSTALL_SCORE'
                    and bmcm.entity_code = secondary_ci.install_status
            ) AS Install_Score,
            count(tech_debt.u_secondary_ci) AS count_secondary_ci
        from
            (
                (
                    (
                        bb_ib_staging_snow_u_technical_debt tech_debt
                        left join bb_mst_ci app on (tech_debt.u_application = app.sys_id)
                    )
                    left join bb_prefact_snow_cmdb_ci tech_app on (tech_app.sys_id = tech_debt.u_technical_ci)
                )
                left join bb_prefact_snow_cmdb_ci secondary_ci on (secondary_ci.sys_id = tech_debt.u_secondary_ci)
            )
        where
            tech_debt.u_category = 'End of Life'
            and secondary_ci.install_status is not null
            and secondary_ci.install_status in (
                'Production',
                'Pre-Production',
                'Development',
                'Staging',
                'Training'
            )
        group by
            tech_debt.u_application,
            app.id,
            app.id,
            app.ci_name,
            tech_debt.u_sub_category,
            tech_debt.u_technical_ci,
            tech_app.name,
            date_format (tech_debt.sys_created_on, '%Y-%m-%d'),
            tech_debt.state,
            date_format (tech_debt.sys_updated_on, '%Y-%m-%d'),
            case
                when tech_app.name in (
                    select
                        bmcm.entity_val
                    from
                        bb_mst_common_master bmcm
                    where
                        bmcm.entity = 'TECH_DEBT'
                        and bmcm.entity_code = 'CRITICAL_TECH_COMPONENT'
                ) then 'Critical'
                else 'Not Critical'
            end,
            (
                select
                    bmcm.entity_val
                from
                    bb_mst_common_master bmcm
                where
                    bmcm.entity = 'TECH_DEBT_TECH_SCORE'
                    and bmcm.entity_code = case
                        when tech_app.name in (
                            select
                                bmcm.entity_val
                            from
                                bb_mst_common_master bmcm
                            where
                                bmcm.entity = 'TECH_DEBT'
                                and bmcm.entity_code = 'CRITICAL_TECH_COMPONENT'
                        ) then 'Critical'
                        else 'Not Critical'
                    end
            ),
            ifnull (tech_debt.u_severity, 'Low'),
            (
                select
                    bmcm.entity_val
                from
                    bb_mst_common_master bmcm
                where
                    bmcm.entity = 'TECH_DEBT_EOL_SCORE'
                    and bmcm.entity_code = ifnull (tech_debt.u_severity, 'Low')
            ),
            (
                select
                    bmcm.entity_val
                from
                    bb_mst_common_master bmcm
                where
                    bmcm.entity = 'TECH_DEBT_EOL_SCORE'
                    and bmcm.entity_code = 'Critical'
            ),
            case
                when secondary_ci.install_status = 'Production' then 'Production'
                else 'Non-Production'
            end,
            (
                select
                    bmcm.entity_val
                from
                    bb_mst_common_master bmcm
                where
                    bmcm.entity = 'TECH_DEBT_INSTALL_SCORE'
                    and bmcm.entity_code = secondary_ci.install_status
            )
        order by
            app.ci_name,
            tech_app.name,
            date_format (tech_debt.sys_created_on, '%Y-%m-%d'),
            date_format (tech_debt.sys_updated_on, '%Y-%m-%d')
    ) tech_debt;