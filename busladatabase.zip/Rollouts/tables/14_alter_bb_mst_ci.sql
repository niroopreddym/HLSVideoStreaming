ALTER TABLE bb_mst_ci
-- Adding column
ADD COLUMN `tpo_staff_id` VARCHAR(7) DEFAULT NULL,
-- Adding index
ADD KEY `idx_tpoid_bb_mst_ci` (`tpo_staff_id`) USING BTREE;