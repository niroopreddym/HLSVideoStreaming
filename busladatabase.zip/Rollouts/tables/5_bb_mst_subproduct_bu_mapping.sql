CREATE SEQUENCE bb_seq_mst_subproduct_bu_mapping;

GRANT ALL ON bb_seq_mst_subproduct_bu_mapping TO 'busla_ownr';

CREATE TABLE
    `bb_mst_subproduct_bu_mapping` (
        `id` int (11) NOT NULL DEFAULT nextval (`bb_seq_mst_subproduct_bu_mapping`),
        `subproduct_id` int (11) NOT NULL,
        `business_unit_id` int (11) NOT NULL,
        `created_by` varchar(50) NOT NULL,
        `created_on` datetime NOT NULL DEFAULT current_timestamp(),
        `modified_by` varchar(50) DEFAULT NULL,
        `modified_on` datetime DEFAULT NULL ON UPDATE current_timestamp(),
        PRIMARY KEY (`id`) USING BTREE,
        UNIQUE KEY `udx_sp_bu_bb_mst_subproduct_bu_mapping` (`subproduct_id`, `business_unit_id`) USING BTREE
    ) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = DYNAMIC;