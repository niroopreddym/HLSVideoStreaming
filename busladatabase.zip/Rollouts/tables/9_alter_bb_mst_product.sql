ALTER TABLE bb_mst_product
-- Adding columns
ADD COLUMN `portfolio_id` INT (11) DEFAULT NULL,
ADD COLUMN `pillar_id` INT (11) DEFAULT NULL,
ADD COLUMN `art_id` INT (11) DEFAULT NULL,
ADD COLUMN `tpm_staff_id` VARCHAR(7) DEFAULT NULL,
ADD COLUMN `business_unit_id` INT (11) DEFAULT NULL,
ADD COLUMN `status_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP(),
-- Adding indexes
ADD KEY `idx_portfolioid_bb_mst_product` (`portfolio_id`),
ADD KEY `idx_pillar_id_bb_mst_product` (`pillar_id`),
ADD KEY `idx_art_id_bb_mst_product` (`art_id`),
ADD KEY `idx_tpm_staff_id_bb_mst_product` (`tpm_staff_id`),
ADD KEY `idx_bu_id_bb_mst_product` (`business_unit_id`);