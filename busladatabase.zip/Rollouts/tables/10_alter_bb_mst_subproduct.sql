ALTER TABLE bb_mst_subproduct
-- Adding columns
ADD COLUMN `business_unit_ids` VARCHAR(100) DEFAULT NULL,
ADD COLUMN `art_id` INT (11) DEFAULT NULL,
ADD COLUMN `tpm_staff_id` VARCHAR(7) DEFAULT NULL,
ADD COLUMN `status_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP(),
-- Adding indexes
ADD KEY `idx_tpm_staff_id_bb_mst_subproduct` (`tpm_staff_id`),
ADD KEY `idx_art_bb_mst_subproduct` (`art_id`);