SET @has_rows = EXISTS (SELECT 1 FROM `bb_ib_staging_snow_u_tech_debt_ci_inventory` LIMIT 1);

-- Only proceed to drop if @has_rows is false (no rows exist)
SET @query = IF(@has_rows, 'SELECT "Table has rows; skipping drop";', 'DROP TABLE `bb_ib_staging_snow_u_tech_debt_ci_inventory`;');
PREPARE stmt FROM @query;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
