CREATE SEQUENCE bb_seq_mst_ci_teams_mapping;

GRANT ALL ON bb_seq_mst_ci_teams_mapping TO 'busla_ownr';

CREATE TABLE
    `bb_mst_ci_teams_mapping` (
        `id` int (11) NOT NULL DEFAULT nextval (`bb_seq_mst_ci_teams_mapping`),
        `ci_id` int (11) NOT NULL,
        `team_id` int (11) NOT NULL,
        `primary_team_ind` varchar(1) DEFAULT 'N' COMMENT 'CI Primary Team Indicator, ''Y'' / ''N''',
        `is_active` varchar(1) DEFAULT 'Y' COMMENT 'If team is Active : Y for Yes or N for No',
        `created_by` varchar(50) NOT NULL,
        `created_on` datetime NOT NULL DEFAULT current_timestamp(),
        `modified_by` varchar(50) DEFAULT NULL,
        `modified_on` datetime DEFAULT NULL ON UPDATE current_timestamp(),
        PRIMARY KEY (`id`) USING BTREE,
        UNIQUE KEY `udx_art_bb_mst_ci_teams_mapping` (`ci_id`, `team_id`, `is_active`) USING BTREE
    ) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = DYNAMIC;