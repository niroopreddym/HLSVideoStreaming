CREATE SEQUENCE bb_seq_ib_staging_engg_bitbucket_pull_request;

GRANT ALL ON bb_seq_ib_staging_engg_bitbucket_pull_request TO 'busla_ownr';

CREATE TABLE
    `bb_ib_staging_engg_bitbucket_pull_request` (
        `id` int (11) NOT NULL DEFAULT nextval (`bb_seq_ib_staging_engg_bitbucket_pull_request`),
        `aat` varchar(50) DEFAULT NULL,
        `added_lines` int (11) DEFAULT NULL,
        `deleted_lines` int (11) DEFAULT NULL,
        `application_ci` varchar(50) DEFAULT NULL,
        `pr_created_by_staff_id` varchar(50) DEFAULT NULL,
        `pr_created_by_staff_name` varchar(100) DEFAULT NULL,
        `pr_created_dt` bigint (20) DEFAULT NULL,
        `pr_id` int (11) DEFAULT NULL,
        `pr_reviewers_staffid_list` text DEFAULT NULL,
        `pr_status` varchar(50) DEFAULT NULL,
        `pr_title` text DEFAULT NULL,
        `pr_updated_dt` bigint (20) DEFAULT NULL,
        `project_code` varchar(50) DEFAULT NULL,
        `repo_code` varchar(100) DEFAULT NULL,
        `stats_prepared_on_date` datetime DEFAULT NULL,
        `total_line_additions` int (11) DEFAULT NULL,
        `total_line_deletions` int (11) DEFAULT NULL,
        `created_by` varchar(50) CHARACTER
        SET
            utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
            `created_on` datetime DEFAULT current_timestamp(),
            `modified_by` varchar(50) CHARACTER
        SET
            utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
            `modified_on` datetime DEFAULT NULL ON UPDATE current_timestamp()
    ) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = DYNAMIC;