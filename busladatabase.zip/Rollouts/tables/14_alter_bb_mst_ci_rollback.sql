ALTER TABLE bb_mst_ci
-- Dropping index
DROP KEY `idx_tpoid_bb_mst_ci`,
-- Dropping column
DROP COLUMN `tpo_staff_id`;