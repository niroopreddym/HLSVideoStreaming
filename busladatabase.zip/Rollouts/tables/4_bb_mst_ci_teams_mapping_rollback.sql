SET @has_rows = EXISTS (SELECT 1 FROM `bb_mst_ci_teams_mapping` LIMIT 1);

-- Only proceed to drop if @has_rows is false (no rows exist)
SET @query = IF(@has_rows, 'SELECT "Table has rows; skipping drop";', 'DROP TABLE `bb_mst_ci_teams_mapping`;');
PREPARE stmt FROM @query;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;