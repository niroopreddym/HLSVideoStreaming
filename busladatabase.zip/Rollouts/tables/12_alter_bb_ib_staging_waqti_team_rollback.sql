ALTER TABLE bb_ib_staging_waqti_team
-- Dropping columns
DROP COLUMN `pillar_id`,
DROP COLUMN `pillar_code`,
DROP COLUMN `pillar_name`;