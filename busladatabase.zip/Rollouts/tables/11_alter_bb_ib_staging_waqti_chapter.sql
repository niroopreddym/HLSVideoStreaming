ALTER TABLE bb_ib_staging_waqti_chapter
-- Adding columns
ADD COLUMN `pillar_id` INT (11) DEFAULT NULL,
ADD COLUMN `pillar_code` VARCHAR(50) DEFAULT NULL,
ADD COLUMN `pillar_name` VARCHAR(255) DEFAULT NULL;