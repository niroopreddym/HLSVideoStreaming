CREATE SEQUENCE bb_seq_prefact_snow_u_tdci;

GRANT ALL ON bb_seq_prefact_snow_u_tdci TO 'busla_ownr';

CREATE TABLE
    `bb_prefact_snow_u_tech_debt_ci_inventory` (
        `id` int (11) NOT NULL DEFAULT nextval (`bb_seq_prefact_snow_u_tdci`),
        `u_application_ci` tinytext DEFAULT NULL COMMENT 'Application CI SYS_ID',
        `u_application_ci_name` tinytext DEFAULT NULL COMMENT 'Application CI Name',
        `u_secondary_ci` mediumtext DEFAULT NULL COMMENT 'Secondary CI SYS_ID',
        `u_secondary_ci_name` tinytext DEFAULT NULL COMMENT 'Secondary CI Name',
        `u_technical_ci` tinytext DEFAULT NULL COMMENT 'Technical CI SYS_ID',
        `u_technical_ci_name` tinytext DEFAULT NULL COMMENT 'Technical CI Name',
        `created_by` varchar(50) NOT NULL,
        `created_on` datetime NOT NULL DEFAULT current_timestamp(),
        `modified_by` varchar(50) DEFAULT NULL,
        `modified_on` datetime DEFAULT NULL ON UPDATE current_timestamp(),
        PRIMARY KEY (`id`) USING BTREE,
        UNIQUE KEY `udx_bb_prefact_snow_tdci` (
            `u_application_ci` (100),
            `u_secondary_ci` (100),
            `u_technical_ci` (100)
        ) USING BTREE,
        KEY `idx_bb_prefact_snow_tdci_application_ci` (`u_application_ci` (255)) USING BTREE,
        KEY `idx_bb_prefact_snow_tdci_application_ci_name` (`u_application_ci_name` (255)) USING BTREE,
        KEY `idx_bb_prefact_snow_tdci_secondary_ci` (`u_secondary_ci` (768)) USING BTREE,
        KEY `idx_bb_prefact_snow_tdci_secondary_ci_name` (`u_secondary_ci_name` (255)) USING BTREE,
        KEY `idx_bb_prefact_snow_tdci_technical_ci` (`u_technical_ci` (255)) USING BTREE,
        KEY `idx_bb_prefact_snow_tdci_technical_ci_name` (`u_technical_ci_name` (255)) USING BTREE
    ) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = DYNAMIC;