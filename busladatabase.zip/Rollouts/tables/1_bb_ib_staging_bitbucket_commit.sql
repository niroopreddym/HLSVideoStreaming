CREATE SEQUENCE bb_seq_ib_staging_bitbucket_commit;

GRANT ALL ON bb_seq_ib_staging_bitbucket_commit TO 'busla_ownr';

CREATE TABLE
    `bb_ib_staging_bitbucket_commit` (
        `id` int (11) NOT NULL DEFAULT nextval (`bb_seq_ib_staging_bitbucket_commit`),
        `aat` varchar(50) DEFAULT NULL,
        `application_ci` varchar(100) DEFAULT NULL,
        `author_staff_id` varchar(50) DEFAULT NULL,
        `author_staff_name` varchar(100) DEFAULT NULL,
        `author_time_stamp` bigint (20) DEFAULT NULL,
        `commit_display_id` varchar(50) DEFAULT NULL,
        `commit_id` varchar(50) DEFAULT NULL,
        `commit_message` text DEFAULT NULL,
        `committer_staff_id` varchar(50) DEFAULT NULL,
        `committer_staff_name` varchar(100) DEFAULT NULL,
        `committer_time_stamp` bigint (20) DEFAULT NULL,
        `jira_key` tinytext DEFAULT NULL,
        `pr_id` int (11) DEFAULT NULL,
        `project_code` varchar(50) DEFAULT NULL,
        `repo_code` varchar(100) DEFAULT NULL,
        `created_by` varchar(50) CHARACTER
        SET
            utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
            `created_on` datetime DEFAULT current_timestamp(),
            `modified_by` varchar(50) CHARACTER
        SET
            utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
            `modified_on` datetime DEFAULT NULL ON UPDATE current_timestamp()
    ) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = DYNAMIC;