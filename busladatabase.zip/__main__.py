from __future__ import annotations
from configparser import ConfigParser
from azure.storage.blob import BlobServiceClient
from logging import Logger
from models.dbchangelog import DbChangeLog, DatabaseChangeLog
import logging
import os

class EmailService:
    _svc_name_ = "CITP-Email-Service"
    _svc_display_name_ = "CITP Email Trigger Service"
    _svc_description_ = "CITP Email Trigger Service running on scheduled CRON"

    def __init__(self) -> None:
        self.logger = self._get_logger()

    def _get_logger(self) -> Logger:
        logger = logging.getLogger(self._svc_name_)
        logger.setLevel(logging.INFO)
        tstPath = os.path.join(os.path.dirname(__file__), "service.log")
        print("logpath:", tstPath)
        handler = logging.FileHandler(os.path.join(os.path.dirname(__file__), "service.log"))
        formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
        handler.setFormatter(formatter)
        logger.addHandler(handler)
        return logger

    def start(self):
        config = ConfigParser()
        config.read('config.ini')
        STORAGE_ACCOUNT_URL = config.get("AzureBlobStorage", "account_url")
        STORAGE_ACCOUNT_KEY = config.get("AzureBlobStorage", "account_key")
        CONTAINER_NAME = config.get("AzureBlobStorage", "container_name")
        CHANGELOG_BLOB_NAME = config.get("AzureBlobStorage", "changelog_blob_name")
        # Initialize the Blob Service Client
        blob_service_client = BlobServiceClient(account_url=STORAGE_ACCOUNT_URL, credential=STORAGE_ACCOUNT_KEY)
        container_client = blob_service_client.get_container_client(CONTAINER_NAME)

def __init__() -> None:
    print("intialising main components")

# Example usage
if __name__ == "__main__":
    # Example of reading the YAML
    change_log: DbChangeLog = DbChangeLog()
    trackedChangeLog:DatabaseChangeLog = change_log.read_yaml('C:/Users/S495167/python/emirates.com/busladatabase/db.changelog-master.yaml')
    print(trackedChangeLog)

    # Example of writing back to YAML
    # write_yaml('output.yaml', db_change_log) 