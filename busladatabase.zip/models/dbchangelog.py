from __future__ import annotations
from typing import List, Optional
import yaml
from dataclasses import dataclass, asdict
import logging
import getpass

# Model Definitions
@dataclass
class SqlFile:
    """Represents an external SQL file."""
    path: str

@dataclass
class Sql:
    """Represents an inline SQL statement."""
    content: str

@dataclass
class Change:
    sql: Optional[Sql] = None
    sqlFile: Optional[SqlFile] = None

@dataclass
class ChangeSet:
    id: int
    author: str
    changes: List[Change]
    rollback: List[Change]

@dataclass
class DatabaseChangeLog:
    databaseChangeLog: List[ChangeSet]

class DbChangeLog:
    _instance: Optional['DbChangeLog'] = None
    def __init__(self) -> None:
         logging.info(f'DbChangeLog instance')

    def __new__(cls, *args, **kwargs) -> 'DbChangeLog':
        if not cls._instance:
            cls._instance = super(DbChangeLog, cls).__new__(cls)
        return cls._instance

    # Function to read from a YAML file
    def read_yaml(self, file_path: str) -> DatabaseChangeLog:
        logging.info("reading the yaml file")
        with open(file_path, 'r') as file:
            data = yaml.safe_load(file)
        
        expected_fields = set(DatabaseChangeLog.__annotations__.keys())
        filtered_data = {key: value for key, value in data.items() if key in expected_fields}
        response = DatabaseChangeLog(**filtered_data)
        return response
    
    # this is for local we have to make it generic to work for other details
    def add_new_changeset(self, file_path: str) -> DatabaseChangeLog:
        change_set_log:DatabaseChangeLog = self.read_yaml(file_path)
        changeset: ChangeSet = ChangeSet(
            id=100, 
            author='DSA-Pull-your_username', 
            changes=[
                SqlFile(path='Rollouts/tables/test_table_creation.sql') # //use signed URL here or use the below lets wrap the re
            ], 
            rollback=[
                Sql(content=f"""Rollouts/tables/test_table_creation_rollback.sql""") # this is in line style
            ]
        )
        change_set_log.databaseChangeLog.append(changeset)


    # Function to write to a YAML file
    def write_yaml(self, file_path: str, data: DatabaseChangeLog):
        logging.info("writing the yaml file")
        with open(file_path, 'w') as file:
            yaml.dump(asdict(data), file, default_flow_style=False)

