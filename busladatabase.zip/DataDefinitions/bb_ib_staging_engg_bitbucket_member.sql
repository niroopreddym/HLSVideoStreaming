CREATE SEQUENCE bb_seq_ib_staging_engg_bitbucket_member;

CREATE TABLE
    `bb_ib_staging_engg_bitbucket_member` (
        `id` INT (11) NOT NULL DEFAULT nextval (`bb_seq_ib_staging_engg_bitbucket_member`),
        `staging_engg_bitbucket_id` INT (11) NOT NULL,
        `user_id` VARCHAR(50) NOT NULL COLLATE 'utf8mb4_general_ci',
        `is_pr_reviewer` VARCHAR(1) NOT NULL DEFAULT 'N' COMMENT 'Y / N' COLLATE 'utf8mb4_general_ci',
        `is_pr_contributor` VARCHAR(1) NOT NULL DEFAULT 'N' COMMENT 'Y / N' COLLATE 'utf8mb4_general_ci',
        `is_pr_author` VARCHAR(1) NOT NULL DEFAULT 'N' COMMENT 'Y / N' COLLATE 'utf8mb4_general_ci',
        `created_by` VARCHAR(50) NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
        `created_on` DATETIME NOT NULL DEFAULT current_timestamp(),
        `modified_by` VARCHAR(50) NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
        `modified_on` DATETIME NULL DEFAULT NULL ON UPDATE current_timestamp(),
        PRIMARY KEY (`id`) USING BTREE
    ) COLLATE = 'utf8mb4_general_ci' ENGINE = InnoDB;