CREATE SEQUENCE bb_seq_mst_capability;

CREATE TABLE
    `bb_mst_capability` (
        `id` INT (11) NOT NULL DEFAULT nextval (`bb_seq_mst_capability`) COMMENT 'Capability ID',
        `capability_code` VARCHAR(25) NOT NULL DEFAULT concat (
            'CPBLT',
            lpad (lastval (`buslams`.`bb_seq_mst_capability`), 8, 0)
        ) COMMENT 'Capability Code' COLLATE 'utf8mb4_general_ci',
        `capability_name` VARCHAR(150) NOT NULL COMMENT 'Capability Name' COLLATE 'utf8mb4_general_ci',
        `capability_desc` VARCHAR(250) NOT NULL COMMENT 'Capability Description' COLLATE 'utf8mb4_general_ci',
        `capability_type` VARCHAR(10) NOT NULL COMMENT 'Capability Type - L1 or L2' COLLATE 'utf8mb4_general_ci',
        `parent_id` INT (11) NOT NULL COMMENT 'Parent Capability ID for L2 Capabilities',
        `status` VARCHAR(1) NOT NULL COMMENT 'Status' COLLATE 'utf8mb4_general_ci',
        `remarks` VARCHAR(500) NULL DEFAULT NULL COMMENT 'Remarks' COLLATE 'utf8mb4_general_ci',
        `created_by` VARCHAR(20) NOT NULL COMMENT 'Created By' COLLATE 'utf8mb4_general_ci',
        `created_on` DATETIME NOT NULL DEFAULT current_timestamp() COMMENT 'Created On',
        `modified_by` VARCHAR(20) NULL DEFAULT NULL COMMENT 'Modified By' COLLATE 'utf8mb4_general_ci',
        `modified_on` DATETIME NULL DEFAULT NULL ON UPDATE current_timestamp() COMMENT 'Modified On',
        PRIMARY KEY (`id`) USING BTREE,
        UNIQUE INDEX `udx_cp_nm_bb_mst_capability` (`capability_name`, `capability_type`) USING BTREE,
        UNIQUE INDEX `udx_cp_code_bb_mst_capability` (`capability_code`) USING BTREE,
        INDEX `idx_parent_id_bb_mst_capability` (`parent_id`) USING BTREE
    ) COLLATE = 'utf8mb4_general_ci' ENGINE = InnoDB ROW_FORMAT = DYNAMIC;