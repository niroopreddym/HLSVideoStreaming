CREATE SEQUENCE bb_seq_mst_bu_cc_mapping;

CREATE TABLE
    `bb_mst_bu_cc_mapping` (
        `id` INT (11) NOT NULL DEFAULT nextval (`bb_seq_mst_bu_cc_mapping`),
        `business_unit_id` INT (11) NULL DEFAULT NULL,
        `Cost_Center_Finance_Code` INT (6) NULL DEFAULT NULL,
        `Cost_Center` VARCHAR(6) NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
        `Cost_Center_Shortcut` VARCHAR(5) NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
        `Cost_Center_Description` VARCHAR(150) NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
        `created_by` VARCHAR(50) NOT NULL COLLATE 'utf8mb4_general_ci',
        `created_on` DATETIME NOT NULL DEFAULT current_timestamp(),
        `modified_by` VARCHAR(50) NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
        `modified_on` DATETIME NULL DEFAULT NULL ON UPDATE current_timestamp()
    ) COLLATE = 'utf8mb4_general_ci' ENGINE = InnoDB;