CREATE SEQUENCE bb_seq_mst_pillar;

CREATE TABLE
    `bb_mst_pillar` (
        `id` INT (11) NOT NULL DEFAULT nextval (`bb_seq_mst_pillar`),
        `waqti_id` INT (11) NULL DEFAULT NULL,
        `pillar_code` VARCHAR(25) NULL DEFAULT NULL COMMENT 'Pillar Code Unique Identifier' COLLATE 'utf8mb4_general_ci',
        `pillar_short_name` VARCHAR(50) NOT NULL COMMENT 'Pillar Short Name' COLLATE 'utf8mb4_general_ci',
        `pillar_name` VARCHAR(100) NOT NULL COMMENT 'Pillar Name' COLLATE 'utf8mb4_general_ci',
        `portfolio_id` INT (11) NOT NULL,
        `status` VARCHAR(1) NOT NULL DEFAULT 'Y' COMMENT 'Active=Y, Inactive=N' COLLATE 'utf8mb4_general_ci',
        `status_date` DATETIME NOT NULL DEFAULT current_timestamp(),
        `created_by` VARCHAR(50) NOT NULL COLLATE 'utf8mb4_general_ci',
        `created_on` DATETIME NOT NULL DEFAULT current_timestamp(),
        `modified_by` VARCHAR(50) NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
        `modified_on` DATETIME NULL DEFAULT NULL ON UPDATE current_timestamp(),
        PRIMARY KEY (`id`) USING BTREE,
        UNIQUE INDEX `udx_waqti_id_bb_mst_pillar` (`waqti_id`) USING BTREE,
        INDEX `idx_pillar_name_bb_mst_pillar` (`portfolio_id`) USING BTREE,
        INDEX `idx_portfolio_bb_mst_pillar` (`pillar_name`) USING BTREE,
        INDEX `idx_pillar_sn_bb_mst_pillar` (`pillar_short_name`, `status`) USING BTREE,
        INDEX `idx_pillarcd_bb_mst_pillar` (`pillar_code`) USING BTREE
    ) COLLATE = 'utf8mb4_general_ci' ENGINE = InnoDB ROW_FORMAT = DYNAMIC;