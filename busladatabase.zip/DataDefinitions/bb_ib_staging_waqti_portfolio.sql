CREATE SEQUENCE bb_seq_ib_staging_waqti_portfolio;

CREATE TABLE
    `bb_ib_staging_waqti_portfolio` (
        `id` INT (11) NOT NULL DEFAULT nextval (`bb_seq_ib_staging_waqti_portfolio`),
        `waqti_id` INT (11) NULL DEFAULT NULL,
        `portfolio_name` VARCHAR(50) NOT NULL COLLATE 'utf8mb4_general_ci',
        `portfolio_desc` VARCHAR(100) NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
        `status` VARCHAR(1) NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
        `sys_created_by` VARCHAR(50) NOT NULL COMMENT 'Created by in Waqti' COLLATE 'utf8mb4_general_ci',
        `sys_created_on` DATETIME NULL DEFAULT NULL COMMENT 'Created on in Waqti',
        `sys_modified_by` VARCHAR(50) NULL DEFAULT NULL COMMENT 'Modified by in Waqti' COLLATE 'utf8mb4_general_ci',
        `sys_modified_on` DATETIME NULL DEFAULT NULL COMMENT 'Modified on in Waqti',
        `created_by` VARCHAR(50) NOT NULL DEFAULT 'UPLOAD' COLLATE 'utf8mb4_general_ci',
        `created_on` DATETIME NOT NULL DEFAULT current_timestamp(),
        `modified_by` VARCHAR(50) NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
        `modified_on` DATETIME NULL DEFAULT NULL ON UPDATE current_timestamp(),
        PRIMARY KEY (`id`) USING BTREE,
        INDEX `idx_pf_name_waqti_portfolio` (`portfolio_name`) USING BTREE,
        INDEX `idx_waqti_id_waqti_portfolio` (`waqti_id`) USING BTREE,
        INDEX `idx_waqti_id_waqti_created_on` (`created_on`) USING BTREE
    ) COLLATE = 'utf8mb4_general_ci' ENGINE = InnoDB ROW_FORMAT = DYNAMIC;