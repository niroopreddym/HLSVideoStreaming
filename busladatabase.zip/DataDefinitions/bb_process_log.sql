CREATE SEQUENCE bb_seq_process_log;

CREATE TABLE
    `bb_process_log` (
        `id` INT (11) NOT NULL DEFAULT nextval (`bb_seq_process_log`),
        `process` VARCHAR(100) NOT NULL COLLATE 'utf8mb4_general_ci',
        `indicator` DOUBLE NULL DEFAULT NULL,
        `log_desc` VARCHAR(3000) NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
        `created_by` VARCHAR(20) NOT NULL COLLATE 'utf8mb4_general_ci',
        `created_on` DATETIME NOT NULL DEFAULT current_timestamp(),
        `bb_process_id` INT (11) NULL DEFAULT NULL,
        `hostname` TINYTEXT NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
        PRIMARY KEY (`id`) USING BTREE
    ) COLLATE = 'utf8mb4_general_ci' ENGINE = InnoDB ROW_FORMAT = DYNAMIC;