CREATE SEQUENCE bb_seq_snow_purge_history;

CREATE TABLE
    `bb_snow_purge_history` (
        `id` INT (11) NOT NULL DEFAULT nextval (`bb_seq_snow_purge_history`),
        `sys_id` TINYTEXT NOT NULL COLLATE 'utf8mb4_general_ci',
        `table_name` VARCHAR(100) NOT NULL COLLATE 'utf8mb4_general_ci',
        `deletion_time` DATETIME NOT NULL,
        `status` VARCHAR(1) NOT NULL DEFAULT 'N' COMMENT 'Default, Pending = N, Processed = Y' COLLATE 'utf8mb4_general_ci',
        `status_updated_on` DATETIME NOT NULL DEFAULT current_timestamp(),
        `created_by` VARCHAR(50) NOT NULL COLLATE 'utf8mb4_general_ci',
        `created_on` DATETIME NOT NULL DEFAULT current_timestamp(),
        `modified_by` VARCHAR(50) NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
        `modified_on` DATETIME NULL DEFAULT NULL ON UPDATE current_timestamp(),
        PRIMARY KEY (`id`) USING BTREE,
        INDEX `bb_idx_snow_purge_history_sys_id` (`sys_id` (255)) USING BTREE,
        INDEX `bb_idx_snow_purge_history_table_name` (`table_name`) USING BTREE,
        INDEX `bb_idx_snow_purge_history_status` (`status`) USING BTREE,
        INDEX `bb_idx_snow_purge_history_created_on` (`created_on`) USING BTREE
    ) COLLATE = 'utf8mb4_general_ci' ENGINE = InnoDB;