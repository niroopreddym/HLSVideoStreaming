CREATE TABLE
    `bb_rollup_sub_category` (
        `id` INT (11) NOT NULL,
        `sub_category_id` INT (11) NULL DEFAULT NULL,
        `weightage` FLOAT NULL DEFAULT NULL,
        `created_by` VARCHAR(50) NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
        `created_on` DATETIME NULL DEFAULT current_timestamp(),
        `modified_by` VARCHAR(50) NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
        `modified_on` DATETIME NULL DEFAULT NULL ON UPDATE current_timestamp(),
        PRIMARY KEY (`id`) USING BTREE
    ) COLLATE = 'utf8mb4_general_ci' ENGINE = InnoDB;