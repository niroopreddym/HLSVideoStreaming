CREATE TABLE
    `bb_job_run_details` (
        `id` INT (11) NOT NULL,
        `job_name` VARCHAR(100) NOT NULL COLLATE 'utf8mb4_unicode_ci',
        `cron_expression` VARCHAR(50) NULL DEFAULT NULL COLLATE 'utf8mb4_unicode_ci',
        `job_group` VARCHAR(100) NOT NULL COLLATE 'utf8mb4_unicode_ci',
        `job_status` VARCHAR(1) NULL DEFAULT NULL COLLATE 'utf8mb4_unicode_ci',
        `job_execution_status` VARCHAR(20) NULL DEFAULT NULL COMMENT 'Started, InProgress, Completed, Failed' COLLATE 'utf8mb4_unicode_ci',
        `job_started_on` DATETIME NULL DEFAULT NULL,
        `job_completed_on` DATETIME NULL DEFAULT NULL,
        `hostname` VARCHAR(50) NULL DEFAULT NULL COLLATE 'utf8mb4_unicode_ci',
        `created_by` VARCHAR(20) NOT NULL COLLATE 'utf8mb4_unicode_ci',
        `created_on` DATETIME NOT NULL DEFAULT current_timestamp(),
        `modified_by` VARCHAR(20) NULL DEFAULT NULL COLLATE 'utf8mb4_unicode_ci',
        `modified_on` DATETIME NULL DEFAULT NULL ON UPDATE current_timestamp(),
        PRIMARY KEY (`id`) USING BTREE
    ) COLLATE = 'utf8mb4_general_ci' ENGINE = InnoDB;