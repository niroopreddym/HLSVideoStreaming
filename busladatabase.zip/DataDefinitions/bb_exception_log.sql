CREATE SEQUENCE bb_seq_exception_log;

CREATE TABLE
    `bb_exception_log` (
        `id` INT (15) NOT NULL DEFAULT nextval (`bb_seq_exception_log`),
        `trans_date` TIMESTAMP NULL DEFAULT NULL,
        `error` VARCHAR(4000) NULL DEFAULT NULL COLLATE 'utf8mb4_unicode_ci',
        `cause` LONGTEXT NULL DEFAULT NULL COLLATE 'utf8mb4_unicode_ci',
        `created_by` VARCHAR(20) NULL DEFAULT NULL COLLATE 'utf8mb4_unicode_ci',
        `created_on` DATETIME NULL DEFAULT NULL,
        `log_type` VARCHAR(100) NULL DEFAULT NULL COLLATE 'utf8mb4_unicode_ci',
        `intimated_date` DATE NULL DEFAULT NULL,
        `hostname` TINYTEXT NULL DEFAULT NULL COLLATE 'utf8mb4_unicode_ci',
        `method_name` VARCHAR(500) NULL DEFAULT NULL COLLATE 'utf8mb4_unicode_ci',
        `service_name` VARCHAR(500) NULL DEFAULT NULL COLLATE 'utf8mb4_unicode_ci',
        `modified_by` VARCHAR(10) NULL DEFAULT NULL COLLATE 'utf8mb4_unicode_ci',
        `modified_on` DATETIME NULL DEFAULT NULL,
        PRIMARY KEY (`id`) USING BTREE
    ) COLLATE = 'utf8mb4_general_ci' ENGINE = InnoDB;