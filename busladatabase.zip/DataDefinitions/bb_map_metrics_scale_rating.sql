CREATE SEQUENCE bb_seq_map_metrics_scale_rating;

CREATE TABLE
    `bb_map_metrics_scale_rating` (
        `id` INT (11) NOT NULL DEFAULT nextval (`bb_seq_map_metrics_scale_rating`),
        `metrics_id` INT (11) NOT NULL,
        `scale_value_min` VARCHAR(50) NOT NULL COLLATE 'utf8mb4_general_ci',
        `scale_value_max` VARCHAR(50) NOT NULL COLLATE 'utf8mb4_general_ci',
        `scale_indicator` VARCHAR(1) NOT NULL COLLATE 'utf8mb4_general_ci',
        `tier` VARCHAR(10) NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
        `scale_rating` TINYINT (4) NOT NULL DEFAULT '0',
        `created_by` VARCHAR(50) NOT NULL COLLATE 'utf8mb4_general_ci',
        `created_on` DATETIME NOT NULL DEFAULT current_timestamp(),
        `modified_by` VARCHAR(50) NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
        `modified_on` DATETIME NULL DEFAULT NULL ON UPDATE current_timestamp(),
        PRIMARY KEY (`id`) USING BTREE
    ) COLLATE = 'utf8mb4_general_ci' ENGINE = InnoDB;