CREATE SEQUENCE bb_seq_mst_product;

CREATE TABLE
    `bb_mst_product` (
        `id` INT (11) NOT NULL DEFAULT nextval (`bb_seq_mst_product`),
        `capability_id` INT (11) NULL DEFAULT NULL COMMENT 'Refers to Level 1 capability',
        `product_code` VARCHAR(25) NOT NULL DEFAULT concat (
            'PRDCT',
            lpad (lastval (`buslams`.`bb_seq_mst_product`), 8, 0)
        ) COLLATE 'utf8mb4_general_ci',
        `product_name` VARCHAR(150) NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
        `product_desc` VARCHAR(1000) NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
        `product_ownr` VARCHAR(100) NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
        `technical_product_manager` VARCHAR(100) NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
        `technical_product_owner` VARCHAR(100) NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
        `about_product` VARCHAR(500) NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
        `type` VARCHAR(50) NULL DEFAULT NULL COMMENT 'Refers to Product Plaform' COLLATE 'utf8mb4_general_ci',
        `status` VARCHAR(1) NULL DEFAULT 'Y' COMMENT 'COMMENT \'Active=Y, Inactive=N\'' COLLATE 'utf8mb4_general_ci',
        `remarks` VARCHAR(500) NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
        `created_by` VARCHAR(20) NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
        `created_on` DATETIME NULL DEFAULT current_timestamp(),
        `modified_by` VARCHAR(20) NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
        `modified_on` DATETIME NULL DEFAULT NULL ON UPDATE current_timestamp(),
        PRIMARY KEY (`id`) USING BTREE,
        UNIQUE INDEX `udx_productcd_bb_mst_product` (`product_code`) USING BTREE,
        UNIQUE INDEX `udx_productnm_bb_mst_product` (`product_name`) USING BTREE,
        INDEX `idx_capability_bb_mst_product` (`capability_id`) USING BTREE
    ) COLLATE = 'utf8mb4_general_ci' ENGINE = InnoDB;