CREATE SEQUENCE bb_seq_ib_staging_engg;

CREATE TABLE
    `bb_ib_staging_engg` (
        `id` INT (11) NOT NULL DEFAULT nextval (`bb_seq_ib_staging_engg`),
        `stats_prepared_on` DATETIME NOT NULL,
        `data_source` VARCHAR(50) NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
        `data` VARCHAR(10240) NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
        `status` VARCHAR(1) NOT NULL DEFAULT 'N' COLLATE 'utf8mb4_general_ci',
        `status_date` DATETIME NULL DEFAULT NULL,
        `created_by` VARCHAR(50) NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
        `created_on` DATETIME NOT NULL DEFAULT current_timestamp(),
        `modified_by` VARCHAR(50) NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
        `modified_on` DATETIME NULL DEFAULT NULL ON UPDATE current_timestamp(),
        PRIMARY KEY (`id`) USING BTREE,
        INDEX `idx_ib_staging_engg_stats_prepared_on` (`stats_prepared_on`) USING BTREE,
        INDEX `idx_ib_staging_engg_datasource` (`data_source`) USING BTREE,
        INDEX `idx_ib_staging_engg_created_on` (`created_on`) USING BTREE
    ) COLLATE = 'utf8mb4_general_ci' ENGINE = InnoDB ROW_FORMAT = DYNAMIC;