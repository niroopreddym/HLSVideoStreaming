CREATE SEQUENCE bb_seq_mst_portfolio;

CREATE TABLE
    `bb_mst_portfolio` (
        `id` INT (11) NOT NULL DEFAULT nextval (`bb_seq_mst_portfolio`),
        `waqti_id` INT (11) NULL DEFAULT NULL,
        `portfolio_code` VARCHAR(25) NOT NULL DEFAULT concat (
            'PORTFOLIO',
            lpad (lastval (`buslams`.`bb_seq_mst_portfolio`), 8, 0)
        ) COLLATE 'utf8mb4_general_ci',
        `portfolio_name` VARCHAR(50) NOT NULL COLLATE 'utf8mb4_general_ci',
        `portfolio_desc` VARCHAR(100) NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
        `portfolio_type` VARCHAR(10) NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
        `created_by` VARCHAR(50) NOT NULL DEFAULT 'UPLOAD' COLLATE 'utf8mb4_general_ci',
        `created_on` DATETIME NOT NULL DEFAULT current_timestamp(),
        `modified_by` VARCHAR(50) NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
        `modified_on` DATETIME NULL DEFAULT NULL ON UPDATE current_timestamp(),
        PRIMARY KEY (`id`) USING BTREE,
        UNIQUE INDEX `udx_pf_code_bb_mst_portfolio` (`portfolio_code`) USING BTREE,
        UNIQUE INDEX `udx_waqti_id_bb_mst_portfolio` (`waqti_id`) USING BTREE,
        INDEX `idx_pf_name_bb_mst_portfolio` (`portfolio_name`) USING BTREE,
        INDEX `idx_pf_desc_bb_mst_portfolio` (`portfolio_desc`) USING BTREE
    ) COLLATE = 'utf8mb4_general_ci' ENGINE = InnoDB ROW_FORMAT = DYNAMIC;