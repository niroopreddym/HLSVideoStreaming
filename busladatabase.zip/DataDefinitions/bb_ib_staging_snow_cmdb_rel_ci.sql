CREAT SEQUENCE bb_seq_ib_staging_snow_cmdb_rel_ci;

CREATE TABLE
    `bb_ib_staging_snow_cmdb_rel_ci` (
        `id` INT (11) NOT NULL DEFAULT nextval (`bb_seq_ib_staging_snow_cmdb_rel_ci`),
        `child` MEDIUMTEXT NULL DEFAULT NULL COMMENT 'Child' COLLATE 'utf8mb4_general_ci',
        `connection_strength` TINYTEXT NULL DEFAULT NULL COMMENT 'Connection Strength' COLLATE 'utf8mb4_general_ci',
        `parent` MEDIUMTEXT NULL DEFAULT NULL COMMENT 'Parent' COLLATE 'utf8mb4_general_ci',
        `percent_outage` TINYTEXT NULL DEFAULT NULL COMMENT 'Percent outage' COLLATE 'utf8mb4_general_ci',
        `port` INT (11) NULL DEFAULT NULL COMMENT 'Port',
        `sys_created_by` TINYTEXT NULL DEFAULT NULL COMMENT 'Created by' COLLATE 'utf8mb4_general_ci',
        `sys_created_on` DATETIME NULL DEFAULT NULL COMMENT 'Created',
        `sys_id` MEDIUMTEXT NULL DEFAULT NULL COMMENT 'Sys ID' COLLATE 'utf8mb4_general_ci',
        `sys_mod_count` TINYTEXT NULL DEFAULT NULL COMMENT 'Updates' COLLATE 'utf8mb4_general_ci',
        `sys_updated_by` TINYTEXT NULL DEFAULT NULL COMMENT 'Updated by' COLLATE 'utf8mb4_general_ci',
        `sys_updated_on` DATETIME NULL DEFAULT NULL COMMENT 'Updated',
        `type` MEDIUMTEXT NULL DEFAULT NULL COMMENT 'Type' COLLATE 'utf8mb4_general_ci',
        `created_by` VARCHAR(50) NOT NULL COLLATE 'utf8mb4_general_ci',
        `created_on` DATETIME NOT NULL DEFAULT current_timestamp(),
        `modified_by` VARCHAR(50) NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
        `modified_on` DATETIME NULL DEFAULT NULL ON UPDATE current_timestamp(),
        PRIMARY KEY (`id`) USING BTREE,
        INDEX `idx_bb_ib_staging_snow_cmdb_rel_ci_sys_id` (`sys_id` (100)) USING BTREE,
        INDEX `idx_bb_ib_staging_snow_cmdb_rel_ci_child` (`child` (100)) USING BTREE,
        INDEX `idx_bb_ib_staging_snow_cmdb_rel_ci_parent` (`parent` (100)) USING BTREE,
        INDEX `idx_bb_ib_staging_snow_cmdb_rel_ci_type` (`type` (100)) USING BTREE,
        INDEX `idx_bb_ib_staging_snow_cmdb_rel_ci_sys_created_on` (`sys_created_on`) USING BTREE,
        INDEX `idx_bb_ib_staging_snow_cmdb_rel_ci_sys_updated_on` (`sys_updated_on`) USING BTREE,
        INDEX `idx_bb_ib_staging_snow_cmdb_rel_ci_created_on` (`created_on`) USING BTREE,
        INDEX `idx_bb_ib_staging_snow_cmdb_rel_ci_modified_on` (`modified_on`) USING BTREE
    ) COLLATE = 'utf8mb4_general_ci' ENGINE = InnoDB ROW_FORMAT = DYNAMIC;