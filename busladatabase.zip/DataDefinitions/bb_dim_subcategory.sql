CREATE SEQUENCE bb_seq_dim_subcategory;

CREATE TABLE
    `bb_dim_subcategory` (
        `id` INT (11) NOT NULL DEFAULT nextval (`bb_seq_dim_subcategory`),
        `category_id` INT (11) NULL DEFAULT NULL,
        `subcategory_code` VARCHAR(150) NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
        `subcategory_desc` VARCHAR(150) NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
        `created_by` VARCHAR(50) NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
        `created_on` DATETIME NULL DEFAULT current_timestamp(),
        `modified_by` VARCHAR(50) NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
        `modified_on` DATETIME NULL DEFAULT NULL ON UPDATE current_timestamp(),
        PRIMARY KEY (`id`) USING BTREE,
        INDEX `idx_dim_subcategory_subcategory_code` (`subcategory_code`) USING BTREE,
        INDEX `idx_category_bb_mst_category` (`category_id`) USING BTREE
    ) COLLATE = 'utf8mb4_general_ci' ENGINE = InnoDB ROW_FORMAT = DYNAMIC;