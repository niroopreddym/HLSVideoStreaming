CREATE SEQUENCE bb_seq_prefact_waqti_chapter;

CREATE TABLE
    `bb_prefact_waqti_chapter` (
        `id` INT (11) NOT NULL DEFAULT nextval (`bb_seq_prefact_waqti_chapter`),
        `waqti_id` INT (11) NULL DEFAULT NULL,
        `chapter_code` VARCHAR(50) NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
        `chapter_name` VARCHAR(150) NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
        `status` VARCHAR(1) NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
        `sys_created_by` VARCHAR(50) NOT NULL COMMENT 'Created by in Waqti' COLLATE 'utf8mb4_general_ci',
        `sys_created_on` DATETIME NULL DEFAULT NULL COMMENT 'Created on in Waqti',
        `sys_modified_by` VARCHAR(50) NULL DEFAULT NULL COMMENT 'Modified by in Waqti' COLLATE 'utf8mb4_general_ci',
        `sys_modified_on` DATETIME NULL DEFAULT NULL COMMENT 'Modified on in Waqti',
        `created_by` VARCHAR(50) NULL DEFAULT 'UPLOAD' COLLATE 'utf8mb4_general_ci',
        `created_on` DATETIME NOT NULL DEFAULT current_timestamp(),
        `modified_by` VARCHAR(50) NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
        `modified_on` DATETIME NULL DEFAULT NULL ON UPDATE current_timestamp(),
        PRIMARY KEY (`id`) USING BTREE,
        UNIQUE INDEX `udx_waqti_id_prefact_waqti_chapter` (`waqti_id`) USING BTREE,
        INDEX `idx_chapter_nm_prefact_waqti_chapter` (`chapter_name`) USING BTREE,
        INDEX `idx_chapter_cd_prefact_waqti_chapter` (`chapter_code`) USING BTREE
    ) COLLATE = 'utf8mb4_general_ci' ENGINE = InnoDB ROW_FORMAT = DYNAMIC;