CREATE SEQUENCE bb_seq_mst_common_master;

CREATE TABLE
    `bb_mst_common_master` (
        `id` INT (11) NOT NULL DEFAULT nextval (`bb_seq_mst_common_master`),
        `entity` VARCHAR(100) NOT NULL COLLATE 'utf8mb4_general_ci',
        `entity_code` VARCHAR(100) NOT NULL COLLATE 'utf8mb4_general_ci',
        `entity_val` VARCHAR(100) NOT NULL COLLATE 'utf8mb4_general_ci',
        `entity_desc` VARCHAR(1000) NOT NULL COLLATE 'utf8mb4_general_ci',
        `entity_status` VARCHAR(1) NOT NULL DEFAULT 'Y' COMMENT 'active = Y, not active = N' COLLATE 'utf8mb4_general_ci',
        `status_date` DATETIME NOT NULL DEFAULT current_timestamp(),
        `created_by` VARCHAR(50) NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
        `created_on` DATETIME NOT NULL DEFAULT current_timestamp(),
        `modified_by` VARCHAR(50) NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
        `modified_on` DATETIME NULL DEFAULT NULL ON UPDATE current_timestamp(),
        PRIMARY KEY (`id`) USING BTREE,
        UNIQUE INDEX `bb_udx_entity_mst_common_master` (`entity`, `entity_code`, `entity_val`) USING BTREE,
        INDEX `bb_idx_created_on_mst_common_master` (`created_on`) USING BTREE,
        INDEX `bb_idx_entity_mst_common_master` (`entity`) USING BTREE,
        INDEX `bb_idx_entity_code_mst_common_master` (`entity_code`) USING BTREE,
        INDEX `bb_idx_entity_status_mst_common_master` (`entity_status`) USING BTREE
    ) COLLATE = 'utf8mb4_general_ci' ENGINE = InnoDB ROW_FORMAT = DYNAMIC;