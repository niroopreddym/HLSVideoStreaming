CREATE SEQUENCE bb_seq_mst_subproduct;

CREATE TABLE
    `bb_mst_subproduct` (
        `id` INT (11) NOT NULL DEFAULT nextval (`bb_seq_mst_subproduct`),
        `product_id` INT (11) NULL DEFAULT NULL,
        `capability_id` INT (11) NULL DEFAULT NULL COMMENT 'Refers to Level 2 capability',
        `business_unit_id` INT (11) NULL DEFAULT NULL COMMENT 'Refers to Business Unit ID',
        `subproduct_code` VARCHAR(25) NOT NULL DEFAULT concat (
            'SUBPRDCT',
            lpad (lastval (`buslams`.`bb_seq_mst_subproduct`), 8, 0)
        ) COLLATE 'utf8mb4_general_ci',
        `subproduct_name` VARCHAR(150) NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
        `subproduct_desc` VARCHAR(1000) NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
        `about_subproduct` VARCHAR(500) NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
        `business_ownr` VARCHAR(100) NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
        `technical_product_manager` VARCHAR(100) NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
        `technical_product_owner` VARCHAR(100) NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
        `status` VARCHAR(1) NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
        `remarks` VARCHAR(500) NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
        `created_by` VARCHAR(20) NOT NULL COLLATE 'utf8mb4_general_ci',
        `created_on` DATETIME NOT NULL DEFAULT current_timestamp(),
        `modified_by` VARCHAR(20) NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
        `modified_on` DATETIME NULL DEFAULT NULL ON UPDATE current_timestamp(),
        PRIMARY KEY (`id`) USING BTREE,
        UNIQUE INDEX `udx_subproduct_cd_bb_mst_subproduct` (`subproduct_code`) USING BTREE,
        UNIQUE INDEX `udx_subproduct_nm_bb_mst_subproduct` (`subproduct_name`) USING BTREE,
        INDEX `idx_cp_id_bb_mst_subproduct` (`capability_id`) USING BTREE,
        INDEX `idx_bu_id_bb_mst_subproduct` (`business_unit_id`) USING BTREE,
        INDEX `idx_product_id_bb_mst_subproduct` (`product_id`) USING BTREE
    ) COLLATE = 'utf8mb4_general_ci' ENGINE = InnoDB;