CREATE SEQUENCE bb_seq_snow_fact_change_request;

CREATE TABLE
    `bb_snow_fact_change_request` (
        `id` INT (11) NOT NULL DEFAULT nextval (`bb_seq_snow_fact_change_request`),
        `dim_ci_id` INT (11) NULL DEFAULT NULL,
        `dim_time_id` INT (11) NULL DEFAULT NULL,
        `close_code` TINYTEXT NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
        `number` TINYTEXT NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
        `state` TINYTEXT NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
        `created_by` VARCHAR(50) NOT NULL COLLATE 'utf8mb4_general_ci',
        `created_on` DATETIME NOT NULL DEFAULT current_timestamp(),
        `modified_by` VARCHAR(50) NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
        `modified_on` DATETIME NULL DEFAULT NULL ON UPDATE current_timestamp(),
        PRIMARY KEY (`id`) USING BTREE
    ) COLLATE = 'utf8mb4_general_ci' ENGINE = InnoDB;