CREATE SEQUENCE bb_seq_mst_business_unit;

CREATE TABLE
    `bb_mst_business_unit` (
        `id` INT (11) NOT NULL DEFAULT nextval (`bb_seq_mst_business_unit`),
        `business_unit_code` VARCHAR(25) NOT NULL DEFAULT concat (
            'BUC',
            lpad (
                lastval (`buslams`.`bb_seq_mst_business_unit`),
                8,
                0
            )
        ) COLLATE 'utf8mb4_general_ci',
        `business_unit_name` VARCHAR(150) NOT NULL COLLATE 'utf8mb4_general_ci',
        `business_unit_desc` VARCHAR(250) NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
        `status` VARCHAR(1) NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
        `company_name` VARCHAR(10) NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
        `company_code` VARCHAR(2) NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
        `remarks` VARCHAR(500) NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
        `created_by` VARCHAR(20) NOT NULL COLLATE 'utf8mb4_general_ci',
        `created_on` DATETIME NOT NULL DEFAULT current_timestamp(),
        `modified_by` VARCHAR(20) NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
        `modified_on` DATETIME NULL DEFAULT NULL ON UPDATE current_timestamp(),
        PRIMARY KEY (`id`) USING BTREE,
        UNIQUE INDEX `udx_bu_name_bb_mst_business_unit` (`business_unit_name`) USING BTREE,
        UNIQUE INDEX `udx_bu_code_bb_mst_business_unit` (`business_unit_code`) USING BTREE
    ) COLLATE = 'utf8mb4_general_ci' ENGINE = InnoDB ROW_FORMAT = DYNAMIC;