CREATE SEQUENCE bb_seq_mst_team;

CREATE TABLE
    `bb_mst_team` (
        `id` INT (11) NOT NULL DEFAULT nextval (`bb_seq_mst_team`),
        `team_code` VARCHAR(50) NOT NULL COLLATE 'utf8mb4_general_ci',
        `team_name` VARCHAR(200) NOT NULL COLLATE 'utf8mb4_general_ci',
        `team_desc` VARCHAR(100) NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
        `aat_id` INT (11) NULL DEFAULT '0',
        `status` VARCHAR(1) NULL DEFAULT 'Y' COMMENT 'Active=Y, Inactive=N' COLLATE 'utf8mb4_general_ci',
        `status_date` DATETIME NOT NULL DEFAULT current_timestamp(),
        `waqti_id` INT (11) NULL DEFAULT NULL,
        `created_by` VARCHAR(50) NOT NULL COLLATE 'utf8mb4_general_ci',
        `created_on` DATETIME NOT NULL DEFAULT current_timestamp(),
        `modified_by` VARCHAR(50) NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
        `modified_on` DATETIME NULL DEFAULT NULL ON UPDATE current_timestamp(),
        PRIMARY KEY (`id`) USING BTREE,
        UNIQUE INDEX `udx_waqti_id_bb_mst_team` (`waqti_id`) USING BTREE,
        INDEX `idx_team_name_bb_mst_team` (`team_name`) USING BTREE,
        INDEX `idx_aat_bb_mst_team` (`aat_id`) USING BTREE,
        INDEX `idx_team_code_bb_mst_team` (`team_code`) USING BTREE
    ) COLLATE = 'utf8mb4_general_ci' ENGINE = InnoDB ROW_FORMAT = DYNAMIC;