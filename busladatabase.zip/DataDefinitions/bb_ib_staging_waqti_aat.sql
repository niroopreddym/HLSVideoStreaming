CREATE SEQUENCE bb_seq_ib_staging_waqti_aat;

CREATE TABLE
    `bb_ib_staging_waqti_aat` (
        `id` INT (11) NOT NULL DEFAULT nextval (`bb_seq_ib_staging_waqti_aat`),
        `waqti_id` INT (11) NOT NULL DEFAULT '0' COMMENT 'aat id from Waqti',
        `aat_name` VARCHAR(50) NOT NULL COLLATE 'utf8mb4_general_ci',
        `aat_desc` VARCHAR(100) NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
        `pillar_id` INT (11) NULL DEFAULT NULL,
        `pillar_code` VARCHAR(25) NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
        `pillar_name` VARCHAR(100) NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
        `portfolio_id` INT (11) NULL DEFAULT '0',
        `portfolio_code` VARCHAR(50) NULL DEFAULT NULL COMMENT 'Portfolio Code' COLLATE 'utf8mb4_general_ci',
        `portfolio_name` VARCHAR(100) NULL DEFAULT NULL COMMENT 'Portfolio Name' COLLATE 'utf8mb4_general_ci',
        `status` VARCHAR(1) NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
        `sys_created_by` VARCHAR(50) NOT NULL COMMENT 'Created by in Waqti' COLLATE 'utf8mb4_general_ci',
        `sys_created_on` DATETIME NULL DEFAULT NULL COMMENT 'Created on in Waqti',
        `sys_modified_by` VARCHAR(50) NULL DEFAULT NULL COMMENT 'Modified by in Waqti' COLLATE 'utf8mb4_general_ci',
        `sys_modified_on` DATETIME NULL DEFAULT NULL COMMENT 'Modified on in Waqti',
        `created_by` VARCHAR(50) NOT NULL DEFAULT 'UPLOAD' COLLATE 'utf8mb4_general_ci',
        `created_on` DATETIME NOT NULL DEFAULT current_timestamp(),
        `modified_by` VARCHAR(50) NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
        `modified_on` DATETIME NULL DEFAULT NULL ON UPDATE current_timestamp(),
        PRIMARY KEY (`id`) USING BTREE,
        INDEX `idx_aat_name_waqti_aat` (`aat_name`) USING BTREE,
        INDEX `idx_aat_desc_waqti_aat` (`aat_desc`) USING BTREE,
        INDEX `idx_portfolio_id_waqti_aat` (`portfolio_id`) USING BTREE,
        INDEX `idx_portfolio_cd_waqti_aat` (`portfolio_code`) USING BTREE,
        INDEX `idx_waqti_id_waqti_aat` (`waqti_id`) USING BTREE,
        INDEX `idx_waqti_id_waqti_created_on` (`created_on`) USING BTREE
    ) COLLATE = 'utf8mb4_general_ci' ENGINE = InnoDB ROW_FORMAT = DYNAMIC;