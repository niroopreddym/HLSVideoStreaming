CREATE SEQUENCE bb_seq_mst_aat;

CREATE TABLE
    `bb_mst_aat` (
        `id` INT (11) NOT NULL DEFAULT nextval (`bb_seq_mst_aat`),
        `waqti_id` INT (11) NULL DEFAULT NULL,
        `aat_code` VARCHAR(50) NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
        `aat_name` VARCHAR(50) NOT NULL COLLATE 'utf8mb4_general_ci',
        `aat_desc` VARCHAR(100) NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
        `art_short_name` VARCHAR(50) NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
        `art_name` VARCHAR(100) NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
        `pillar_id` INT (11) NULL DEFAULT NULL,
        `delivery_portfolio_id` INT (11) NULL DEFAULT '0',
        `status` VARCHAR(1) NOT NULL DEFAULT 'Y' COMMENT 'Active=Y, Inactive=N' COLLATE 'utf8mb4_general_ci',
        `status_date` DATETIME NOT NULL DEFAULT current_timestamp(),
        `created_by` VARCHAR(50) NOT NULL COLLATE 'utf8mb4_general_ci',
        `created_on` DATETIME NOT NULL DEFAULT current_timestamp(),
        `modified_by` VARCHAR(50) NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
        `modified_on` DATETIME NULL DEFAULT NULL ON UPDATE current_timestamp(),
        PRIMARY KEY (`id`) USING BTREE,
        UNIQUE INDEX `udx_waqti_id_bb_mst_aat` (`waqti_id`) USING BTREE,
        INDEX `idx_pillarid_bb_mst_aat` (`pillar_id`) USING BTREE,
        INDEX `idx_art_bb_mst_aat` (`art_name`) USING BTREE,
        INDEX `idx_art_desc_bb_mst_aat` (`aat_desc`) USING BTREE,
        INDEX `idx_art_cd_bb_mst_aat` (`aat_code`) USING BTREE,
        INDEX `idx_aat_nm_bb_mst_aat` (`aat_name`) USING BTREE
    ) COLLATE = 'utf8mb4_general_ci' ENGINE = InnoDB ROW_FORMAT = DYNAMIC;