CREATE TABLE
    `bb_email_notification` (
        `id` INT (11) NOT NULL AUTO_INCREMENT,
        `data_collected_date` DATE NULL DEFAULT NULL,
        `is_processed` TINYINT (1) NULL DEFAULT NULL,
        PRIMARY KEY (`id`) USING BTREE
    ) COLLATE = 'utf8mb4_general_ci' ENGINE = InnoDB AUTO_INCREMENT = 109;