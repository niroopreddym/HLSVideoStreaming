CREATE SEQUENCE bb_seq_dim_category;

CREATE TABLE
    `bb_dim_category` (
        `id` INT (11) NOT NULL DEFAULT nextval (`bb_seq_dim_category`),
        `category_code` VARCHAR(150) NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
        `category_desc` VARCHAR(150) NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
        `created_by` VARCHAR(50) NOT NULL COLLATE 'utf8mb4_general_ci',
        `created_on` DATETIME NOT NULL DEFAULT current_timestamp(),
        `modified_by` VARCHAR(50) NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
        `modified_on` DATETIME NULL DEFAULT NULL ON UPDATE current_timestamp(),
        PRIMARY KEY (`id`) USING BTREE,
        INDEX `idx_dim_category_category_code` (`category_code`) USING BTREE
    ) COLLATE = 'utf8mb4_general_ci' ENGINE = InnoDB ROW_FORMAT = DYNAMIC;