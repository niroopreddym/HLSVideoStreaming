CREATE TABLE
    `bb_mst_user_exception_access` (
        `id` INT (11) NOT NULL,
        `staff_id` VARCHAR(10) NOT NULL COMMENT 'staff id where edit access is required' COLLATE 'utf8mb4_general_ci',
        `product_id` VARCHAR(50) NULL DEFAULT NULL COMMENT 'product id from bb_mst_products table' COLLATE 'utf8mb4_general_ci',
        `hide_screen` VARCHAR(1000) NULL DEFAULT NULL COMMENT 'list of screen names which needs to be hidden' COLLATE 'utf8mb4_general_ci',
        `remarks` VARCHAR(200) NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
        `created_by` VARCHAR(50) NOT NULL COLLATE 'utf8mb4_general_ci',
        `created_on` DATETIME NOT NULL DEFAULT current_timestamp(),
        `modified_by` VARCHAR(50) NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
        `modified_on` DATETIME NULL DEFAULT NULL ON UPDATE current_timestamp()
    ) COLLATE = 'utf8mb4_general_ci' ENGINE = InnoDB ROW_FORMAT = DYNAMIC;