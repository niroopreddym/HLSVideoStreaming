CREATE SEQUENCE bb_seq_module_status;

CREATE TABLE
    `bb_module_status` (
        `id` INT (11) NOT NULL DEFAULT nextval (`bb_seq_module_status`),
        `name` VARCHAR(50) NOT NULL COLLATE 'utf8mb4_general_ci',
        `stats_prepared_on` DATETIME NULL DEFAULT NULL,
        `status` VARCHAR(10) NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
        `start_date` DATETIME NULL DEFAULT NULL,
        `end_date` DATETIME NULL DEFAULT NULL,
        `error` TEXT NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
        `created_by` VARCHAR(50) NOT NULL COLLATE 'utf8mb4_general_ci',
        `created_on` DATETIME NOT NULL DEFAULT current_timestamp(),
        `modified_by` VARCHAR(50) NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
        `modified_on` DATETIME NULL DEFAULT NULL ON UPDATE current_timestamp(),
        PRIMARY KEY (`id`) USING BTREE
    ) COLLATE = 'utf8mb4_general_ci' ENGINE = InnoDB ROW_FORMAT = DYNAMIC;