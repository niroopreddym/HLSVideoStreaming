CREATE SEQUENCE bb_seq_mst_ci_notfn_history;

CREATE TABLE
    `bb_mst_ci_notfn_history` (
        `id` INT (11) NOT NULL DEFAULT nextval (`bb_seq_mst_ci_notfn_history`),
        `ci_id` INT (11) NOT NULL,
        `notified_on` DATETIME NOT NULL DEFAULT current_timestamp(),
        `reminder_required` VARCHAR(1) NOT NULL DEFAULT 'N' COMMENT 'reminder required = Y, not required = N' COLLATE 'utf8mb4_general_ci',
        `created_by` VARCHAR(50) NOT NULL COLLATE 'utf8mb4_general_ci',
        `created_on` DATETIME NOT NULL DEFAULT current_timestamp(),
        `modified_by` VARCHAR(50) NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
        `modified_on` DATETIME NULL DEFAULT NULL ON UPDATE current_timestamp(),
        PRIMARY KEY (`id`) USING BTREE,
        INDEX `bb_idx_mst_ci_notfn_history` (`ci_id`) USING BTREE
    ) COLLATE = 'utf8mb4_general_ci' ENGINE = InnoDB;