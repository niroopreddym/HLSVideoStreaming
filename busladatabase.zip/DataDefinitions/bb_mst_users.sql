CREATE SEQUENCE bb_seq_mst_users;

CREATE TABLE
    `bb_mst_users` (
        `id` INT (11) NOT NULL DEFAULT nextval (`bb_seq_mst_users`) COMMENT 'Unique record identifier',
        `staff_id` VARCHAR(7) NOT NULL COMMENT 'Staff number' COLLATE 'utf8mb4_general_ci',
        `first_name` VARCHAR(50) NOT NULL COMMENT 'First name of the staff' COLLATE 'utf8mb4_general_ci',
        `last_name` VARCHAR(50) NOT NULL COMMENT 'Last name of the staff' COLLATE 'utf8mb4_general_ci',
        `job_title` VARCHAR(150) NULL DEFAULT NULL COMMENT 'Job Title' COLLATE 'utf8mb4_general_ci',
        `cost_centre_code` VARCHAR(20) NULL DEFAULT NULL COMMENT 'Cost Center Code' COLLATE 'utf8mb4_general_ci',
        `line_manager` INT (11) NULL DEFAULT NULL COMMENT 'Line manage to whom the staff reports to ',
        `line_manager_staff_id` VARCHAR(7) NULL DEFAULT NULL COMMENT 'Line Manager Staff number' COLLATE 'utf8mb4_general_ci',
        `role_code` VARCHAR(50) NULL DEFAULT NULL COMMENT 'Role Code' COLLATE 'utf8mb4_general_ci',
        `role_desc` VARCHAR(50) NULL DEFAULT NULL COMMENT 'Role Description' COLLATE 'utf8mb4_general_ci',
        `chapter_id` INT (4) NULL DEFAULT NULL COMMENT 'Chapter to which the staff belongs to. Refer to id of common master (chapter)',
        `alert_reqd` VARCHAR(1) NULL DEFAULT NULL COMMENT 'Y denotes alert can be sent to the staff' COLLATE 'utf8mb4_general_ci',
        `team_id` INT (11) NULL DEFAULT NULL COMMENT 'Team to which the staff belongs to. Refer to id of common master (team)',
        `grade` VARCHAR(50) NULL DEFAULT NULL COMMENT 'Grade' COLLATE 'utf8mb4_general_ci',
        `extended_portfolio_id` INT (10) NULL DEFAULT NULL,
        `email` VARCHAR(150) NULL DEFAULT NULL COMMENT 'email id of the staff' COLLATE 'utf8mb4_general_ci',
        `date_of_joining` DATE NULL DEFAULT NULL COMMENT 'Date of Joining IT',
        `date_of_leaving` DATE NULL DEFAULT NULL COMMENT 'Date of leaving IT',
        `created_by` VARCHAR(10) NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
        `created_on` DATETIME NULL DEFAULT current_timestamp(),
        `modified_by` VARCHAR(10) NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
        `modified_on` DATETIME NULL DEFAULT NULL ON UPDATE current_timestamp(),
        PRIMARY KEY (`id`) USING BTREE,
        UNIQUE INDEX `udx_staff_id_bb_mst_users` (`staff_id`) USING BTREE,
        INDEX `idx_team_id_bb_mst_users` (`team_id`) USING BTREE,
        INDEX `idx_chapter_id_bb_mst_users` (`chapter_id`) USING BTREE,
        INDEX `idx_job_bb_mst_users` (`job_title`) USING BTREE,
        INDEX `idx_staff_name_bb_mst_users` (`last_name`, `first_name`) USING BTREE
    ) COLLATE = 'utf8mb4_general_ci' ENGINE = InnoDB ROW_FORMAT = DYNAMIC;