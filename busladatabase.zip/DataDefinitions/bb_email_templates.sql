CREATE SEQUENCE bb_seq_email_templates;

CREATE TABLE
    `bb_email_templates` (
        `id` INT (11) NOT NULL DEFAULT nextval (`bb_seq_email_templates`),
        `template_name` VARCHAR(255) NOT NULL COLLATE 'utf8mb4_general_ci',
        `email_to` VARCHAR(255) NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
        `email_cc` VARCHAR(255) NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
        `email_from` VARCHAR(255) NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
        `email_subject` VARCHAR(255) NOT NULL COLLATE 'utf8mb4_general_ci',
        `email_body` TEXT NOT NULL COLLATE 'utf8mb4_general_ci',
        `status` VARCHAR(1) NOT NULL DEFAULT 'Y' COMMENT 'active = Y, not active = N' COLLATE 'utf8mb4_general_ci',
        `created_by` VARCHAR(50) NOT NULL COLLATE 'utf8mb4_general_ci',
        `created_on` DATETIME NOT NULL DEFAULT current_timestamp(),
        `modified_by` VARCHAR(50) NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
        `modified_on` DATETIME NULL DEFAULT NULL ON UPDATE current_timestamp(),
        PRIMARY KEY (`id`) USING BTREE,
        UNIQUE INDEX `bb_udx_email_templates` (`template_name`) USING BTREE,
        INDEX `bb_idx_created_on_email_templates` (`created_on`) USING BTREE
    ) COLLATE = 'utf8mb4_general_ci' ENGINE = InnoDB ROW_FORMAT = DYNAMIC;