CREATE SEQUENCE bb_seq_snow_fact_incident;

CREATE TABLE
    `bb_snow_fact_incident` (
        `id` INT (11) NOT NULL DEFAULT nextval (`bb_seq_snow_fact_incident`),
        `dim_ci_id` INT (11) NULL DEFAULT NULL,
        `dim_time_id` INT (11) NULL DEFAULT NULL,
        `close_code` TINYTEXT NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
        `incident_state` TINYTEXT NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
        `major_incident_state` TINYTEXT NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
        `u_triggered_by_alert` TINYTEXT NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
        `state` TINYTEXT NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
        `task_effective_number` TINYTEXT NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
        `created_by` VARCHAR(50) NOT NULL COLLATE 'utf8mb4_general_ci',
        `created_on` DATETIME NOT NULL DEFAULT current_timestamp(),
        `modified_by` VARCHAR(50) NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
        `modified_on` DATETIME NULL DEFAULT NULL ON UPDATE current_timestamp(),
        PRIMARY KEY (`id`) USING BTREE
    ) COLLATE = 'utf8mb4_general_ci' ENGINE = InnoDB;