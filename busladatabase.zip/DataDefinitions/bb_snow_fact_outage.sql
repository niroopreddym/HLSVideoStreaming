CREATE SEQUENCE bb_seq_snow_fact_outage;

CREATE TABLE
    `bb_snow_fact_outage` (
        `id` INT (11) NOT NULL DEFAULT nextval (`bb_seq_snow_fact_outage`),
        `dim_ci_id` INT (11) NULL DEFAULT NULL,
        `dim_time_id` INT (11) NULL DEFAULT NULL,
        `begin` DATETIME NULL DEFAULT NULL,
        `duration` TINYTEXT NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
        `end` DATETIME NULL DEFAULT NULL,
        `number` TINYTEXT NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
        `task_number` TINYTEXT NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
        `type` TINYTEXT NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
        `created_by` VARCHAR(50) NOT NULL COLLATE 'utf8mb4_general_ci',
        `created_on` DATETIME NOT NULL DEFAULT current_timestamp(),
        `modified_by` VARCHAR(50) NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
        `modified_on` DATETIME NULL DEFAULT NULL ON UPDATE current_timestamp(),
        PRIMARY KEY (`id`) USING BTREE
    ) COLLATE = 'utf8mb4_general_ci' ENGINE = InnoDB;