DataDefinitons is for intial boot also called as init script.

Rollouts
test 1
