#!/bin/bash
# Validate if any changes are pending in the changelog
PENDING=$(liquibase status --verbose | grep -i 'pending')
if [ -n "$PENDING" ]; then
  echo "There are pending changesets that need to be applied first."
  exit 1
fi

# Check for duplicate changeSet IDs in the DATABASECHANGELOG table
DUPLICATES=$(psql -U your_db_user -d your_db_name -c "SELECT ID, COUNT(*) FROM DATABASECHANGELOG GROUP BY ID HAVING COUNT(*) > 1;")
if [ -n "$DUPLICATES" ]; then
  echo "Duplicate changesets detected. Please review your changelog files."
  exit 1
fi

echo "Validation passed. You can proceed with the update."
