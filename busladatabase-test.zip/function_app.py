import azure.functions as func
import subprocess
import datetime
import json
import logging
from azuredevops import AzureDevOpsPRSync

app = func.FunctionApp()

@app.route(route="liquibase_version", auth_level=func.AuthLevel.ANONYMOUS)
def liquibase_version(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('HTTP trigger function processed a request to fetch Liquibase version. 77')

    try:
        # Run the Liquibase command
        result = subprocess.run(
            ["liquibase", "--version"],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
        )

        # Check if the command was successful
        if result.returncode == 0:
            return func.HttpResponse(
                f"Liquibase Version: {result.stdout.strip()}",
                status_code=200
            )
        else:
            return func.HttpResponse(
                f"Error fetching Liquibase version: {result.stderr.strip()}",
                status_code=500
            )
    except Exception as e:
        logging.error(f"Exception occurred: {e}")
        return func.HttpResponse(
            "An error occurred while fetching the Liquibase version.",
            status_code=500
        )

@app.route(route="generate_changelog", auth_level=func.AuthLevel.ANONYMOUS)
def generate_changelog(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('HTTP trigger function initiated to make changes to changelog file')
    try:
        source_file = "promotes\\dev\\deploy.sql"
        stage_promote_file = "promotes\\stage\\deploy.sql"
        history_file = "history\\dev\\deploy.sql"

        with open(source_file, 'r') as src:
            file_content = src.read()
            if not file_content.strip():
                logging.warning(f"Source file '{source_file}' is empty. Aborting operation.")
                return func.HttpResponse(
                    "Source file is empty. No operations were performed.",
                    status_code=400
                )

        # Append content to the destination files
        with open(stage_promote_file, 'a') as dest:
            dest.write(file_content)

        with open(history_file, 'a') as dest:
            dest.write(file_content)

        # Clear the source file
        with open(source_file, 'w') as src:
            src.truncate(0)

        # Commit the modified files using Azure DevOps REST API
        prsync(stage_promote_file, history_file, source_file)

        return func.HttpResponse(
            "Success",
            status_code=200
        )
    except Exception as e:
        logging.error(f"Exception occurred: {e}")
        return func.HttpResponse(
            "An error occurred while processing the request.",
            status_code=500
        )

def prsync(stage_promote_file:str, history_file:str, source_file: str):
    access_token = "BBGGOa0pr4sT7Sh7XhKAPn5gR3lVG5EhL636TOa0UDeiXWju6jVsJQQJ99AKACAAAAAOsIzUAAASAZDOBuBV"
    org_name = "niroop"
    project_name = "Python_Functions"
    repo_name = "busladatabase-test"
    from_branch = "dev"
    to_branch = "stage"

    pr_sync = AzureDevOpsPRSync(access_token, org_name, project_name, repo_name, from_branch, to_branch)
    # pr_sync.sync_pr()
    pr_sync.commit_changes(stage_promote_file, history_file, source_file)