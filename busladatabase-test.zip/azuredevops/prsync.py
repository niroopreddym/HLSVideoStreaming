import requests
import logging
import base64

class AzureDevOpsPRSync:
    def __new__(cls, *args, **kwargs):
        """Ensure the class is a singleton if needed."""
        if not hasattr(cls, '_instance'):
            cls._instance = super(AzureDevOpsPRSync, cls).__new__(cls)
        return cls._instance

    def __init__(self, pat_token, org_name, project_name, repo_name, from_branch, to_branch):
        """
        Initialize the AzureDevOpsPRSync class.
        
        :param pat_token: Personal Access Token (PAT) for authentication.
        :param org_name: Azure DevOps organization name.
        :param project_name: Azure DevOps project name.
        :param repo_name: Azure DevOps repository name.
        :param from_branch: Source branch for the PR.
        :param to_branch: Target branch for the PR.
        """
        self.pat_token = pat_token
        self.org_name = org_name
        self.project_name = project_name
        self.repo_name = repo_name
        self.from_branch = from_branch
        self.to_branch = to_branch
        self.api_base_url = f"https://dev.azure.com/{self.org_name}/{self.project_name}/_apis/git/repositories/{self.repo_name}/pullrequests?api-version=7.1-preview.1"
        self.pr_title = f"Sync {from_branch} to {to_branch}"
        self.pr_description = f"Automated PR to sync changes from {from_branch} to {to_branch}."
        encoded_pat = base64.b64encode(f":{self.pat_token}".encode('utf-8')).decode('utf-8')
        self.headers = {
            "Authorization": f"Basic {encoded_pat}",
            "Content-Type": "application/json"
        }

    def get_existing_pr(self):
        url = f"{self.api_base_url}&searchCriteria.sourceRefName=refs/heads/{self.from_branch}&searchCriteria.targetRefName=refs/heads/{self.to_branch}&searchCriteria.status=active"
        response = self._api_request("GET", url)
        pr_list = response.get("value", [])
        return pr_list[0] if pr_list else None

    def create_pr(self):
        url = self.api_base_url
        payload = {
            "sourceRefName": f"refs/heads/{self.from_branch}",
            "targetRefName": f"refs/heads/{self.to_branch}",
            "title": self.pr_title,
            "description": self.pr_description,
        }
        return self._api_request("POST", url, json=payload)

    def update_pr(self, pr_id):
        url = f"https://dev.azure.com/{self.org_name}/{self.project_name}/_apis/git/repositories/{self.repo_name}/pullrequests/{pr_id}/comments?api-version=7.1-preview.1"
        payload = {
            "content": "The PR has been refreshed due to new changes in the source branch."
        }
        return self._api_request("POST", url, json=payload)

    def sync_pr(self):
        existing_pr = self.get_existing_pr()
        if existing_pr:
            pr_id = existing_pr["id"]
            print(f"Found existing PR: #{pr_id} - {existing_pr['title']}")
            self.update_pr(pr_id)
            print(f"Updated PR #{pr_id} with a new comment.")
        else:
            print("No existing PR found. Creating a new one...")
            new_pr = self.create_pr()
            print(f"Created new PR: #{new_pr['id']} - {new_pr['title']}")

    def commit_changes(self, stage_promote_file, history_file, source_file):
        dev_branch = "dev"
        try:
            # Read the content of the modified files
            with open(stage_promote_file, 'r') as f:
                stage_file_content = f.read()
            
            with open(history_file, 'r') as f:
                history_file_content = f.read()
            
            with open(source_file, 'r') as f:
                src_file_content = f.read()

            # Prepare the commit message and changes
            commit_message = "Automated update to changelog files."

            changes = [
                {
                    "changeType": "edit",
                    "item": {
                        "path": "/promotes/stage/deploy.sql" 
                    },
                    "newContent": {
                        "content": stage_file_content,
                        "contentType": "rawtext"
                    }
                },
                {
                    "changeType": "edit",
                    "item": {
                        "path": "/history/dev/deploy.sql" 
                    },
                    "newContent": {
                        "content": history_file_content,
                        "contentType": "rawtext"
                    }
                },
                {
                    "changeType": "edit",
                    "item": {
                        "path": "/promotes/dev/deploy.sql" 
                    },
                    "newContent": {
                        "content": src_file_content,
                        "contentType": "rawtext"
                    }
                }
            ]

            # Fetch the current commit ID of the target branch
            commit_id = self.get_recent_commit_id()
            
            # Prepare the payload
            payload = {
                "refUpdates": [{
                    "name": f"refs/heads/{dev_branch}",  
                    "oldObjectId": commit_id 
                }],
                "commits": [{
                    "comment": commit_message,
                    "changes": changes
                }]
            }
            
            api_url = f"https://dev.azure.com/{self.org_name}/{self.project_name}/_apis/git/repositories/{self.repo_name}/pushes?api-version=7.1"
            # Make the API call to push the commit
            response = requests.post(
                api_url,
                headers=self.headers,
                json=payload
            )
            
            if response.status_code == 200 or response.status_code == 201:
                print("Changes successfully pushed to the repository.")
            else:
                print(f"Failed to push changes: {response.status_code} - {response.text}")
        except Exception as e:
           logging.error(f"Error committing changes: {e}")
           raise
        
    def get_recent_commit_id(self) -> str:
        dev_branch = "dev"
        api_url = f"https://dev.azure.com/{self.org_name}/{self.project_name}/_apis/git/repositories/{self.repo_name}/commits?searchCriteria.itemVersion.version={dev_branch}&$top=1&api-version=7.1"
        
        try:
            response = requests.get(api_url, headers=self.headers)
            
            if response.status_code == 200:
                commit_data = response.json()
                if "value" in commit_data and len(commit_data["value"]) > 0:
                    commit_id = commit_data["value"][0]["commitId"]
                    return commit_id
                else:
                    # we can send this as intial commit it "0000000000000000000000000000000000000000"
                    raise ValueError("No commits found in the response.")
            else:
                raise Exception(f"Failed to fetch commits: {response.status_code} - {response.text}")
        
        except Exception as e:
            print(f"Error fetching the most recent commit ID: {e}")
            raise


