import requests

class BitbucketPRSync:
    def __new__(cls, *args, **kwargs):
        """Ensure the class is a singleton if needed."""
        if not hasattr(cls, '_instance'):
            cls._instance = super(BitbucketPRSync, cls).__new__(cls)
        return cls._instance

    def __init__(self, access_token, workspace, repo_slug, from_branch, to_branch):
        """
        Initialize the BitbucketPRSync class.
        
        :param access_token: HTTPS Access Token for authentication.
        :param workspace: Bitbucket workspace (team or user).
        :param repo_slug: Repository slug (repo name).
        :param from_branch: Source branch for the PR.
        :param to_branch: Target branch for the PR.
        """
        self.access_token = access_token
        self.workspace = workspace
        self.repo_slug = repo_slug
        self.from_branch = from_branch
        self.to_branch = to_branch
        self.api_base_url = "https://api.bitbucket.org/2.0"
        self.pr_title = f"Sync {from_branch} to {to_branch}"
        self.pr_description = f"Automated PR to sync changes from {from_branch} to {to_branch}."
        self.headers = {
            "Authorization": f"Bearer {self.access_token}",
            "Content-Type": "application/json"
        }

    def _api_request(self, method, endpoint, **kwargs):
        """Helper function to make API requests."""
        url = f"{self.api_base_url}{endpoint}"
        response = requests.request(
            method,
            url,
            headers=self.headers,
            **kwargs
        )
        response.raise_for_status()
        return response.json()

    def get_existing_pr(self):
        """Check if an open PR exists from `from_branch` to `to_branch`."""
        endpoint = f"/repositories/{self.workspace}/{self.repo_slug}/pullrequests"
        params = {
            "q": f"source.branch.name=\"{self.from_branch}\" AND destination.branch.name=\"{self.to_branch}\" AND state=\"OPEN\""
        }
        response = self._api_request("GET", endpoint, params=params)
        pr_list = response.get("values", [])
        return pr_list[0] if pr_list else None

    def create_pr(self):
        """Create a new pull request."""
        endpoint = f"/repositories/{self.workspace}/{self.repo_slug}/pullrequests"
        payload = {
            "title": self.pr_title,
            "description": self.pr_description,
            "source": {"branch": {"name": self.from_branch}},
            "destination": {"branch": {"name": self.to_branch}},
        }
        return self._api_request("POST", endpoint, json=payload)

    def update_pr(self, pr_id):
        """Update an existing pull request by adding a comment."""
        endpoint = f"/repositories/{self.workspace}/{self.repo_slug}/pullrequests/{pr_id}/comments"
        payload = {
            "content": {"raw": "The PR has been refreshed due to new changes in the source branch."}
        }
        return self._api_request("POST", endpoint, json=payload)

    def sync_pr(self):
        """Main function to handle PR sync logic."""
        existing_pr = self.get_existing_pr()
        if existing_pr:
            pr_id = existing_pr["id"]
            print(f"Found existing PR: #{pr_id} - {existing_pr['title']}")
            self.update_pr(pr_id)
            print(f"Updated PR #{pr_id} with a new comment.")
        else:
            print("No existing PR found. Creating a new one...")
            new_pr = self.create_pr()
            print(f"Created new PR: #{new_pr['id']} - {new_pr['title']}")


# Example Usage

