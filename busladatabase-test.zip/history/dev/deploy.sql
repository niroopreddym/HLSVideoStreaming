CREATE TABLE
    deploy_test (
        id INT AUTO_INCREMENT,
        name VARCHAR(50),
        PRIMARY KEY (id)
    );