## Part-1-boot up steps

You don't need to know Docker or Prometheus beforehand to solve this assignment, take a look at the following docs and understand the basics about these tools.

- run solution/gencsv.sh using ./gencsv.sh
- it will generate a csv file under csvserver folder which needs to be mounted as a volume to the container
- run the docker container using docker run -d -v C:/Users/maneti.n/go/src/github.com/infracloudio/csvserver/solution/csvserver/inputdata:/csvserver/inputdata infracloudio/csvserver:latest
- use docker ps to check the running container and the port on which the app is listening
- stop the container using docker stop <container-id>
- Run a new container with the port number as 9393 and env variable set to border yellow using the following command docker run -d -v C:/Users/maneti.n/go/src/github.com/infracloudio/csvserver/solution/csvserver/inputdata:/csvserver/inputdata -p 9393:9300 -e CSVSERVER_BORDER='Orange'  infracloudio/csvserver:latest
