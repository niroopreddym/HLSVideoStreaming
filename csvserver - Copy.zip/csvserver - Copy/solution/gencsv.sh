#!/usr/bin/env bash

# file="./csvserver/inputdata"
# # echo "0, 234" > $file
# # echo "1, 98" >> $file
# # echo "2, 34" >> $file
# # cat $file

# echo "$RANDOM, $RANDOM" > $file
# cat $file

input=10
file="./csvserver/inputdata"

echo "$RANDOM, $RANDOM" > $file
for (( i=1; i<=$input-1; i++ ))
do
    echo "$RANDOM, $RANDOM" >> $file
done

cat $file